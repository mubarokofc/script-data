// nomor owner ubah nomor lu
global.owner = '62895354291993@s.whatsapp.net' // 62895354291993
// nama owner ubah nama lu
global.ownerName = 'Zidan'
// nomor pengembang yang bisa akses fitur saveplugin, delplugin, getplugin dan eval
global.developer = [
'62895354291993',
'62895354291993',
'6283843317662'
// jangan asal add nomor, nanti bisa curi kode bot
].map(number => number.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
// nama bot lu
global.botName = 'Anya Chan'
// fake pada beberapa fitur
global.fake = 'Copyright © 2024 Zidan Store'
// header pada beberapa fitur
global.header = `© Anya Chan v${require('./package.json').version}`
// footer pada beberapa fitur
global.footer = 'ꜱɪᴍᴘʟᴇ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ ᴍᴀᴅᴇ ᴢɪᴅᴀɴ ꜱᴛᴏʀᴇ' 
global.footer2 = '© Copyright By Zidan Store 2025'
// jeda anti spam / detik
global.cooldown = 1
// ram maksimal untuk auto restart / gb
global.max_ram = 3
// blacklist nomor dengan kode negara tersebut
global.blocks = ['91', '92', '212']
// multi prefix default
global.prefixes = /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i
// setting id channel (cara ambil: invite bot menjadi admin channel lalu balas pesan undangan dengan perintah .getnewsletter
global.newsletter = '120363375037255604@newsletter'
global.newsletter2 = '120363312671301398@newsletter'
global.newsletter3 = '120363312671301398@newsletter'
// qris url di beberapa fitur seperti donate, buyprem dan sewabot
global.qrisUrl = 'https://files.catbox.moe/bhtque.jpg'
// audio url yang ada di menu
global.audioUrl = 'https://cdn.filestackcontent.com/2r7cSUozTQ2tTS15NfFj';
// setting pairing code
global.pairing = {
    copyFromLink: false, // ubah true jika ingin salin pairing via link https://iyaudah-iya.vercel.app/pairing
    status: true, // ubah false jika ingin menggunakan qr
    number: '6289520418621' // ubah jadi nomor bot lu
}
// apikey fitur quickchat
global.quoteApi = 'https://btzqc.betabotz.eu.org/generate'
// url database mongodb (daftar di https://www.mongodb.com/)
global.mongoUrl = ''
// setting message
// setting configuration baileys
global.config = {
session: 'session',
online: false,
version: [2, 3000, 1015901307],
browser: ['Ubuntu', 'Chrome', '22.04.4'],
button: true
}
global.alyachan = 'https://api.alyachan.dev'
global.xiex = 'Blogspot2'
global.alya = 'M0w7952Hn35F'
global.skizo = 'Akiraa'
global.shann = 'SRA-QWWTJH'
global.zenith = 'zenkey'
global.betabotz = '0TIrhCdZ7U2s1fX6Jzs0K0k056kyG7YQ0'
global.maher = 'bd12a55cb8342529af'
global.groq = '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'
global.zeta = '9jL26pavtzAHk9mdF0A5AeAfFcE1480b9b06737d9eC62c1e'
global.tomoe = 'AIzaSyB2mvsGVTZAU-h-GtCLzoLhjHEdvugx9uQ'
global.paste = 'abFFSw5uEbwkh1APp0hRTbwXgU4B9DZZwf7rjRPZE'

// Cvps
global.token_do = "-" // Apikey Digital Ocean

// Cpanel V1
global.panelApi = {
  domain: 'https://panel.zidanstore.xyz',
  apikey: 'ptla_caBjgFrHCQM6FdUBSzPbsxSr1aquqkzvqV8V8rwjhO1',
  capikey: 'ptlc_TZevhIPuKXU7ZeIY2WryGdNcaPXt02Syi2UbB4x6rn4',
  eggs: '15'
}

// Cpanel V2
global.panelApi2 = {
  domain: '',
  apikey: '',
  capikey: '',
  eggs: '15'
}

//~~~~~~~~~ Settings Orderkuota ~~~~~~~~//
global.merchantIdOrderKuota = "OK2028793"
global.apiOrderKuota = "395862317374523872028793OKCT2640B5E32BEC76FBC4F4544B9C52AD4D"
global.qrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214510592215823740303UMI51440014ID.CO.QRIS.WWW0215ID20243440349370303UMI5204541153033605802ID5921ZIDAN STORE OK20287936009PURWOREJO61055418362070703A016304F386"

//~~~~~~~~~~ Settings Apikey ~~~~~~~~~~//
global.apiDigitalOcean = "-"
global.apiSimpleBot = "simplebotz85"

// ===== INTEGRASI ===== (WAJIB)
// Orderkuota https://okeconnect.com
global.ord_web = 'https://h2h.okeconnect.com'
global.ord_id = 'OK2028793'
global.ord_apikey = '395862317374523872028793OKCT2640B5E32BEC76FBC4F4544B9C52AD4D'
global.ord_harga_id = '905ccd028329b0a'
global.ord_pin = '9090'
global.ord_password = 'zidanstore'

// Laba (Keuntungan)
global.user_silver = 200
global.user_gold = 100
global.user_diamond = 50

// QRIS
global.qris = '00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214510592215823740303UMI51440014ID.CO.QRIS.WWW0215ID20243440349370303UMI5204541153033605802ID5921ZIDAN STORE OK20287936009PURWOREJO61055418362070703A016304F386'

global.subdomain = {
"zidanstore-server.online": {
"zone": "bfd0fa82eeabde62e79fbd64fd7dbd14",
"apitoken": "-DOkzWhCyZm4VjEP3L6roZ92KU5ffO8vDqnzRqSc",
},
"zidan-store.my.id": {
"zone": "4d474f8f4038f1cabd15a0bd82a60b7b",
"apitoken": "xxJnVMu3E6-XnXJJf67ooRkQefHMd0gEoftTWKW3"
},
"zidanstore.xyz": {
"zone": "14ac5d2eb38c0cc28daff698e3c9c454",
"apitoken": "R5N-ctmk46nqI_5ExUZC33hq1yK5oBaEFr5133Qp",
},
"admin-panel.tech": {
"zone": "305d4757160a88486d3780785c7c9887",
"apitoken": "UH-aDtxu5Mm9oU8khMd5ZVg22f7nhnSkCORBn8zP",
},
"kang-panel.tech": {
"zone": "28baf36eb9ced4be271bdb6ea3320f41",
"apitoken": "MBiKuyoS0e0zJc8LKUjSXyLmgAf1IV9u86FJmVny",
},
"web-cabul.me": {
"zone": "4b24636040f0f2d799a8a1aaea568e57",
"apitoken": "OvRX-DghNjcPF9rlKElGCLIsPvv3Nd3khuDAUZ3q",
},

"king-hosting.live": {
"zone": "2e6eb183148e0ef9add390af271a8bb2",
"apitoken": "kcnnE1sESybx-P_nLkkiKtfZFqGhRmwFg9wL0cf6",
},
"tokopanel.software": {
"zone": "cc9638d4c289130ba070484625e6aefa",
"apitoken": "bcAP5z3gHvmQTlQ59qNB9BWmf0JiGt0C99FU6SXs",
},
"pannel-private.me": {
"zone": "71ad41d3c25085bd7b8a1135632c7c63",
"apitoken": "HfGKPUu1KrOVc3q51nkoJYZFQvIpA-AFOP-t6SNZ",
},
"hitam.systems": {
"zone": "cfaba3ef0065acc82facc17f1b79d50b",
"apitoken": "4o3tZAc5jOzA00joKpLYhG_616qCJxNLGlhawMEY",
},
"panel-run-bot.engineer": {
"zone": "678298eaac2e2a0dea25f693310ec6e0",
"apitoken": "8UmNiZZqEIAqWbM7XlcZofyvhc70NMs2_gXmmkug",
},
"uchiha.tech": {
"zone": "1b09e81ec29d760ff33e476a084de6ed",
"apitoken": "nzLwv-2uzMt3Ihsd5MVV2aLJ9EoovxrVK7Y4b2To",
},
"buyer-vps.site": {
"zone": "354e1c784bed5a8d93f458ec1ff86f35",
"apitoken": "rzOLIO1c-Me1X0owStLFUZ0ggfs_cxHDab2A7krF",
},
"arzanoffc.online": {
"zone": "43ca801f5c6a73a77da5f0243f4f8c1d",
"apitoken": "RZQft_gJGOJDskx6L6SxREJCvOKw0hclLjHUCNLS",
},
"hexaneuro.biz.id": {
"zone": "16273869fda58585fc435e4582a5ff56",
"apitoken": "y4wV0um-bvrVTvFVPrNrGEi590bPowvosRyNiGMn"
 },   
"mypanel.tech": {
"zone": "9c5460deca7c84273b46f2f047783636",
"apitoken": "0IBfmlUlCkYqoFPWYaqCmqI3_vWxkrFNbxrQjzX2"
}, 
"kedai-panel.me": {
"zone": "3ab91ea96368234719c9de7d260742e2",
"apitoken": "O22A19W7trZZ52bAXtF77aUVdGDdAk8PjQqwM7qv"
}, 
"control-pannel.site": {
"zone": "20c517d7dcc25d9cf516f5c4cf2d21ba",
"apitoken": "mAA84Qs4nJvLTaup0HTGrpVbgaSk-4vfUrcdHgCH"
}, 
"mypanelstore.xyz": {
"zone": "72f7362d7686d9158a8e389851fc379c", 
"apitoken": "V2y-I2o1s5E1tdCPpUSnT4FokV6WuxEUC2FqqVIX"
}
}
global.mess = {
wait: 'Processed . . .',
ok: 'Successfully.',
limit: 'Anda telah mencapai limit dan akan disetel ulang pada pukul 00.00\n\n> untuk mendapatkan limit tak terbatas, tingkatkan ke paket premium.',
premium: 'This feature only for premium user.',
jadibot: 'This feature only for jadibot user.',
owner: 'This feature is only for owner.',
devs: 'This feature is only for developers.',
vvip: 'This feature is only for user vvip.',
group: 'This feature will only work in groups.',
private: 'Use this feature in private chat.',
admin: 'This feature only for group admin.',
botAdmin: 'This feature will work when I become an admin',
gconly: 'Bot hanya dapat digunakan di dalam grup.',
bot: 'This feature can only be accessed by bots',
wrong: 'Wrong format!',
error: {
url: 'URL is Invalid!', 
api: 'Sorry an error occurred!'
},
block: {
owner: `This feature is being blocked by owner!`,
system: `This feature is being blocked by system because an error occurred!`
},
query: 'Enter search text',
search: 'Searching . . .',
scrap: 'Scrapping . . .',
wrongFormat: 'Incorrect format, please look at the menu again',
game: 'Bermain game di obrolan pribadi hanya untuk pengguna premium, tingkatkan ke paket premium hanya Rp. 20.000 selama 1 bulan.'
}

// menghapus cache setelah update
require('./system/functions.js').reloadFile(__filename);