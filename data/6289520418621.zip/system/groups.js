let fetch = require("node-fetch"),
    func = require("./functions.js");

function removeDuplicateMember(e) {
    let t = new Set;
    return e.filter(e => !t.has(e.jid) && (t.add(e.jid), !0))
}
module.exports = class {
    expiration = 86400;
    qchannel = {
        key: {
            remoteJid: "status@broadcast",
            fromMe: !1,
            participant: "0@s.whatsapp.net"
        },
        message: {
            newsletterAdminInviteMessage: {
                newsletterJid: "120363312671301398@newsletter",
                newsletterName: 'ꜱɪᴍᴘʟᴇ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ ᴍᴀᴅᴇ ᴢɪᴅᴀɴ ꜱᴛᴏʀᴇ',
                jpegThumbnail: null,
                caption: 'ꜱɪᴍᴘʟᴇ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ ᴍᴀᴅᴇ ᴢɪᴅᴀɴ ꜱᴛᴏʀᴇ',
                inviteExpiration: Date.now() + 18144e5
            }
        }
    };
    groupAdd = async (o, s) => {
        if (!global.db.setting[o.user.jid].maintenance) {
            let {
                from: e,
                subject: t,
                desc: a,
                jid: r
            } = s, i, l;
            if (void 0 !== global.db.groups[e]) return l = (s = global.db.groups[e]).tekswelcome.replace("+user", "@" + r.split("@")[0]).replace("+group", t).replace("+desc", a), s.member.find(e => e.jid == r) || s.member.push({
                jid: r,
                lastseen: Date.now(),
                toxic: 0,
                chat: 0
            }), s && s.antiluar && !r.startsWith("62") ? (o.reply(e, func.texted("bold", `Sorry @${sender.split("@")[0]}, this group is only for indonesian people and you will removed automatically.`), {
                expiration: this.expiration
            }), o.updateBlockStatus(r, "block"), func.delay(2e3).then(() => o.groupParticipantsUpdate(e, [r], "remove"))) : s && s.blacklist.some(e => e === r) && !s.detect ? (o.reply(e, func.texted("bold", `Sorry @${r.split("@")[0]}, you have been blacklisted from this group.`)), func.delay(2e3).then(() => o.groupParticipantsUpdate(e, [r], "remove"))) : (s.welcome && (i = await o.profilePictureUrl(r, "image").catch(e => "https://files.catbox.moe/39hmb8.jpg"), o.sendMessageModify(e, l, this.qchannel, {
                title: "Welcome Message",
                body: global.header,
                thumbnail: await fetch(i).then(e => e.buffer()),
                largeThumb: !1,
                expiration: this.expiration,
                newsletter: !0
            })), l = removeDuplicateMember(s.member), void(s.member = l))
        }
    };
    groupRemove = async (e, t) => {
        var a, r, i, l, o = global.db.setting[e.user.jid];
        o.maintenance || ({
            from: t,
            subject: l,
            desc: a,
            jid: i
        } = t, void 0 !== global.db.groups[t] && (i = (r = global.db.groups[t]).teksleft.replace("+user", "@" + i.split("@")[0]).replace("+group", l).replace("+desc", a), r.left && e.sendMessageModify(t, i, this.qchannel, {
            title: "Leave Message",
            body: global.header,
            thumbnail: await fetch(o.cover).then(e => e.buffer()),
            largeThumb: !1,
            expiration: this.expiration,
            newsletter: !0
        }), l = removeDuplicateMember(r.member), r.member = l))
    }
}, func.reloadFile(__filename);