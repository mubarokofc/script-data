let jidNormalizedUser = require("@whiskeysockets/baileys").jidNormalizedUser,
    {
        Baileys,
        InvCloud
    } = require("./baileys.js"),
    {
        groupAdd,
        groupRemove
    } = new(require("./groups.js")),
    fs = require("fs"),
    chalk = require("chalk"),
    func = require("./functions.js"),
    path = require("path"),
    platform = require("os").platform,
    mainbot = null,
    expiration = 86400,
    fchannel = {
        key: {
            remoteJid: "status@broadcast",
            fromMe: !1,
            participant: "0@s.whatsapp.net"
        },
        message: {
            newsletterAdminInviteMessage: {
                newsletterJid: "120363375037255604@newsletter",
                newsletterName: "Jadibot System Notification",
                jpegThumbnail: null,
                caption: "Powered By ZidanDev",
                inviteExpiration: Date.now() + 18144e5
            }
        }
    };
exports.Jadibot = (l, d) => {
    try {
        null == mainbot && (mainbot = l);
        let i = null,
            t = global.db.jadibot.findIndex(e => e.number === d),
            o = (-1 == t && global.db.jadibot.push({
                number: d,
                session: "",
                notify: !0,
                status: !0
            }), "jadibot/session-" + d.split("@")[0]);
        var e = {
                ...global.config
            },
            c = e.online,
            b = e.version,
            g = e.browser;
        let n = 0,
            a = !1,
            s = Date.now(),
            r = new Baileys({
                pairing: {
                    status: !0,
                    number: d
                },
                type: "jadibot",
                session: o,
                online: c,
                version: b,
                browser: g
            });
        r.on("pairing", async e => {
            if (n++, console.log("Mencoba koneksi:", n), 2 < n) return l.reply(d, `Pairing code tidak dimasukkan ${n} kali, jadibot stopped.`, fchannel, {
                expiration: expiration
            }).then(async () => {
                null !== i && await l.sendMessage(d, {
                    delete: i
                })
            }), a = global.jadibot[d] || Object.values(global.jadibot).find(e => jidNormalizedUser(e.user?.id) == d), global.db.jadibot[t] && void 0 !== a && (delete global.jadibot[d], await a.end(), a.ws.close(), o) && fs.existsSync(o) && fs.rmSync(o, {
                recursive: !0,
                force: !0
            }), !1;
            var a = `Masukkan kode di bawah untuk jadi bot sementara:

1. klik titik tiga di pojok kanan atas
2. klik "Perangkat tertaut"
3. klik "Tautkan Perangkat"
4. klik "Tautkan dengan nomor telepon saja"
5. masukkan 6 digit kode di bawah

Your Pairing Code: ` + e.code;
            i = null == i ? (e = (await l.reply(d, a, fchannel, {
                expiration: expiration
            })).key, e) : (await l.sendMessage(d, {
                delete: i
            }), e = (await l.reply(d, a, fchannel, {
                expiration: expiration
            })).key, e)
        }), r.on("connect", async e => {
            e && "object" == typeof e && e.message && global.db.jadibot[t].notify && (console.log(e.message), /connecting/i.test(e.message) && !a ? (a = !0, await l.reply(d, e.message, fchannel, {
                expiration: expiration
            })) : /connected/i.test(e.message) ? (await l.reply(d, e.message, fchannel, {
                expiration: expiration
            }), global.db.jadibot[t].notify = !1) : await l.reply(d, e.message, fchannel, {
                expiration: expiration
            }))
        }), r.on("error", async e => {
            console.log(chalk.redBright.bold(e.message))
        }), r.on("ready", e => {
            e.user.uptime = s, e.user.jadibot = !0, global.db.jadibot[t].status = !0, global.db.jadibot[t].session = o, setInterval(async () => {
                try {
                    var e, a = [];
                    for (e of await fs.readdirSync(o)) "creds.json" != e && a.push(path.join(o, e));
                    await Promise.allSettled(a.map(async a => {
                        var e = await fs.statSync(a);
                        if (e.isFile() && 36e5 <= Date.now() - e.mtimeMs) {
                            if ("win32" === platform()) {
                                let e;
                                try {
                                    e = await fs.openSync(a, "r+")
                                } catch (e) {} finally {
                                    await e.close()
                                }
                            }
                            await fs.unlinkSync(a)
                        }
                    }))
                } catch {}
            }, 6e5)
        }), r.on("message", async e => {
            var {
                m: a,
                store: i
            } = e;
            InvCloud(i), require("../handler.js")(r.anya, e), global.db.setting[a.bot].autoread && "status@broadcast" === a.chat && !a.message?.protocolMessage && await r.anya.readMessages([a.key])
        }), r.on("message.delete", e => {
            var a = r.anya.user.jid;
            global.db.setting[a] && global.db.setting[a].maintenance || e && e.delete && e.origin && !e.origin.fromMe && !e.origin.isBot && e.origin.sender && e.origin.isGc && global.db.groups[e.origin.chat] && global.db.groups[e.origin.chat].antidelete && r.anya.copyNForward(e.origin.chat, e.delete, !1, {
                quoted: e.delete,
                ephemeralExpiration: e.origin.expiration || expiration
            })
        }), r.on("caller", e => {
            require("./anticall")(r.anya, e)
        }), r.on("group.add", e => groupAdd(r.anya, e)), r.on("group.remove", e => groupRemove(r.anya, e))
    } catch (e) {
        console.log(e), null !== mainbot && mainbot.reply(global.devs[1], e.message, fchannel, {
            expiration: expiration
        })
    }
}, exports.StopJadibot = async a => {
    var e = global.jadibot[a] || Object.values(global.jadibot).find(e => jidNormalizedUser(e.user?.id) == a),
        i = global.db.jadibot.find(e => e.number === a);
    if (void 0 === e && null !== mainbot) return mainbot.reply(a, "Kamu tidak terdaftar dalam sesi jadibot!", fchannel, {
        expiration: expiration
    });
    delete global.jadibot[a], i.status = !1, await e.end(), e.ws.close(), null !== mainbot && await mainbot.reply(a, "Jadibot successfully stopped.", fchannel, {
        expiration: expiration
    })
}, func.reloadFile(__filename);