let fs = require("fs");
module.exports = class {
  constructor() {
    this.MongoURL = global.mongoUrl;
    this.init = new (require("./localdb"))();
  }
  initDatabase = async () => {
    let e = {};
    try {
      var t;
      if (!this.MongoURL || !/mongo/.test(this.MongoURL)) {
        t = fs.readFileSync("./database/database.json", "utf8");
        e = JSON.parse(t);
      }
    } catch (e) {
      console.error("Error reading database file:", e);
    }
    global.db = {
      users: {},
      groups: {},
      statistic: {},
      sticker: {},
      stickercmd: {},
      setting: {},
      register: {},
      reminder: {},
      menfes: {},
      tictactoe: {},
      petakbom: {},
      casino: {},
      werewolf: {},
      chess: {},
      sambungkata: {},
      opentime: {},
      closetime: {},
      openai: {},
      verifyemail: {},
      metadata: {},
      saldo: [],
      paydata: [],
      testi: [],
      idtrx: [],
      proses: [],
      done: [],
      premium: [],
      jadibot: [],
      spamcode: [],
      orkut: [],
      owner: [],
      blockcmd: [],
      ...((await this.init.read()) || e)
    };
    await this.init.save(global.db);
  };
};