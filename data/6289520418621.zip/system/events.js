const cron = require('node-cron');
const moment = require('moment-timezone');
const fs = require('fs');
const func = require('./functions.js');
let statuses = true;
let alreadyRan = false;
let alarms = new Set();

module.exports = async (anya) => {
    /* Automatically Feature By ZidanDev */
    const groups = Object.values(global.db.groups).filter(v => v.automatically).map(x => x.jid);
    const bot = anya.user.id ? anya.user.id.split(':')[0] + '@s.whatsapp.net' : anya.user.jid;
    const setting = global.db.setting[bot];

    function checkBotAdmin(member) {
        const admins = member.filter(x => x.admin !== null)
        return !!admins.find(item => item.id === bot)
    }

    cron.schedule('0 0 0 * * *', async () => {
        if (!alreadyRan) {
            alreadyRan = true;
            Object.entries(global.db.statistic).map(([_, data]) => data.hittoday = 0);
            Object.values(global.db.users).filter((v) => v.limit < setting.limit.free && !v.premium).map((x) => x.limit = setting.limit.free);
            setting.lastreset = Date.now();
            let data = await func.backupSC();
            let caption = `Berikut adalah file backup kode bot:\nNama file: ${data.name}\nUkuran file: ${data.size} MB`
            await anya.sendMessage(global.developer[0], {
                    document: {
                        url: data.name
                    },
                    caption: caption,
                    mimetype: 'application/zip',
                    fileName: data.name
                }, {
                    quoted: func.fstatus('Auto Backup Script'),
                    ephemeralExpiration: 0
                })
                .then(_ => fs.unlinkSync(data.name));
        }
    }, {
        scheduled: true,
        timezone: 'Asia/Jakarta'
    });

    const scheduleTask = (cronTime, startingTask, announce) => {
        cron.schedule(cronTime, async () => {
            if (statuses === true) {
                statuses = false
                let getGroups = await anya.groupFetchAllParticipating();
                let listGroups = Object.values(getGroups);
                for (let x of listGroups) {
                    if (groups.includes(x.id) && x.announce === announce && checkBotAdmin(x.participants)) {
                        await startingTask(x);
                        await new Promise(resolve => setTimeout(resolve, 3000));
                    }
                }
                setTimeout(() => (statuses = true), 1000 * 60 * 3);
            }
        }, {
            scheduled: true,
            timezone: 'Asia/Jakarta'
        });
    };

    scheduleTask('0 0 0 * * *', async (data) => {
        // let text = 'Sistem secara otomatis menutup grup ini karena waktu tidur.';
        let text = 'System automatically closing this group because sleeping time.';
        await anya.groupSettingUpdate(data.id, 'announcement')
            .then((_) => anya.sendMessage(data.id, {
                text: text
            }, {
                quoted: func.fstatus('System Notification'),
                ephemeralExpiration: 86400
            }));
    }, false);

    scheduleTask('0 3 18 * * *', async (data) => {
        // let text = 'Sistem secara otomatis menutup grup ini karena waktu maghrib dan akan dibuka 20 menit dimulai dari sekarang.';
        let text = 'selamat menunaikan ibadah Sholat Maghrib bagi yang muslim...\n\n_untuk wilayah jakarta dan sekitarnya._';
        await anya.groupSettingUpdate(data.id, 'announcement')
            .then((_) => anya.sendMessage(data.id, {
                text: text
            }, {
                quoted: func.fstatus('System Notification'),
                ephemeralExpiration: 86400
            }));
    }, false);

    scheduleTask('0 20 18 * * *', async (data) => {
        // let text = 'Sistem otomatis membuka grup ini karena waktu maghrib telah usai.';
        let text = 'System automatically opening this group because maghrib time is over.';
        await anya.groupSettingUpdate(data.id, 'not_announcement')
            .then((_) => anya.sendMessage(data.id, {
                text: text
            }, {
                quoted: func.fstatus('System Notification'),
                ephemeralExpiration: 86400
            }));
    }, true);

    scheduleTask('0 30 23 * * *', async (data) => {
        // let text = 'Sistem akan secara otomatis menutup grup ini dalam waktu 30 menit dimulai dari sekarang.';
        let text = 'System will automatically close this group within 30 minutes starting from now.';
        await anya.sendMessage(data.id, {
            text: text
        }, {
            quoted: func.fstatus('System Notification'),
            ephemeralExpiration: 86400
        });
    }, false);

    scheduleTask('0 0 4 * * *', async (data) => {
        // let text = 'Sistem secara otomatis membuka grup ini karena pagi hari.';
        let text = 'System automatically opening this group because morning time.';
        await anya.groupSettingUpdate(data.id, 'not_announcement')
            .then((_) => anya.sendMessage(data.id, {
                text: text
            }, {
                quoted: func.fstatus('System Notification'),
                ephemeralExpiration: 86400
            }));
    }, true);

    const checkExpiredUsers = () => {
        let now = Date.now();
        for (let [id, user] of Object.entries(global.db.users)) {
            if (!user.banned && user.expired.user && now >= user.expired.user) {
                console.log('Expired User:', user.name);
                delete global.db.users[id];
            }
        }
    };

    const checkExpiredGroups = () => {
        let now = Date.now();
        for (let [id, group] of Object.entries(global.db.groups)) {
            if (group.expired && now >= group.expired) {
                console.log('Expired Group:', group.name);
                delete global.db.groups[id];
            }
        }
    };

    const checkExpiredPremium = async () => {
        let now = Date.now();
        for (let [id, user] of Object.entries(global.db.users)) {
            if (user.premium && user.expired.premium && now >= user.expired.premium) {
                await anya.sendMessage(id, {
                    text: `Your premium package has expired, thank you for buying and using our service`
                }, {
                    quoted: func.fstatus('System Notification'),
                    ephemeralExpiration: 86400
                });
                user.expired.premium = 0;
                user.premium = false;
                user.limit = setting.limit.free;
            }
        }
    };
    
    const checkExpiredVvip = async () => {
        let now = Date.now();
        for (let [id, user] of Object.entries(global.db.users)) {
            if (user.vvip && user.expired.vvip && now >= user.expired.vvip) {
                await anya.sendMessage(id, {
                    text: `Your vvip package has expired, thank you for buying and using our service`
                }, {
                    quoted: func.fstatus('System Notification'),
                    ephemeralExpiration: 86400
                });
                user.expired.vvip = 0;
                user.vvip = false;
                user.limit = setting.limit.free;
            }
        }
    };

    const checkExpiredJadibot = async () => {
        let now = Date.now();
        for (let [number, user] of Object.entries(global.db.users)) {
            if (user.jadibot && user.expired.jadibot && now >= user.expired.jadibot) {
                await anya.sendMessage(number, {
                    text: `Your jadibot package has expired, thank you for buying and using our service`
                }, {
                    quoted: func.fstatus('System Notification'),
                    ephemeralExpiration: 86400
                });
                user.expired.jadibot = 0;
                user.jadibot = false;
                const client = global.jadibot[number] ? global.jadibot[number] : Object.values(global.jadibot).find(v => v.user.id.split(':')[0] == number.replace(/[^0-9]/g, ''))
                let settings = global.db.jadibot.find(v => v.number === number)
                if (settings && typeof client !== 'undefined') {
                    delete global.jadibot[number];
                    settings.status = false;
                    await client.end();
                    client.ws.close();
                }
            }
        }
    };

    const checkExpiredBanned = async () => {
        let now = Date.now();
        for (let [id, user] of Object.entries(global.db.users)) {
            if (user.banned && user.expired.banned && now >= user.expired.banned) {
                await anya.sendMessage(id, {
                    text: `Banned berakhir, Jangan melanggar rules agar tidak dibanned lagi.`
                }, {
                    quoted: func.fstatus('System Notification'),
                    ephemeralExpiration: 86400
                });
                user.expired.banned = 0;
                user.banned = false;
            }
        }
    };
    
    const checkExpiredSewaNotice = async () => {
        try {
            let now = Date.now();
            for (let [id, group] of Object.entries(global.db.groups)) {
                if (group.sewa.status && group.sewa.notice && group.sewa.expired && !/(PERMANENT|Infinity|0)/.test(group.sewa.expired) && (now + 345600000) >= group.sewa.expired) {
                    const getGroups = await anya.groupFetchAllParticipating();
                    const groupData = Object.values(getGroups).map(item => item.id);
                    if (groupData.includes(id)) {
                        await anya.sendMessage(id, {
                            text: 'Masa sewa grup ini tersisa 4 hari, perpanjangan hanya berlaku jika masa aktif tersisa kurang dari 3 hari terimakasih.',
                            mentions: Object.values(group.member).map(v => v.jid)
                        }, {
                            quoted: func.fstatus('System Notification'),
                            ephemeralExpiration: 0
                        });
                    }
                    group.sewa.notice = false;
                }
            }
        } catch (error) {
            console.log(error);
            group.sewa.notice = false;
        }
    };

    const checkExpiredSewa = async () => {
        let now = Date.now();
        for (let [id, group] of Object.entries(global.db.groups)) {
            try {
                if (group.sewa.status && group.sewa.expired && group.sewa.expired != 0 && now >= group.sewa.expired) {
                    const getGroups = await anya.groupFetchAllParticipating();
                    const listGroups = Object.values(getGroups).map(item => item.id);
                    if (listGroups.includes(id)) {
                        await anya.sendMessage(id, {
                            text: 'Bot time has expired and will leave from this group, thank you.',
                            mentions: group.member.map(v => v.jid)
                        }, {
                            quoted: func.fstatus('System Notification'),
                            ephemeralExpiration: 86400
                        }).then(() => anya.groupLeave(id));
                    };
                    group.sewa.expired = 0;
                    group.sewa.status = false;
                    console.log('Expired Sewa:', group.name);
                    await new Promise(resolve => setTimeout(resolve, 3000));
                }
            } catch (error) {
                console.log(error)
                group.sewa.status = false;
                delete global.db.groups[id];
            }
        }
    }

    const scheduleTaskAlarm = async (item, group) => {
        const getGroups = await anya.groupFetchAllParticipating();
        const groupData = Object.values(getGroups);
        const fstatus = {
            key: {
                participant: '0@s.whatsapp.net',
                remoteJid: '0@s.whatsapp.net'
            },
            message: {
                conversation: 'Alarm Notification'
            }
        }
        groupData.forEach(async (metadata) => {
            const groupId = metadata.id;
            const isBotAdmin = checkBotAdmin(metadata.participants);
            const isAlarmOn = isBotAdmin && metadata.announce ? true : !isBotAdmin && !metadata.announce ? true : isBotAdmin && !metadata.announce ? true : false;
            if (groupId === group.jid && isAlarmOn) {
                const announce = {
                    'true': 'announcement',
                    'false': 'not_announcement'
                } [item.announce];
                const text = item.textAlarm.trim();
                const mentions = item.tagAll ? metadata.participants.map(x => x.id) : [];
                const expiration = metadata.ephemeralDuration || 0;
                console.log('item:', item);
                if (/announcement|not_announcement/.test(announce) && isBotAdmin) {
                    await anya.groupSettingUpdate(groupId, announce)
                        .then((_) => anya.sendMessage(groupId, {
                            text: text,
                            mentions: mentions
                        }, {
                            quoted: fstatus,
                            ephemeralExpiration: expiration
                        }));
                } else await anya.sendMessage(groupId, {
                    text: text,
                    mentions: mentions
                }, {
                    quoted: fstatus,
                    ephemeralExpiration: expiration
                });
            };
        });
    };

    const checkAlarmGroups = async () => {
        const groupData = Object.values(global.db.groups).filter(v => v.alarm && Array.isArray(v.alarm));
        for (let group of groupData) {
            group.alarm.forEach(async (item) => {
                const date = moment.tz(item.timeZone || 'Asia/Jakarta');
                const dayNow = date.format('dddd');
                const timeNow = date.format('HH:mm');
                const dayOfNumber = numberToDay(item.days);
                const isAlarmOn = item.days != null ? dayOfNumber.includes(dayNow) : (dayOfNumber === 'Every Day');
                if (item.status && isAlarmOn) {
                    let alarmId = `${group.jid}-${item.name}-${item.time}-${item.createdAt}`;
                    if (item.time === timeNow && !alarms.has(alarmId)) {
                        console.log('timeNow:', timeNow);
                        func.logFile(timeNow, 'alarm');
                        alarms.add(alarmId);
                        await scheduleTaskAlarm(item, group);
                        setTimeout(() => (alarms.delete(alarmId)), 1000 * 60);
                    }
                }
            })
            await new Promise(resolve => setTimeout(resolve, 3000));
        }
    }

    const checkExpiredPanel = async () => {
        let now = Date.now();
        const groupJid = '120363331944895057@g.us';
        for (let [id, server] of Object.entries(global.db.server)) {
            if (server.data && server.data.length > 0) {
                for (let i = 0; i < server.data.length; i++) {
                    if (server.data[i].expired <= now) {
                        await anya.sendMessage(id, {
                            text: `Your server (${server.data[i].username}) has expired and the server has been suspended.`,
                        }, {
                            quoted: func.fverified,
                            ephemeralExpiration: 0
                        }).then(() => {
                            anya.sendMessage(groupJid, {
                                text: `Server @${id.replace(/@.+/, '')} (${server.data[i].username}) has expired and the server has been suspended.`,
                                mentions: [id]
                            }, {
                                quoted: func.fverified,
                                ephemeralExpiration: 0
                            })
                        })
                        if (server.data[i].id != null) {
                            try {
                                await fetch(`${global.panelApi.domain}/api/application/servers/${server.data[i].id}/suspend`, {
                                    "method": "POST",
                                    "headers": {
                                        "Accept": "application/json",
                                        "Content-Type": "application/json",
                                        "Authorization": "Bearer " + global.panelApi.apikey,
                                    }
                                })
                            } catch (error) {
                                console.log(error)
                            }
                            server.data.splice(i, 1)
                        }
                    }
                    if (server.data.length === 0) {
                    await anya.groupParticipantsUpdate(groupJid, [id], 'remove');
                   }
                }
            }
        }
    };
    
    function checkBotAdmin(member) {
        const admins = member.filter(x => x.admin !== null)
        return !!admins.find(item => item.id === bot)
    }

    function selisihMenit(item, group, event) {
        let a = item.time;
        let b = group.timing.find(v => v.event === event).time;
        let waktuA = a.split(':').map(Number);
        let waktuB = b.split(':').map(Number);
        if (waktuB[0] < waktuA[0]) {
            waktuB[0] += 24;
        }
        let menitA = waktuA[0] * 60 + waktuA[1];
        let menitB = waktuB[0] * 60 + waktuB[1];
        let selisihMenit = Math.abs(menitB - menitA);
        return selisihMenit;
    }

    function numberToDay(item) {
        const days = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];

        // Jika item adalah string dan bukan angka
        if (typeof item === 'string') {
            // Mengembalikan array dari nama hari
            return days;
        }

        // Jika item tidak valid
        if (!item || (typeof item === 'number' && (item < 0 || item > 6))) {
            return 'Every Day';
        }

        // Jika item adalah array
        if (Array.isArray(item)) {
            let result = [];
            for (let i of item) {
                if (i >= 0 && i < days.length) {
                    result.push(days[i]);
                }
            }
            return result.length > 0 ? result : 'Every Day';
        }

        // Mengembalikan nama hari berdasarkan index
        return days[item];
    }

    // Fungsi untuk mengecek ulang tahun hari ini
    function checkBirthday(userBirthday) {
        const birthdayData = userBirthday.split('/');
        if (birthdayData.length < 2) return false;

        // Menggunakan moment untuk mendapatkan tanggal saat ini di zona waktu Asia/Jakarta
        const today = moment.tz('Asia/Jakarta');
        const currentDay = today.date();
        const currentMonth = today.month() + 1; // Bulan dimulai dari 0

        const [day, month] = birthdayData.map(Number); // Mengonversi ke angka

        if (day === currentDay && month === currentMonth) {
            return true;
        }
        return false;
    }

    // Fungsi untuk mengecek data grup yang bisa kirim pesan oleh bot
    function filteredGroupData(metadata) {
        const isBotAdmin = checkBotAdmin(metadata.participants);
        const result = isBotAdmin && metadata.announce ? true : !isBotAdmin && !metadata.announce ? true : isBotAdmin && !metadata.announce ? true : false;
        return result;
    }

    function getAgeFromDate(userBirthday) {
        const birthdayData = userBirthday.split('/');
        if (birthdayData.length < 3) return false;
        const [day, month, year] = birthdayData.map(Number); // Mengonversi ke angka
        let d = new Date
        let date = new Date(`${year}/${month}/${day}`)
        let ageD = new Date(d - date)
        let age = ageD.getFullYear() - new Date(1970, 0, 1).getFullYear()
        return age;
    }

    // Fungsi untuk mengecek user di semua grup
    async function checkUsersInAllGroups(userId) {
        const getGroups = await anya.groupFetchAllParticipating();
        const result = Object.values(getGroups)
            .filter(metadata => filteredGroupData(metadata) && metadata.participants.some(x => x.id.includes(userId)))
            .map(item => ({
                id: item.id,
                subject: item.subject,
                expiration: item.ephemeralDuration || 0
            }));

        return result;
    }

    const checkBirthdayUser = async () => {
        for (let [userId, user] of Object.entries(global.db.users)) {
            try {
                if (user.ultah && user.ultah.status && user.ultah.date && checkBirthday(user.ultah.date)) {
                    user.balance += 100000;
                    user.ultah.status = false;
                    const age = getAgeFromDate(user.ultah.date);
                    const groupData = await checkUsersInAllGroups(userId);
                    const caption = `Selamat ulang tahun yang *ke-${age}*, @${userId.replace(/@.+/, '')}! Di hari istimewa ini, aku ingin mengingatkan betapa berartinya kamu bagi banyak orang. Setiap senyummu, setiap ide kreatif yang kamu ciptakan, membawa kebahagiaan dan inspirasi bagi mereka yang ada di sekitarmu.

Di balik setiap senyummu, ada cerita yang tak terungkap, dan di balik setiap tawa, ada perjuangan yang telah kamu lalui. Ingatlah, setiap tahun yang berlalu adalah sebuah perjalanan yang penuh makna. Teruslah berkarya dan menjadi inspirasi bagi banyak orang di sekitarmu. 

Semoga cinta dan kebahagiaan selalu menyertaimu, dan jangan pernah ragu untuk menjadi diri sendiri. Selamat ulang tahun, ${global.db.users[userId].name}! 🌟✨`;
                    if (groupData.length > 0) {
                        for (let [index, data] of groupData.entries()) {
                            console.log(data);
                            try {
                                await anya.sendMessage(data.id, {
                                    text: caption,
                                    mentions: [userId]
                                }, {
                                    quoted: func.fstatus("System Notification"),
                                    ephemeralExpiration: data.expiration
                                });
                            } catch (error) {
                                console.log('Error sending birthday message:', error)
                            }
                            await new Promise(resolve => setTimeout(resolve, 10000 * index));
                        }
                    } else {
                        await anya.sendMessage(userId, {
                            text: caption,
                            mentions: [userId]
                        });
                    }
                }
            } catch (error) {
                console.log(error);
                user.balance += 100000;
                user.ultah.status = false;
            }
        }
    };
    
    const checkNewYear = async () => {
        const newYear = moment.tz('Asia/Jakarta').format('YYYY-MM-DD hh:mm:ss');
        let eventId = 'newyear'
        if (newYear === '2026-01-01 00:00:00' && !anya.event[eventId]) {
            anya.event[eventId] = true;
            const groupList = Object.values(await anya.groupFetchAllParticipating()).filter(x => x.participants.find(item => item.id == anya.user.jid && item.admin != null))
            const groupData = groupList.map(item => item.id);
            let mentions = [];
            groupList.map(({
                participants
            }) => participants.map(item => item.id)).map(userId => mentions.push(...userId));
            const imageBuffer = await func.fetchBuffer('https://files.catbox.moe/2o9l7w.jpg');
            const caption = `Selamat menyambut Tahun Baru 2025! Semoga di tahun yang baru ini, kita semua dapat menjadi pribadi yang lebih baik dari sebelumnya. Mari kita lupakan masa lalu yang kelam dan sambut masa depan dengan harapan dan semangat yang lebih baik. ayo kita wujudkan impian dan tujuan kita bersama.`
            for (let chatId of groupData) {
                await anya.sendMessage(chatId, {
                    image: imageBuffer,
                    caption: caption,
                    mentions: mentions
                }, {
                    quoted: func.fverified,
                    ephemeralExpiration: 0
                })
                await new Promise(resolve => setTimeout(resolve, 3000));
            }
        }
    };

    // Schedule checks
    setInterval(checkExpiredUsers, 10000);
    setInterval(checkExpiredGroups, 10000);
    setInterval(checkExpiredPremium, 10000);
    setInterval(checkExpiredVvip, 10000);
    setInterval(checkExpiredJadibot, 10000);
    setInterval(checkExpiredBanned, 10000);
    setInterval(checkExpiredSewaNotice, 10000);
    setInterval(checkExpiredSewa, 30000);
    setInterval(checkAlarmGroups, 10000);
    setInterval(checkExpiredPanel, 10000);
    setInterval(checkBirthdayUser, 10000);

}

func.reloadFile(__filename)