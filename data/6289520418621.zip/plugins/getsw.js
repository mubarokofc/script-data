exports.run = {
    usage: ['getsw'],
    use: 'reply story wa',
    category: 'owner',
    async: async (m, {
        func,
        anya
    }) => {
        if (!m.quoted || m.quoted?.chat !== 'status@broadcast') return m.reply('Reply story wa yang ingin disimpan!')
        let swdl = await m.quoted.download();
        let to = m.chat;
        if (/imageMessage/.test(m.quoted.mtype)) {
            await anya.sendMedia(to, swdl, m, {
                    caption: m.quoted.text ? m.quoted.text : '',
                    expiration: 0
                })
                .then(() => anya.sendMessage(m.chat, {
                    react: {
                        text: '✅',
                        key: m.key
                    }
                }))
                .catch((e) => anya.sendMessage(m.chat, {
                    react: {
                        text: '❌',
                        key: m.key
                    }
                }))
        } else if (/videoMessage/.test(m.quoted.mtype)) {
            await anya.sendMedia(to, swdl, m, {
                    caption: m.quoted.text ? m.quoted.text : '',
                    expiration: 0
                })
                .then(() => anya.sendMessage(m.chat, {
                    react: {
                        text: '✅',
                        key: m.key
                    }
                }))
                .catch((e) => anya.sendMessage(m.chat, {
                    react: {
                        text: '❌',
                        key: m.key
                    }
                }))
        } else if (/audioMessage/.test(m.quoted.mtype)) {
            await anya.sendMedia(to, swdl, m, {
                    caption: m.quoted.text ? m.quoted.text : '',
                    expiration: 0
                })
                .then(() => anya.sendMessage(m.chat, {
                    react: {
                        text: '✅',
                        key: m.key
                    }
                }))
                .catch((e) => anya.sendMessage(m.chat, {
                    react: {
                        text: '❌',
                        key: m.key
                    }
                }))
        } else if (/extendedTextMessage|conversation/.test(m.quoted.mtype)) {
            await anya.sendMessage(to, {
                    text: m.quoted.text
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                })
                .then(() => anya.sendMessage(m.chat, {
                    react: {
                        text: '✅',
                        key: m.key
                    }
                }))
                .catch((e) => anya.sendMessage(m.chat, {
                    react: {
                        text: '❌',
                        key: m.key
                    }
                }))
        }
    },
    owner: true
}