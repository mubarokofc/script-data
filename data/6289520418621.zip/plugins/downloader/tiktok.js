exports.run = {
    usage: ['tiktok'],
    hidden: ['tt'],
    use: 'link tiktok',
    category: 'downloader',
    async: async (m, { func, anya, isPrem }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'https://vt.tiktok.com/ZSF4cWcA2/'));
        if (!m.args[0].includes('tiktok.com')) return m.reply(global.mess.error.url);
        
        anya.sendReact(m.chat, '🕒', m.key);
        
        await func.tiktok(m.args[0]).then(res => {
            if (res.status == 400) return m.reply(mess.error.api);
            if (res.result.audio == undefined) return m.reply('itu tiktokslide tolol.');

            let txt = '乂  *TIKTOK - DOWNLOADER*\n';
            txt += `\n◦  *Title* : ${res.result.caption}`;
            txt += `\n◦  *Quality* : MEDIUM`;

            // Kirim pesan dengan video dan tombol
            anya.sendMessage(m.chat, {
                video: { url: res.result.medium },
                caption: txt,
                footer: global.footer,
                buttons: [
                    {
                        buttonId: m.prefix + `ttmp3 ${m.args[0]}`, // Menggunakan m.args[0] untuk mengirim link video
                        buttonText: {
                            displayText: 'Ambil Musiknya'
                        },
                        type: 1,
                    }
                ],
                headerType: 1,
                contextInfo: {
                    isForwarded: true,
                    forwardingScore: 9999,
                    mentionedJid: [m.sender], // Menambahkan pengirim ke dalam mentionedJid
                },
                viewOnce: true
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
        }).catch((err) => m.reply('Maaf terjadi kesalahan.'));
    },
    limit: 5
};