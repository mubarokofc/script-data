const axios = require('axios')
async function getAdzanTimes(city) {
const response = await axios.get(`https://api.alyachan.dev/api/jadwalsholat?q=${encodeURIComponent(city)}&apikey=${global.alya}`)
return response.data
}
function formatAdzanTimes(data) {
let result = ''
for (let key in data.data) {
if (key !== 'tgl' && key !== 'hijri' && key !== 'parameter') {
result += `◦ ${ucword(key)}: ${data.data[key]}\n`
}
}
return result.trim()
}
function ucword(str) {
return str.charAt(0).toUpperCase() + str.slice(1)
}
exports.run = {
usage: ['adzan'],
use: 'kota',
category: 'islamic',
async: async (m, { func, anya }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'Semarang'));
anya.sendReact(m.chat, '🕒', m.key)
const adzanData = await getAdzanTimes(m.text)
if (!adzanData || !adzanData.data) return
const formattedData = formatAdzanTimes(adzanData)
anya.reply(m.chat, formattedData, m)
anya.sendReact(m.chat, '✅', m.key)
}
}