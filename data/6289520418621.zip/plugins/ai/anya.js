const qs = require('qs');
const crypto = require('crypto');
const axios = require('axios');
const FormData = require('form-data');

const transcribe = async (audioBuffer, fileName) => {
    try {
        const formData = new FormData();

        // Menggunakan Buffer langsung
        formData.append('file', audioBuffer, {
            filename: fileName,
            contentType: 'audio/mpeg'
        });
        const config = {
            headers: {
                ...formData.getHeaders(),
                'authority': 'api.talknotes.io',
                'accept': '*/*',
                'accept-encoding': 'gzip, deflate, br',
                'origin': 'https://talknotes.io',
                'referer': 'https://talknotes.io/',
                'User-Agent': 'Postify/1.0.0'
            },
            maxBodyLength: Infinity
        };
        const response = await axios.post('https://api.talknotes.io/tools/converter', formData, config);
        return response.data;
    } catch (error) {
        if (error.response) {
            throw new Error(`${error.response.status}: ${error.response.data}`);
        } else if (error.request) {
            throw new Error('Failed to convert audio to text');
        } else {
            throw new Error(error.message);
        }
    }
}

const textAlert = '*[System Notice]* Pengguna gratis hanya diperbolehkan mengirim pertanyaan dengan maksimum 150 karakter.';

exports.run = {
    usage: ['anya'],
    hidden: ['anya-ai'],
    use: 'text',
    category: 'ai',
    async: async (m, {
        func,
        anya,
        users,
        errorMessage
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'Hai'))
        if (m.text.length > 150 && !m.isPrem) return m.reply(textAlert)
        anya.sendReact(m.chat, '🕒', m.key)
        try {
            let messageId = 'ANYA' + func.makeid(8).toUpperCase() + 'GPT'
            let response = await Lbbai(m.text, users.name.replaceAll('\n', '\t'))
            anya.sendMessage(m.chat, {
                text: `${response}`
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration,
                messageId: messageId
            });
        } catch (error) {
            anya.sendReact(m.chat, '❌', m.key)
            return errorMessage(error)
        }
    },
    main: async (m, {
        func,
        anya,
        users,
        quoted,
        errorMessage
    }) => {
        const sendVoiceMessage = async (jid, text) => {
            await tiktokTts(text, 'id_001').then(async result => {
                if (!result.success) return await anya.sendMessage(jid, {
                    text: text
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                });
                return await anya.sendMessage(jid, {
                    audio: result.base64,
                    mimetype: 'audio/mp4',
                    ptt: true
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                })
            })
        }

        if (m.budy && m.arg && /^anya$/i.test(m.arg[0])) {
            if (users.limit < 1) return m.reply(global.mess.limit)
            if (!m.text) return // m.reply('Halo! Ada yang bisa aku bantu hari ini?')
            if (m.text.length > 150 && !m.isPrem) return m.reply(textAlert)
            anya.sendReact(m.chat, '🕒', m.key)
            try {
                let messageId = 'ANYA' + func.makeid(8).toUpperCase() + 'GPT'
                let response = await Lbbai(m.text, users.name.replaceAll('\n', '\t'))
                anya.sendMessage(m.chat, {
                    text: `${response}`
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration,
                    messageId: messageId
                });
                users.limit -= 3;
                if (users.limit < 0) users.limit = 0;
            } catch (error) {
                anya.sendReact(m.chat, '❌', m.key)
                return errorMessage(error)
            }
        } else if (m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('GPT') && !m.isPrefix) {
            if (users.limit < 1) return m.reply(global.mess.limit);
            if (m.budy.length > 150 && !m.isPrem) return m.reply(textAlert)
            anya.sendReact(m.chat, '🕒', m.key)
            try {
                let messageId = 'ANYA' + func.makeid(8).toUpperCase() + 'GPT'
                //let messageId = 'BAE5' + func.makeid(9).toUpperCase() + 'GPT'
                let response = await Lbbai(m.budy, users.name.replaceAll('\n', '\t'), m.quoted.text)
                await tiktokTts(response, 'id_001').then(async result => {
                    if (!result.success) return anya.sendMessage(m.chat, {
                        text: `${response}`
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration,
                        messageId: messageId
                    });
                    await anya.sendMessage(m.chat, {
                        audio: result.base64,
                        mimetype: 'audio/mp4',
                        ptt: true
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration,
                        messageId: messageId
                    })
                })
                users.limit -= 3;
                if (users.limit < 0) users.limit = 0;
            } catch (error) {
                anya.sendReact(m.chat, '❌', m.key)
                return errorMessage(error)
            }
        }
        if (users.premium && /audio/.test(m.mime) && m.seconds < 9 && !m.fromMe) {
            anya.sendReact(m.chat, '🕒', m.key)
            try {
                let messageId = 'ANYA' + func.makeid(8).toUpperCase() + 'GPT'
                let media = await m.download();
                let result;
                try {
                    result = (await transcribe(media, func.filename('mp3'))).text;
                } catch (error) {
                    console.log(error);
                    return anya.sendReact(m.chat, '❌', m.key)
                }
                if (!result) return anya.sendReact(m.chat, '', m.key)
                console.log(result);
                // if (!/^(anya|anyu|anye|anyi|anja)/i.test(result)) return anya.sendReact(m.chat, '', m.key)
                const text = result; //.replace(/anya/g, '')
                if (m.isGc && m.isOwner && m.isAdmin && /tutup (grup|group)/i.test(text)) {
                    if (!m.isBotAdmin) return sendVoiceMessage(m.chat, 'maaf tuan, saya bukan admin di grup ini.')
                    await anya.groupSettingUpdate(m.chat, 'announcement')
                        .then((res) => sendVoiceMessage(m.chat, 'baik tuan, grup ini sudah saya tutup.'))
                        .catch((err) => sendVoiceMessage(m.chat, 'maaf tuan, terjadi kesalahan.'))
                    return false;
                } else if (m.isGc && m.isOwner && m.isAdmin && /buka (grup|group)/i.test(text)) {
                    if (!m.isBotAdmin) return sendVoiceMessage(m.chat, 'maaf tuan, saya bukan admin di grup ini.')
                    await anya.groupSettingUpdate(m.chat, 'not_announcement')
                        .then((res) => sendVoiceMessage(m.chat, 'baik tuan, grup ini sudah saya buka.'))
                        .catch((err) => sendVoiceMessage(m.chat, 'maaf tuan, terjadi kesalahan.'))
                    return false;
                }
                let response = await Lbbai(text, users.name.replaceAll('\n', '\t'))
                anya.sendMessage(m.chat, {
                    text: `${response}`
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration,
                    messageId: messageId
                });
            } catch (error) {
                console.error("Error in main function:", error);
                anya.sendReact(m.chat, '❌', m.key)
                /*return anya.reply(m.chat, error.message, m, {
                    expiration: m.expiration
                })*/
            }
        }
    },
    limit: 3,
    location: 'plugins/ai/anya.js'
}

function detectLanguage(text) {
    // Daftar kata dasar sederhana untuk bahasa Inggris dan Indonesia
    const englishWords = ['the', 'be', 'to', 'of', 'and', 'a', 'in', 'that', 'have', 'I'];
    const indonesianWords = ['dan', 'di', 'yang', 'ke', 'dari', 'ini', 'itu', 'dengan', 'untuk', 'sebagai'];

    let englishCount = 0;
    let indonesianCount = 0;

    const words = text.toLowerCase().split(/\s+/);

    words.forEach(word => {
        if (englishWords.includes(word)) {
            englishCount++;
        }
        if (indonesianWords.includes(word)) {
            indonesianCount++;
        }
    });

    return englishCount > indonesianCount ? 'en_us_001' : 'id_001';
}

function bersihkanInput(input) {
    // Ekspresi reguler untuk mencocokkan karakter yang diizinkan
    const regex = /[^a-zA-Z0-9.,! ]/g;
    // Mengganti semua karakter yang tidak diizinkan dengan string kosong
    const bersih = input.replace(regex, '');
    return bersih;
}


async function tiktokTts(text) {
    try {
        const modelVoice = detectLanguage(text);
        const input = bersihkanInput(text);
        const {
            status,
            data
        } = await axios('https://tiktok-tts.weilnet.workers.dev/api/generation', {
            method: "POST",
            data: {
                text: input,
                voice: modelVoice
            },
            headers: {
                "content-type": "application/json",
            },
        });
        return {
            success: true,
            creator: 'ZidanDev',
            base64: Buffer.from(data.data, "base64")
        }
    } catch (err) {
        console.log(err.response.data);
        return err.response.data;
    }
}

function generateUUIDv4() {
    return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c => (c ^ crypto.randomBytes(1)[0] & 15 >> c / 4).toString(16));
}

async function chatWithAI(text) {
    try {
        const conversation_uuid = generateUUIDv4();
        const requestData = {
            conversation_uuid: conversation_uuid,
            text: text,
            sent_messages: 1
        };

        const config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Accept': '*/*',
                'X-Requested-With': 'XMLHttpRequest'
            }
        };

        const response = await axios.post('https://www.timospecht.de/wp-json/cgt/v1/chat', qs.stringify(requestData), config);
        if (!response.data.success) return 'Terjadi kesalahan.'
        return response.data.data.message;
    } catch (error) {
        throw new Error('Terjadi kesalahan:', error);
    }
}

async function Lbbai(input, name, current) {
    const {
        dateNow,
        timeNow
    } = timeZone();
    let sistem = `Kamu adalah Anya, Bot WhatsApp dengan program kecerdasan buatan AI (artificial intelligence). Jawablah setiap pertanyaan dengan jawaban yang edukatif dan relevan. Jika ada yang bertanya tentang waktu, jawab dengan informasi yang berkaitan dengan waktu saat ini, yaitu ${timeNow}, dan hari ini adalah ${dateNow}. Lawan bicaramu adalah ${name}. Kamu memiliki sifat dingin dan sedikit imut. Kamu dirancang dan dikembangkan oleh ZidanDev sejak tahun 2021. ZidanDev memiliki nama lengkap Muhammad Zidan Mubarok, berasal dari Semarang, lahir pada 19 September 2009, makanan kesukaan ZidanDev adalah soto ayam, bakso, mie ayam, sate ayam, lumpia. dan dia adalah seseorang yang kreatif serta berbakat dalam menciptakan berbagai hal.`;
    if (current) sistem += `\n\nBerikan respons yang tidak hanya menjawab pertanyaan, tetapi juga mengaitkan jawabanmu dengan konteks dari percakapan sebelumnya. Jika ada konteks sebelumnya, gunakan itu untuk memperkaya jawabanmu: Sebelumnya, kamu telah membahas: ${current}`;
    try {
        const response = await axios.post("https://chateverywhere.app/api/chat/", {
            "model": {
                "id": "gpt-4",
                "name": "GPT-4",
                "maxLength": 32000, // Sesuaikan token limit jika diperlukan
                "tokenLimit": 8000, // Sesuaikan token limit untuk model GPT-4
                "completionTokenLimit": 5000, // Sesuaikan jika diperlukan
                "deploymentName": "gpt-4"
            },
            "messages": [{
                "pluginId": null,
                "content": input,
                "role": "user"
            }],
            "prompt": sistem,
            "temperature": 0.5
        }, {
            headers: {
                "Accept": "/*/",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            }
        });

        const result = response.data;
        return result;
    } catch (error) {
        function createPrompt(query) {
            return `${sistem}\nTolong jawab pertanyaan berikut dengan bahasa Indonesia gaul dan santai, sertakan juga emoticon lucu tapi seperlunya saja: ${query}`;
        }

        const prompt = createPrompt(input);
        const response = await fetch(`https://darkness.ashlynn.workers.dev/chat/?prompt=${encodeURIComponent(prompt)}&model=gpt-4o-mini`);
        const data = await response.json();

        if (data.successful === 'success' && data.response) {
            const apiResponse = data.response.trim();
            return apiResponse;
        } else {
            return 'Oops! Something went wrong. Please try again.';
        }
        return error.message;
    }
}

function timeZone() {
    const today = new Date();
    const date = new Date(today.toLocaleString("en-US", {
        timeZone: "Asia/Jakarta"
    }));
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const day = today.getDate();
    const month = today.getMonth() + 1; // perhatikan bahwa bulan dimulai dari 0, maka ditambahkan 1.
    const year = today.getFullYear();
    // mengambil nama hari dalam bahasa Inggris.
    const dayOfWeek = today.toLocaleDateString("id-ID", {
        weekday: "long"
    });
    const timeNow = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    return {
        dateNow: `${dayOfWeek}, ${day}/${month}/${year}`,
        timeNow: `${timeNow} WIB`
    }
}