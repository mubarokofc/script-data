const axios = require('axios');

exports.run = {
usage: ['gptpicture'],
use: 'query',
category: 'ai',
async: async (m, { func, anya }) => {
if (!m.text) return m.reply(func.example(m.cmd, '1 girls and boy'));
anya.sendReact(m.chat, '🕒', m.key)
try {
let data = await gptpicture(m.text)
if (!data.status) return m.reply(data.message)
let imgs = data.imgs;
for (let i = 0; i < imgs.length; i++) {
let result = imgs[i];
setTimeout(async () => {
anya.sendMedia(m.chat, result, m, {
caption: imgs.length == 1 ? global.mess.ok : `Images *(${i + 1}/${imgs.length})*`,
expiration: m.expiration
});
}, i * 1000);
}
} catch (error) {
return m.reply(String(error));
}
},
limit: true
}

async function gptpicture(query) {
const playod = {
captionInput: query,
captionModel: 'default',
};
try {
const response = await axios.post('https://chat-gpt.pictures/api/generateImage', playod, {
headers: {
Accept: '*/*',
'Content-Type': 'application/json',
'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36'
}
});
const data = response.data.imgs;
const result = {
status: true,
imgs: data,
};
return result;
} catch (error) {
const result = {
status: false,
message: String(error)
};
return result;
}
}