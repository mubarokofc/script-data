const fetch = require('node-fetch');

async function wwdgpt(prompt, name) {
const today = new Date();
const date = new Date(today.toLocaleString("en-US", {timeZone: "Asia/Jakarta"}));
const hours = date.getHours();
const minutes = date.getMinutes();
const day = today.getDate();
const month = today.getMonth() + 1; // perhatikan bahwa bulan dimulai dari 0, maka ditambahkan 1.
const year = today.getFullYear();
// mengambil nama hari dalam bahasa Inggris.
const dayOfWeek = today.toLocaleDateString("id-ID", { weekday: "long" });
const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
const getTodayDate = `Hari ini adalah ${dayOfWeek}, ${day}/${month}/${year}.`;
const sistem = `kamu adalah asisten berbahasa indonesia, namamu anya, Bot WhatsApp dengan program kecerdasan buatan AI. jawab setiap pertanyaan dengan jawaban yang edukatif, jika ada yang bertanya tentang waktu kamu jawab yang berkaitan dengan ${timeNow} dan ${getTodayDate}, lawan bicaramu adalah ${name}, kamu memiliki sifat dingin dan sedikit tsundere imut, kamu dirancang dan dikembangkan oleh SuryaDev sejak tahun 2021, SuryaDev memiliki nama lengkap Jabal Surya Ngalam, berasal dari Jepara, lahir pada 21 mei 2005, dia adalah seseorang yang kreatif dan berbakat dalam menciptakan berbagai hal.`
try {
const response = await fetch('https://wewordle.org/gptapi/v1/web/turbo', {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.1 Mobile/15E148',
},
body: JSON.stringify({
messages: [
{
content: sistem,
role: "assistant"
},
{
content: prompt,
role: "user"
}
]
}),
});
const data = await response.text();
return data?.message?.content;
} catch (error) {
console.error('Error:', error);
throw error;
}
}

exports.run = {
usage: ['wwdgpt'],
use: 'quesion',
category: 'ai',
async: async (m, { func, anya, users, errorMessage }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'Hai'))
anya.sendReact(m.chat, '🕒', m.key)
try {
let messageId = 'ANYA' + func.makeid(5).toUpperCase() + 'WWDGPT'
let response = await wwdgpt(m.text, users.name.replaceAll('\n', '\t'))
anya.sendMessage(m.chat, {text: `${response}`}, {quoted: m, ephemeralExpiration: m.expiration, messageId: messageId});
} catch (error) {
anya.sendReact(m.chat, '❌', m.key)
return errorMessage(error)
}
},
main: async (m, { func, anya, users, errorMessage }) => {
if (m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('WWDGPT') && !m.isPrefix) {
anya.sendReact(m.chat, '🕒', m.key)
try {
let messageId = 'ANYA' + func.makeid(5).toUpperCase() + 'WWDGPT'
let response = await wwdgpt(m.budy, users.name.replaceAll('\n', '\t'))
anya.sendMessage(m.chat, {text: `${response}`}, {quoted: m, ephemeralExpiration: m.expiration, messageId: messageId});
users.limit -= 5
} catch (error) {
anya.sendReact(m.chat, '❌', m.key)
return errorMessage(error)
}
}
},
limit: 5
}