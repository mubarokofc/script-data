const FormData = require('form-data');

async function processing(urlPath, method) {
return new Promise(async (resolve, reject) => {
let Methods = ["enhance", "recolor", "dehaze"];
Methods.includes(method) ? (method = method) : (method = Methods[0]);
let buffer,
Form = new FormData(),
scheme = "https" + "://" + "inferenceengine" + ".vyro" + ".ai/" + method;
Form.append("model_version", 1, {
"Content-Transfer-Encoding": "binary",
contentType: "multipart/form-data; charset=uttf-8",
});
Form.append("image", Buffer.from(urlPath), {
filename: "enhance_image_body.jpg",
contentType: "image/jpeg",
});
Form.submit({
url: scheme,
host: "inferenceengine" + ".vyro" + ".ai",
path: "/" + method,
protocol: "https:",
headers: {
"User-Agent": "okhttp/4.9.3",
Connection: "Keep-Alive",
"Accept-Encoding": "gzip",
},
},
function (err, res) {
if (err) reject();
let data = [];
res
.on("data", function (chunk, resp) {
data.push(chunk);
})
.on("end", () => {
resolve(Buffer.concat(data));
});
res.on("error", (e) => {
reject();
});
}
);
});
}

exports.run = {
usage: ['enhancer', 'recolor', 'hdr'],
use: 'reply photo',
category: 'ai',
async: async (m, { func, anya, quoted }) => {
switch (m.command) {
case 'enhancer':{
anya.enhancer = anya.enhancer ? anya.enhancer : {};
if (m.sender in anya.enhancer) return m.reply('Masih ada proses yang sedang dijalankan, silahkan tunggu.');
if (!quoted.mime) return m.reply(`Kirim/Reply gambar dengan caption ${m.cmd}`);
if (!/image\/(jpe?g|png|video)/.test(quoted.mime)) return m.reply(`Mime ${quoted.mime} tidak support`);
else anya.enhancer[m.sender] = true;
anya.sendReact(m.chat, '🕒', m.key)
let media = await quoted.download?.();
try {
const result = await processing(media, 'dehaze');
anya.sendMedia(m.chat, result, m, {
caption: global.mess.ok,
expiration: m.expiration
});
delete anya.enhancer[m.sender];
} catch (err) {
m.reply('Maaf terjadi kesalahan.');
delete anya.enhancer[m.sender];
}
}
break;
case 'recolor':{
anya.recolor = anya.recolor ? anya.recolor : {};
if (m.sender in anya.recolor) return m.reply('Masih ada proses yang sedang dijalankan, silahkan tunggu.');
if (!quoted.mime) return m.reply(`Kirim/Reply gambar dengan caption ${m.cmd}`);
if (!/image\/(jpe?g|png|video)/.test(quoted.mime)) return m.reply(`Mime ${quoted.mime} tidak support`);
else anya.recolor[m.sender] = true;
anya.sendReact(m.chat, '🕒', m.key)
let media = await quoted.download?.();
try {
const result = await processing(media, 'recolor');
anya.sendMedia(m.chat, result, m, {
caption: global.mess.ok,
expiration: m.expiration
});
delete anya.recolor[m.chat];
} catch (err) {
m.reply('Maaf terjadi kesalahan.');
delete anya.recolor[m.chat];
}
}
break;
case 'hdr':{
anya.hdr = anya.hdr ? anya.hdr : {};
if (m.sender in anya.hdr) return m.reply('Masih ada proses yang sedang dijalankan, silahkan tunggu.');
if (!quoted.mime) return m.reply(`Kirim/Reply gambar dengan caption ${m.cmd}`);
if (!/image\/(jpe?g|png|video)/.test(quoted.mime)) return m.reply(`Mime ${quoted.mime} tidak support`);
else anya.hdr[m.sender] = true;
anya.sendReact(m.chat, '🕒', m.key)
let media = await quoted.download?.();
try {
const result = await processing(media, 'enhance');
anya.sendMedia(m.chat, result, m, {
caption: global.mess.ok,
expiration: m.expiration
});
delete anya.hdr[m.sender];
} catch (err) {
m.reply('Maaf terjadi kesalahan.');
delete anya.hdr[m.sender];
}
}
break;
}
},
premium: true
}