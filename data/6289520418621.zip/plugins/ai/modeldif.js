const fetch = require('node-fetch')

exports.run = {
usage: ['modeldif'],
use: 'number',
category: 'searching',
async: async (m, { func, anya, errorMessage }) => {
let [satu, dua, tiga] = m.args;
if (!func.isNumber(satu)) return m.reply(func.example(m.cmd, '1 1 1'))
if (!func.isNumber(dua)) return m.reply(func.example(m.cmd, '1 1 1'))
if (!func.isNumber(tiga)) return m.reply(func.example(m.cmd, '1 1 1'))
anya.sendReact(m.chat, '🕒', m.key)
try {
let result = await fetch('https://civitai.com/api/v1/models').then(x => x.json())
if (satu > result.items.length) return m.reply(`Hanya terdapat *${result.items.length}* items.`)
let items = result.items[satu];
if (dua > items.modelVersions.length) return m.reply(`Hanya terdapat *${items.modelVersions.length}* modelVersions.`)
let modelVersions = items.modelVersions[dua];
if (dua > modelVersions.images.length) return m.reply(`Hanya terdapat *${modelVersions.images.length}* images.`)
let images = modelVersions.images[tiga];
let txt = `${images.id}`
txt += `\n> Nsfw Level : ${images.nsfwLevel}`
txt += `\n> Width : ${images.width}`
txt += `\n> Height : ${images.height}`
txt += `\n> Hash : ${images.hash}`
if (images.type === 'image') {
anya.sendMessage(m.chat, {
image: {
url: images.url
}, 
caption: txt
}, {quoted: m, ephemeralExpiration: m.expiration})
} else anya.sendMedia(m.chat, images.url, m, {caption: txt, expiration: m.expiration})
} catch (e) {
anya.reply(m.chat, 'Tidak dapat menemukan apa yang kamu cari.', m, {expiration: m.expiration})
return errorMessage(e)
}
},
limit: true
}