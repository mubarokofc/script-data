exports.run = {
usage: ['nevo'],
hidden: ['nevoai'],
use: 'question',
category: 'ai',
async: async (m, { func, anya }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'siapa namamu?'))
anya.sendReact(m.chat, '🕒', m.key);
let data = await func.fetchJson(`https://ai.nevolution.team/nevo?apikey=akbarrdev&prompt=${m.text}`)
if (!data.status) return m.reply(global.mess.error.api)
m.reply(`${data.result}`)
},
limit: true
}