const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');
const fetch = require('node-fetch');
const crypto = require('crypto');

const gender = ['male', 'female'];
const templateType = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22'];

const caricaturer = {
    create: async (image, type = "11", prompt = "Disney girl style, 1boy, disney full body, cute face, detailed eyes, curvy body, full lips, blonde hair, mountain nature background, language", templateId = "21", sex = "female") => {
        if (!gender.includes(sex)) {
            throw new Error(`gender ${sex} tidak tersedia. Pilih salah satu: ${gender.join(', ')}`);
        }
        if (!templateType.includes(templateId)) {
            throw new Error(`template type ${templateId} tidak tersedia. Pilih salah satu: ${templateType.join(', ')}`);
        }

        const url = 'https://photoai.imglarger.com/api/PhoAi/Upload';

        const headers = {
            'Accept': 'application/json, text/plain, */*',
            'Origin': 'https://www.caricaturer.io',
            'Referer': 'https://www.caricaturer.io/',
            'User-Agent': 'Postify/1.0.0',
        };

        const form = new FormData();
        if (typeof image === 'string') {
            if (image.startsWith('http')) {
                const response = await fetch(image);
                const buffer = await response.buffer();
                form.append('file', buffer, `image_${crypto.randomBytes(8).toString('hex')}.jpg`);
            } else {
                form.append('file', fs.createReadStream(image), `image_${crypto.randomBytes(8).toString('hex')}.jpg`);
            }
        } else if (Buffer.isBuffer(image)) {
            form.append('file', image, `image_${crypto.randomBytes(8).toString('hex')}.jpg`);
        } else {
            throw new Error('input image tidak valid.');
        }

        form.append('type', type);
        form.append('prompt', prompt);
        form.append('templateId', templateId);
        form.append('sex', sex);

        try {
            const response = await axios.post(url, form, {
                headers: {
                    ...headers,
                    ...form.getHeaders()
                },
            });
            return {
                code: response.data.data.code,
                type: response.data.data.type
            };
        } catch (error) {
            console.error(error.message);
        }
    },

    checkStatus: async (code, type) => {
        const url = 'https://photoai.imglarger.com/api/PhoAi/CheckStatus';
        const headers = {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json',
            'Origin': 'https://www.caricaturer.io',
            'Referer': 'https://www.caricaturer.io/',
            'User-Agent': 'Postify/1.0.0',
        };

        const data = {
            code: code,
            type: type,
        };

        try {
            let status = 'waiting';
            while (status === 'waiting') {
                const response = await axios.post(url, data, {
                    headers
                });
                status = response.data.data.status;
                if (status === 'success') {
                    console.log('Link Image: ', response.data);
                    return response.data.data.downloadUrls[0];
                }
                await new Promise(resolve => setTimeout(resolve, 5000));
            }
        } catch (error) {
            console.error(error.message);
        }
    },
};

exports.run = {
    usage: ['ai-image'],
    hidden: ['ai-img'],
    use: 'input image',
    category: 'ai',
    async: async (m, {
        func,
        anya,
        quoted
    }) => {
        const splitter = '\n';
        if (!m.text) return m.reply(func.example(m.cmd, `11${splitter}Disney girl style, 1boy, disney full body, cute face, detailed eyes, curvy body, full lips, blonde hair, mountain nature background, language${splitter}21${splitter}female`))
        let [type, prompt, templateId, sex] = m.text.split(splitter);
        if (!type) type = '11';
        if (!prompt) promt = 'Disney girl style, 1boy, disney full body, cute face, detailed eyes, curvy body, full lips, blonde hair, mountain nature background, language';
        if (!templateId) templateId = '21';
        if (!sex) sex = 'female';
        if (!gender.includes(sex)) {
            return m.reply(`gender \`${sex}\` tidak tersedia. Pilih salah satu: ${gender.join(', ')}`);
        }
        if (!templateType.includes(templateId)) {
            return m.reply(`template id \`${templateId}\` tidak tersedia. Pilih salah satu: ${templateType.join(', ')}`);
        }
        if (/image\/(jpe?g|png)/.test(quoted.mime)) {
            anya.sendReact(m.chat, '🕒', m.key)
            try {
                let buffer = await quoted.download();
                let result = await caricaturer.create(buffer, type, prompt, templateId, sex)
                let imageUrl = await caricaturer.checkStatus(result.code, result.type)
                anya.sendMedia(m.chat, imageUrl, m, {
                    expiration: m.expiration,
                    caption: global.mess.ok
                })
            } catch (error) {
                console.log(error)
                anya.reply(m.chat, error.message, m, {
                    expiration: m.expiration
                })
            }
        } else m.reply(`Reply gambar dengan caption ${m.cmd}`)
    },
    limit: true
}