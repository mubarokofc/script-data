const axios = require('axios');
exports.run = {
usage: ['todisney'],
use: 'reply photo',
category: 'ai',
async: async (m, { func, anya, quoted }) => {
if (!quoted || !/image/.test(quoted.mime)) return m.reply('Input media dengan benar! Hanya gambar yang diizinkan.');
anya.sendReact(m.chat, '🕒', m.key);
try {
const media = await anya.downloadAndSaveMediaMessage(quoted);
const anu = await func.UploadFileUgu(media);
const resultUrl = await processToDisney(anu.url);
await anya.sendMessage(m.chat, { image: { url: resultUrl }, caption: global.mess.ok }, { quoted: m });
anya.sendReact(m.chat, '✅', m.key);
} catch (error) {
anya.sendReact(m.chat, '❌', m.key);
}
},
limit: true
};
async function processToDisney(imageUrl) {
const apiUrl = `https://api.nyxs.pw/ai-image/jadidisney?url=${encodeURIComponent(imageUrl)}`;
const { data } = await axios.get(apiUrl);
if (data?.status === true) return data.result;
throw new Error('Pemrosesan gagal.');
}