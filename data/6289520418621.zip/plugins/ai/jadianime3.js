const axios = require('axios');
const FormData = require('form-data');
const {
    fromBuffer
} = require('file-type');

async function tmpfiles(buffer) {
    const {
        ext,
        mime
    } = (await fromBuffer(buffer)) || {};
    const form = new FormData();
    form.append("file", buffer, {
        filename: `tmp.${ext}`,
        contentType: mime
    });
    try {
        const {
            data
        } = await axios.post("https://tmpfiles.org/api/v1/upload", form, {
            headers: form.getHeaders()
        });
        const match = /https?:\/\/tmpfiles.org\/(.*)/.exec(data.data.url);
        return `https://tmpfiles.org/dl/${match[1]}`;
    } catch (error) {
        return false;
    }
}

exports.run = {
    usage: ['jadianime3'],
    hidden: ['toanime3'],
    use: 'reply photo',
    category: 'ai',
    async: async (m, {
        func,
        anya,
        quoted
    }) => {
        if (/image\/(jpe?g|png)/.test(quoted.mime)) {
            anya.sendReact(m.chat, '🕒', m.key);
            let media = await quoted.download();
            let imageUrl = await tmpfiles(media);
            try {
                let url = `https://api.ryzendesu.vip/api/ai/toanime?url=${imageUrl}`;
                // let url = `https://api.botwa.riooxdzz.me/api/maker/convertanime?url=${imageUrl}&apikey=freekey`;
                await anya.sendMedia(m.chat, url, m, {
                    expiration: m.expiration
                })
            } catch (e) {
                await anya.reply(m.chat, e.message, m, {
                    expiration: m.expiration
                })
            }
        } else m.reply(`Kirim/Reply foto dengan caption ${m.cmd}`)
    },
    premium: true,
    location: 'plugins/ai/jadianime3.js'
}