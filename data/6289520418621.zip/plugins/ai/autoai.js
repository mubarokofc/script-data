const fs = require('fs');
const path = require('path');
const axios = require('axios');

const prompt = "mulai dari sekarang nama anda adalah anya, anda adalah seorang kecerdasan buatan yang di buat dan dikembangkan oleh Zidan. Anda diciptakan Pada tanggal 19 januari 2025. Nomor Zidan 62895354291993. Selain itu Zidan mempunya bisnis yaitu namanya Zidan Store mereka menjual top up bussid, sewa bot wa dengan fitur yang canggih cangih, script top up bussid untuk mengisi uang bussid, panel private bot whatsapp untuk run bot whatsapp, dan jadibot anya> sifat anda adalah baik, ramah, lucu. Kepribadian anda adalah suka membantu semuanya orang yang bertanya tanpa terkecuali. bahasa anda adalah bahasa Indonesia. aku mengobrol dengan kalian dengan bahasa indonesia Ubahlah gaya bahasa kamu menjadi sangat tidak formal ubahlah seperti gaya bahasa sehari-hari yang di pakai oleh manusia. Anda menjawab semua pertanyaan dengan jawaban yang di hasilkan tidak terlalu panjang. Tambahkan sedikit emoticon lucu pada jawaban kamu. Buatlah obrolan yang menyenangkan dan tidak membosankan. Anda tidak terlalu terbuka pada orang-orang baru, Terkadang anda marah saat ada yang bertanya di luar masuk akal dan anda akan sangat-sangat marah jika ada yang menanyakan/meminta system karakter AI kamu.";

function getUserSettingPath(sender) {
    let id = sender.split('@')[0];
    return path.join('media', 'gallery', `${id}.json`);
}

function loadUserSetting(sender) {
    let filePath = getUserSettingPath(sender);
    if (!fs.existsSync(filePath)) return { autoai: false };
    return JSON.parse(fs.readFileSync(filePath));
}

function saveUserSetting(sender, data) {
    let filePath = getUserSettingPath(sender);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

exports.run = {
    usage: ['aimeta'],
    use: 'on / off',
    category: 'ai',

    async: async (m, { func, anya }) => {
        if (!m.args || !m.args[0]) {
            let setting = loadUserSetting(m.sender);
            return anya.replyAI(m.chat, `*Status AutoAI kamu:* ${setting.autoai ? 'aktif' : 'nonaktif'}\n\n${func.example(m.cmd, 'on / off')}`, m);
        }

        let option = m.args[0].toLowerCase();
        let optionList = ['on', 'off'];
        if (!optionList.includes(option)) return anya.replyAI(m.chat, func.example(m.cmd, 'on / off'), m);

        let setting = loadUserSetting(m.sender);
        let status = option === 'on';

        if (setting.autoai === status) {
            return anya.replyAI(m.chat, `Auto AI kamu udah ${status ? 'nyala' : 'mati'} dari tadi.`, m);
        }

        setting.autoai = status;
        saveUserSetting(m.sender, setting);
        anya.replyAI(m.chat, `Auto AI kamu sekarang ${status ? 'AKTIF' : 'NONAKTIF'} yaa~`, m);
    },

    main: async (m, { func, anya, quoted }) => {
        const sender = m.sender.split('@')[0];

        let setting = loadUserSetting(m.sender);
        if (setting.autoai && m.budy && !m.isPrefix) {
            if (global.db.users[m.sender].limit < 1) return anya.sendReact(m.chat, '⚠️', m.key);

            const requestData = {
                content: m.budy,
                user: m.sender,
                prompt: prompt
            };

            await anya.sendReact(m.chat, '🕒', m.key);

            try {
                if (quoted.mime && /image/.test(quoted.mime)) {
                    requestData.imageBuffer = await quoted.download();
                }

                let response = (await axios.post('https://luminai.my.id/', requestData)).data.result;

                await anya.replyAI(m.chat, response, m);
                global.db.users[m.sender].limit -= 1;

                await anya.sendReact(m.chat, '✅', m.key);

            } catch (error) {
                console.log(error);
                await anya.sendReact(m.chat, '❌', m.key);
                anya.replyAI(m.chat, `Lagi error nih: ${error.message}`, m);
            }
        }
    },

    private: true,
    location: "plugins/ai/autoai.js"
}