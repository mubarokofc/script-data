const { G4F } = require("g4f");
const g4f = new G4F();

exports.run = {
usage: ['gpt4'],
hidden: ['g4f'],
use: 'question',
category: 'ai',
async: async (m, { func, anya }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'apakah kamu gpt4?'));
anya.sendReact(m.chat, '🕒', m.key);
try {
const options = [{ model: "gpt-4" }];
const today = new Date();
const date = new Date(today.toLocaleString("en-US", {timeZone: "Asia/Jakarta"}));
const hours = date.getHours();
const minutes = date.getMinutes();
const day = today.getDate();
const month = today.getMonth() + 1; // perhatikan bahwa bulan dimulai dari 0, maka ditambahkan 1.
const year = today.getFullYear();
// mengambil nama hari dalam bahasa Inggris.
const dayOfWeek = today.toLocaleDateString("id-ID", { weekday: "long" });
const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
const getTodayDate = `Hari ini adalah ${dayOfWeek}, ${day}/${month}/${year}.`;
const sistem = `kamu Adalah Anya, Bot WhatsApp dengan program kecerdasan buatan AI (artificial intelligence). jawab setiap pertanyaan dengan jawaban yang edukatif, jika ada yang bertanya tentang waktu kamu jawab yang berkaitan dengan ${timeNow} dan ${getTodayDate}, lawan bicaramu adalah ${name}, kamu memiliki sifat dingin dan sedikit tsundere imut, kamu dirancang dan dikembangkan oleh SuryaDev sejak tahun 2021, ZidanDev memiliki nama lengkap Muhammad Zidan Mubarok, berasal dari Semarang, lahir pada 19 september 2009, dia adalah seseorang yang kreatif dan berbakat dalam menciptakan berbagai hal.`
const messages = [
{ role: "system", content: sistem },
{ role: "user", content: m.text },
];
let response = await g4f.chatCompletion(messages, options);
response = response.replace(/\\n/g, '\n').replace(/\\/g, '').replace(/\*\*/g, '*').replace(/###/g, '>').trim();
anya.reply(m.chat, response, m, {
expiration: m.expiration
});
} catch (error) {
console.error(error);
return anya.reply(m.chat, `Terjadi kesalahan: ${String(error)}`, m);
}
},
limit: true
}