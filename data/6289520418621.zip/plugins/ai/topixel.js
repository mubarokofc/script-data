const axios = require('axios');
exports.run = {
usage: ['topixel'],
use: 'reply photo',
category: 'ai',
async: async (m, { func, anya, quoted }) => {
if (!/image/.test(quoted.mime)) return m.reply('Input media dengan benar! Hanya gambar yang diizinkan.');
anya.sendReact(m.chat, '🕒', m.key);
try {
const media = await anya.downloadAndSaveMediaMessage(quoted);
const anu = await func.UploadFileUgu(media);
const resultUrl = await processToPixel(anu.url);
await anya.sendMessage(m.chat, { image: { url: resultUrl }, caption: global.mess.ok }, { quoted: m });
anya.sendReact(m.chat, '✅', m.key);
} catch (error) {
anya.sendReact(m.chat, '❌', m.key);
m.reply('Maaf, terjadi kesalahan saat memproses gambar.');
}
},
limit: true
};
async function processToPixel(imageUrl) {
const apiUrl = `https://api.alyachan.dev/api/topixel?image=${encodeURIComponent(imageUrl)}&apikey=${global.alya}`;
const { data } = await axios.get(apiUrl);
if (data?.status === true) return data.data.url;
throw new Error('Pemrosesan gagal.');
}