function calculateTimeSinceLastSync(lastAccountSyncTimestamp) {
    const now = Date.now(); // Get current time in milliseconds
    const lastSyncTime = lastAccountSyncTimestamp * 1000; // Convert seconds to milliseconds

    const timeDifferenceMs = now - lastSyncTime;

    return timeDifferenceMs;
}

// For a more human-readable format, you can convert the milliseconds to other units:
function formatTimeDifference(milliseconds) {
    const seconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    const remainingHours = hours % 24;
    const remainingMinutes = minutes % 60;
    const remainingSeconds = seconds % 60;

    let formattedTime = "";

    if (days > 0) {
        formattedTime += `${days} hari `;
    }
    if (remainingHours > 0) {
        formattedTime += `${remainingHours} jam `;
    }
    if (remainingMinutes > 0) {
        formattedTime += `${remainingMinutes} menit `;
    }
    formattedTime += `${remainingSeconds} detik`;

    return formattedTime;
}


exports.run = {
    usage: ['lastsync'],
    desc: 'menampilkan sinkronisasi terakhir',
    category: 'special',
    async: async (m, {
        func,
        anya
    }) => {
        // Example usage with your provided timestamp:
        const lastAccountSyncTimestamp = anya?.authState?.creds?.lastAccountSyncTimestamp;
        if (!lastAccountSyncTimestamp) return m.reply('lastAccountSyncTimestamp not found.');
        const timeDifference = calculateTimeSinceLastSync(lastAccountSyncTimestamp);
        console.log(`Time difference in milliseconds: ${timeDifference}`);
        const formattedDifference = formatTimeDifference(timeDifference);
        anya.reply(m.chat, `Time since last sync: ${formattedDifference}`, m, {
            expiration: m.expiration
        })
    }
}