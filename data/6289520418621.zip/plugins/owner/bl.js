const fs = require('fs');
const blacklistFile = './database/blacklist.json';

exports.run = {
  async main(m, { anya }) {
    const chatId = m.chat;

    try {
      // Pastikan file blacklist ada
      if (!fs.existsSync(blacklistFile)) {
        return; // Jika file tidak ada, biarkan
      }

      const blacklistData = JSON.parse(fs.readFileSync(blacklistFile, 'utf8'));

      // Cek apakah pengirim ada dalam blacklist
      if (blacklistData.blacklistedUsers.includes(m.sender)) {
        // Hapus pesan yang dikirim oleh pengguna yang ada dalam blacklist
        await anya.sendMessage(chatId, {
          delete: {
            remoteJid: chatId,
            fromMe: false,
            id: m.key.id,
            participant: m.sender,
          },
        });
      }
    } catch (err) {
      console.error("Terjadi kesalahan saat memproses blacklist:", err);
    }
  },
  group: true, // Hanya berfungsi di grup
  botAdmin: true, // Bot harus menjadi admin untuk menghapus pesan
};