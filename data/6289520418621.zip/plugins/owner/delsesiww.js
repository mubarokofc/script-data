exports.run = {
  usage: ['delsesiww'],
  category: 'owner',
  async: async (m, { func, anya }) => {
    // Cek apakah user adalah owner
    if (!m.isOwner) return m.reply('Fitur ini hanya bisa digunakan oleh Owner.');

    // Ambil data werewolf di database
    if (!global.db || !global.db.werewolf) return m.reply('Tidak ada sesi Werewolf yang ditemukan di database.');

    let werewolfSessions = Object.keys(global.db.werewolf);
    if (werewolfSessions.length === 0) return m.reply('Tidak ada sesi Werewolf yang aktif untuk dihapus.');

    // Hapus semua sesi werewolf
    werewolfSessions.forEach(session => {
      delete global.db.werewolf[session];
    });

    // Konfirmasi ke owner
    m.reply(`Semua sesi permainan Werewolf berhasil dihapus.\nJumlah sesi yang dihapus: *${werewolfSessions.length}*`);
  },
  owner: true
};