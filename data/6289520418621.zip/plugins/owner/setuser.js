const fs = require('fs');

// Fungsi untuk memperbarui database
function updateDatabase() {
    const filePath = "./database/database.json";
    let database;

    try {
        const data = fs.readFileSync(filePath);
        database = JSON.parse(data);
    } catch (error) {
        console.error("Error reading the database file:", error);
        return;
    }

    // Menyimpan kembali ke file
    try {
        fs.writeFileSync(filePath, JSON.stringify(database, null, 2));
        console.log("Database updated successfully!");
    } catch (error) {
        console.error("Error writing to the database file:", error);
    }
}

exports.run = {
    usage: ['setuser'],
    hidden: ['setuserstatus'],
    use: 'Nama,umur,gender',
    category: 'owner',
    async: async (m, { func, anya, setting }) => {
        // Cek apakah pengguna adalah developer
        if (!m.isOwner) return m.reply("Fitur Ini Hanya Bisa Digunakan Oleh Developer");

        const args = m.text.split(',');
        if (args.length !== 3) {
            return m.reply(`Format yang benar: ${m.prefix}setuser Nama,umur,gender\nContoh: ${m.prefix}setuser Zidan,17,male`);
        }

        const name = args[0].trim();
        const age = parseInt(args[1].trim());
        const gender = args[2].trim().toLowerCase();

        if (isNaN(age) || age <= 0) {
            return m.reply('Umur harus berupa angka positif.');
        }

        if (gender !== 'male' && gender !== 'female') {
            return m.reply('Gender harus berupa "male" atau "female".');
        }

        // Cek apakah ada pesan yang dibalas
        if (!m.quoted || !m.quoted.sender) {
            return m.reply('Silakan reply pesan pengguna yang ingin diubah datanya.');
        }

        const userId = m.quoted.sender; // Mengambil ID pengguna yang dibalas
        const userData = {
            name: name,
            age: age,
            gender: gender === 'male' ? 'Laki-laki' : 'Perempuan',
            sender: userId, // Menyimpan ID pengguna yang dibalas
            register: true // Menambahkan status register: true
        };

        // Memperbarui global.db
        if (!global.db.users[userId]) {
            // Jika pengguna yang dibalas belum ada, buat entri baru
            global.db.users[userId] = {};
        }

        // Memperbarui data pengguna yang sudah ada
        global.db.users[userId].name = userData.name;
        global.db.users[userId].age = userData.age;
        global.db.users[userId].gender = userData.gender;
        global.db.users[userId].register = userData.register; // Menambahkan status register

        // Memperbarui file database
        updateDatabase();

        // Mengirimkan konfirmasi dengan mention
        await m.reply(`Data pengguna yang dibalas telah diperbarui:\n⋄ Nama: ${name}\n⋄ Umur: ${age}\n⋄ Gender: ${gender === 'male' ? 'Laki-laki' : 'Perempuan'}`, { mentions: [userId] });
    }
};