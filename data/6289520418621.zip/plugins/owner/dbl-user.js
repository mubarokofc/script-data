const fetch = require('node-fetch');

const pwnya = 'https://raw.githubusercontent.com/ZidanStoreOfc/anya/refs/heads/main/database/listusers.json?token=GHSAT0AAAAAAC5YBZJNBSXKXYJVIMILVSCGZ7I47TQ';
const githubToken = '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'; // Ganti dengan token GitHub Anda
const repoOwner = 'ZidanStoreOfc'; // Ganti dengan pemilik repositori Anda
const repoName = 'anya'; // Ganti dengan nama repositori Anda
const filePath = 'database/listusers.json'; // Ganti dengan path file JSON Anda

let users = []; // Array untuk menyimpan data pengguna
let blacklist = []; // Array untuk menyimpan username yang diblacklist

// Fungsi untuk mengambil data dari GitHub
const fetchData = async (url) => {
    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to fetch data from GitHub');
    return await response.json();
};

// Fungsi untuk menyimpan data ke GitHub
const saveData = async (data) => {
    const response = await fetch(`https://api.github.com/repos/${repoOwner}/${repoName}/contents/${filePath}`, {
        method: 'PUT',
        headers: {
            'Authorization': `token ${githubToken}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            message: 'Update users and blacklist',
            content: Buffer.from(JSON.stringify(data, null, 2)).toString('base64'),
            sha: await getFileSha() // Mendapatkan SHA file untuk update
        })
    });
    if (!response.ok) throw new Error('Failed to save data to GitHub');
    return response.json();
};

// Fungsi untuk mendapatkan SHA dari file
const getFileSha = async () => {
    const response = await fetch(`https://api.github.com/repos/${repoOwner}/${repoName}/contents/${filePath}`, {
        headers: {
            'Authorization': `token ${githubToken}`
        }
    });
    if (!response.ok) throw new Error('Failed to get file SHA');
    const data = await response.json();
    return data.sha;
};

// Mengambil data pengguna dan blacklist dari GitHub saat bot dimulai
const initializeData = async () => {
    try {
        const data = await fetchData(pwnya);
        users = data.users || []; // Mengambil data pengguna dari file JSON
        blacklist = data.blacklist || []; // Mengambil blacklist dari file JSON
    } catch (error) {
        console.error('Error initializing data:', error);
    }
};

// Memanggil fungsi untuk inisialisasi data
initializeData();

// Command untuk menghapus username dari blacklist
exports.run = {
    usage: ['dbl-user'],
    use: 'username',
    category: 'owner',
    async: async (m, { anya, froms }) => {
        const args = m.text.split(' ');
        const usernameToRemove = args[0]; // Mengambil username dari argumen

        // Validasi input username
        if (!usernameToRemove) {
            return m.reply('Silakan masukkan username yang ingin dihapus dari blacklist.');
        }

        // Normalisasi input username
        const normalizedUsername = usernameToRemove.trim();

        // Cek apakah username ada di blacklist
        const index = blacklist.indexOf(normalizedUsername);
        if (index === -1) {
            return m.reply(`Username "${usernameToRemove}" tidak ditemukan di blacklist.`);
        }

        // Menghapus username dari blacklist
        blacklist.splice(index, 1);

        // Simpan data pengguna dan blacklist ke GitHub
        try {
            await saveData({ users, blacklist }); // Simpan data ke GitHub
                        return m.reply(`Username "${usernameToRemove}" telah dihapus dari blacklist.`);
        } catch (error) {
            console.error('Error saving data:', error);
            return m.reply('Terjadi kesalahan saat menyimpan data ke GitHub.');
        }
    },
    devs: true
};

// Inisialisasi data saat bot dimulai
initializeData();