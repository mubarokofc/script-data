exports.run = {
    usage: ['setreedem'],
    use: 'code',
    category: 'owner',
    async: async (m, { func, anya, froms, setting }) => {
        if (!m.isDevs) return m.reply(global.mess.devs);
        
        db.redeem = db.redeem || {
            isRedeem: false,
            code: "",
            user: [],
            maxRedeem: 0
        };
        
        if (!m.args[0]) return m.reply(`*Masukin Kode Redeemnya!*\n\nContoh:\n${m.cmd} epep 10`);
        if (!m.args[1]) return m.reply(`*Masukin Jumlah Tersedia!*\n\nContoh:\n${m.cmd} epep 10`);
        if (isNaN(m.args[1])) return m.reply(`*Jumlah Harus Angka!*\n\nContoh:\n${m.cmd} epep 10`);
        
        db.redeem.isRedeem = true;
        db.redeem.code = m.args[0];
        db.redeem.user = [];
        db.redeem.maxRedeem = parseInt(m.args[1]); // Pastikan ini jadi angka
        
        m.reply("*Code Redeem, Berhasil Di Setting*");
    }
}