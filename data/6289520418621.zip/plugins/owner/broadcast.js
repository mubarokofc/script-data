const fs = require('fs');
const fetch = require('node-fetch');
const moment = require('moment-timezone');

exports.run = {
    usage: ['bcuser', 'bcprem', 'bcpc', 'bcjadibot', 'bcgc', 'bcsewa'],
    use: 'text',
    category: 'owner',
    async: async (m, {
        func,
        anya,
        store,
        setting,
        quoted
    }) => {
        const qchannel = {
            key: {
                remoteJid: 'status@broadcast',
                fromMe: false,
                participant: '0@s.whatsapp.net'
            },
            message: {
                newsletterAdminInviteMessage: {
                    newsletterJid: '120363261409301854@newsletter',
                    newsletterName: 'Powered by Anya Chan.',
                    jpegThumbnail: null,
                    caption: 'Powered By Anya Chan',
                    inviteExpiration: Date.now() + 1814400000
                }
            }
        }
        switch (m.command) {
            case 'bcuser': {
                if (!m.text) return m.reply(func.example(m.cmd, 'minimal mandi'))
                let data = Object.values(global.db.users).filter(v => v.register && !v.banned).map(v => v.jid)
                await m.reply(`Sending broadcast to *${data.length}* users..`)
                let old = new Date()
                let caption = m.text.replace('@owner', `@${global.owner.split('@')[0]}`)
                for (let jid of data) {
                    anya.sendMessageModify(jid, caption, qchannel, {
                        title: 'System Notification',
                        body: global.header,
                        thumbnail: await (await fetch(setting.cover)).buffer(),
                        expiration: 86400
                    })
                    await new Promise(resolve => setTimeout(resolve, 1500));
                }
                anya.reply(m.chat, `Successfully sent broadcast to *${data.length}* users in *${Math.floor(((new Date - old) / 1000))}* seconds.`, m, {
                    expiration: m.expiration
                })
            }
            break
            case 'bcprem': {
                if (!m.text) return m.reply(func.example(m.prefix + m.command, 'minimal mandi'))
                let data = Object.values(global.db.users).filter(v => v.register && v.premium && !v.banned).map(v => v.jid)
                m.reply(`Sending broadcast to *${data.length}* premium users..`)
                let caption = m.text.replace('@owner', `@${global.owner.split('@')[0]}`)
                let old = new Date()
                for (let jid of data) {
                    anya.sendMessageModify(jid, caption, qchannel, {
                        title: 'System Notification',
                        body: global.header,
                        thumbnail: await (await fetch(setting.cover)).buffer(),
                        expiration: 86400
                    })
                    await new Promise(resolve => setTimeout(resolve, 1500));
                }
                anya.reply(m.chat, `Successfully sent broadcast to *${data.length}* premium users in *${Math.floor(((new Date - old) / 1000))}* seconds.`, m, {
                    expiration: m.expiration
                })
            }
            break
            case 'bcpc': {
                if (!m.text) return m.reply(func.example(m.prefix + m.command, 'minimal mandi'))
                let data = await store.chats.all().filter(v => v.id.endsWith('.net')).map(v => v.id)
                let caption = m.text.replace('@owner', `@${global.owner.split('@')[0]}`)
                m.reply(`Sending broadcast to *${data.length}* private chat..`)
                let old = new Date()
                for (let jid of data) {
                    anya.sendMessageModify(jid, caption, qchannel, {
                        title: 'System Notification',
                        body: global.header,
                        thumbnail: await (await fetch(setting.cover)).buffer(),
                        expiration: 86400
                    })
                    await new Promise(resolve => setTimeout(resolve, 1500));
                }
                anya.reply(m.chat, `Successfully sent broadcast to *${data.length}* private chat in *${Math.floor(((new Date - old) / 1000))}* seconds.`, m, {
                    expiration: m.expiration
                })
            }
            break
            case 'bcjadibot': {
                if (!m.text) return m.reply(func.example(m.prefix + m.command, 'minimal mandi'))
                let data = Object.values(global.db.users).filter(v => v.register && v.jadibot && !v.banned).map(v => v.jid)
                m.reply(`Sending broadcast to *${data.length}* jadibot users..`)
                let caption = m.text.replace('@owner', `@${global.owner.split('@')[0]}`)
                let old = new Date()
                for (let jid of data) {
                    anya.sendMessageModify(jid, caption, qchannel, {
                        title: 'System Notification',
                        body: global.header,
                        thumbnail: await (await fetch(setting.cover)).buffer(),
                        expiration: 86400
                    })
                    await new Promise(resolve => setTimeout(resolve, 1500));
                }
                anya.reply(m.chat, `Successfully sent broadcast to *${data.length}* jadibot users in *${Math.floor(((new Date - old) / 1000))}* seconds.`, m, {
                    expiration: m.expiration
                })
            }
            break
            case 'bcgc': {
                let caption = m.text.replace('@owner', `@${global.owner.split('@')[0]}`)
                let groups = Object.values(await anya.groupFetchAllParticipating()).filter(v => v.participants.find(v => v.id == anya.user.jid) && v.announce == false)
                let data = groups.map(x => x.id)
                let mentions = [];
                groups.map(({
                    participants
                }) => participants.map(v => v.id)).map(jid => mentions.push(...jid))
                if (/image\/(webp)/.test(quoted.mime)) {
                    m.reply(`Sending broadcast to *${data.length}* group chat..`)
                    const media = await quoted.download()
                    let old = new Date()
                    for (let jid of data) {
                        await anya.sendMessage(jid, {
                            sticker: media,
                            mentions: mentions
                        }, {
                            quoted: qchannel,
                            ephemeralExpiration: 86400
                        })
                        await new Promise(resolve => setTimeout(resolve, 1500));
                    }
                    anya.reply(m.chat, `Successfully send broadcast message to *${data.length}* groups in *${Math.floor(((new Date - old) / 1000))}* seconds.`, m, {
                        expiration: m.expiration
                    })
                } else if (/video|image\/(jpe?g|png)/.test(quoted.mime)) {
                    m.reply(`Sending broadcast to *${data.length}* group chat..`)
                    const media = await quoted.download()
                    let old = new Date()
                    for (let jid of data) {
                        await anya.sendMedia(jid, media, qchannel, {
                            caption: caption ? '乂  *B R O A D C A S T*\n\n' + caption : '',
                            mentions: mentions,
                            expiration: 86400
                        })
                        await new Promise(resolve => setTimeout(resolve, 1500));
                    }
                    anya.reply(m.chat, `Successfully send broadcast message to *${data.length}* groups in *${Math.floor(((new Date - old) / 1000))}* seconds.`, m, {
                        expiration: m.expiration
                    })
                } else if (/audio/.test(quoted.mime)) {
                    m.reply(`Sending broadcast to *${data.length}* group chat..`)
                    const media = await quoted.download()
                    let old = new Date()
                    for (let jid of data) {
                        await anya.sendMedia(jid, media, qchannel, {
                            ptt: quoted.ptt,
                            mentions: mentions,
                            expiration: 86400
                        })
                        await new Promise(resolve => setTimeout(resolve, 1500));
                    }
                    anya.reply(m.chat, `Successfully send broadcast message to *${data.length}* groups in *${Math.floor(((new Date - old) / 1000))}* seconds.`, m, {
                        expiration: m.expiration
                    })
                } else {
                    if (!m.text) return m.reply(func.example(m.prefix + m.command, 'minimal mandi'))
                    m.reply(`Sending broadcast to *${data.length}* group chat..`)
                    const thumb = await (await fetch('https://telegra.ph/file/aa76cce9a61dc6f91f55a.jpg')).buffer()
                    let old = new Date()
                    for (let jid of data) {
                        await anya.sendMessageModify(jid, caption, qchannel, {
                            title: 'B R O A D C A S T',
                            body: global.header,
                            thumbnail: thumb,
                            largeThumb: false,
                            // mentions: mentions, 
                            expiration: 86400
                        })
                        await new Promise(resolve => setTimeout(resolve, 1500));
                    }
                    anya.reply(m.chat, `Successfully send broadcast message to *${data.length}* groups in *${Math.floor(((new Date - old) / 1000))}* seconds.`, m, {
                        expiration: m.expiration
                    })
                }
            }
            break
            case 'bcsewa': {
                let groupList = Object.values(await anya.groupFetchAllParticipating()).filter(v => v.participants.find(v => v.id == anya.user.jid) && !v.announce)
                let groups = groupList.map(x => x.id)
                let data = Object.values(global.db.groups).filter(v => v.sewa.status).map(x => x.jid)
                let caption = m.text.replace('@owner', `@${global.owner.split('@')[0]}`)
                let mentions = [...anya.ments(caption), ...Object.values(global.db.users).filter(v => !v.banned).map(v => v.jid)]
                if (/image\/(webp)/.test(quoted.mime)) {
                    m.reply(`Sending broadcast to *${data.length}* group chat..`)
                    const media = await quoted.download()
                    let old = new Date()
                    for (let jid of data) {
                        if (!groups.includes(jid)) continue;
                        await anya.sendMessage(jid, {
                            sticker: media,
                            mentions: mentions
                        }, {
                            quoted: qchannel,
                            ephemeralExpiration: 86400
                        })
                        await new Promise(resolve => setTimeout(resolve, 1500));
                    }
                    anya.reply(m.chat, `Successfully send broadcast message to *${data.length}* groups in *${Math.floor(((new Date - old) / 1000))}* seconds.`, m, {
                        expiration: m.expiration
                    })
                } else if (/video|image\/(jpe?g|png)/.test(quoted.mime)) {
                    m.reply(`Sending broadcast to *${data.length}* group chat..`)
                    const media = await quoted.download()
                    let old = new Date()
                    for (let jid of data) {
                        if (!groups.includes(jid)) continue;
                        await anya.sendMedia(jid, media, qchannel, {
                            caption: caption ? '乂  *B R O A D C A S T*\n\n' + caption : '',
                            mentions: mentions,
                            expiration: 86400
                        })
                        await new Promise(resolve => setTimeout(resolve, 1500));
                    }
                    anya.reply(m.chat, `Successfully send broadcast message to *${data.length}* groups in *${Math.floor(((new Date - old) / 1000))}* seconds.`, m)
                } else if (/audio/.test(quoted.mime)) {
                    m.reply(`Sending broadcast to *${data.length}* group chat..`)
                    const media = await quoted.download()
                    let old = new Date()
                    for (let jid of data) {
                        if (!groups.includes(jid)) continue;
                        await anya.sendMedia(jid, media, qchannel, {
                            ptt: quoted.ptt,
                            mentions: mentions,
                            expiration: 86400
                        })
                        await new Promise(resolve => setTimeout(resolve, 1500));
                    }
                    anya.reply(m.chat, `Successfully send broadcast message to *${data.length}* groups in *${Math.floor(((new Date - old) / 1000))}* seconds.`, m, {
                        expiration: m.expiration
                    })
                } else {
                    if (!m.text) return m.reply(func.example(m.prefix + m.command, 'minimal mandi'))
                    m.reply(`Sending broadcast to *${data.length}* group chat..`)
                    const thumb = await (await fetch('https://telegra.ph/file/aa76cce9a61dc6f91f55a.jpg')).buffer()
                    let old = new Date()
                    for (let jid of data) {
                        if (!groups.includes(jid)) continue;
                        await anya.sendMessage(jid, {
                            text: caption,
                            contextInfo: {
                                mentionedJid: mentions,
                                forwardingScore: 256,
                                isForwarded: true,
                                externalAdReply: {
                                    title: 'B R O A D C A S T',
                                    body: global.header,
                                    mediaType: 1,
                                    thumbnail: thumb,
                                    thumbnailUrl: 'https://telegra.ph/file/aa76cce9a61dc6f91f55a.jpg',
                                    sourceUrl: null,
                                    renderLargerThumbnail: false
                                }
                            }
                        }, {
                            quoted: qchannel,
                            ephemeralExpiration: 86400
                        })
                        await new Promise(resolve => setTimeout(resolve, 1500));
                    }
                    anya.reply(m.chat, `Successfully send broadcast message to *${data.length}* groups in *${Math.floor(((new Date - old) / 1000))}* seconds.`, m, {
                        expiration: m.expiration
                    })
                }
            }
            break
        }
    },
    devs: true
}