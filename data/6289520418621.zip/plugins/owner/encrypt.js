const fs = require('fs');
const path = require('path');
const jsobfus = require('javascript-obfuscator');
exports.run = {
usage: ['encrypt'],
use: 'path',
category: 'owner',
async: async (message, { func, anya }) => {
if (!message.text) return message.reply('Mau enc file di path apa?');
let [filePath, level] = message.text.split(',');
if (level && !['low', 'medium', 'high'].includes(level)) {
return message.reply('Format invalid.');
}
let fullPath = path.join(process.cwd(), filePath.trim() + '.js');
if (fs.existsSync(fullPath)) {
anya.sendReact(message.chat, '🕒', message.key);
await anya.sendMessage(global.owner, {
document: fs.readFileSync(fullPath),
caption: 'File asli \'' + filePath + '.js\'',
mimetype: 'application/json',
fileName: path.basename(fullPath)
}, {
quoted: message,
ephemeralExpiration: message.expiration
}).then(async () => {
let fileContent = fs.readFileSync(fullPath, 'utf-8');
let obfuscated = await obfus(fileContent, level ? level : 'medium');
if (obfuscated.status != 200) {
return message.reply(obfuscated.message);
}
fs.writeFileSync(fullPath, '// buy the script to get the full code\n' + obfuscated.result);
message.reply('Sukses enc file di path \'' + filePath + '.js\'');
});
} else {
message.reply('Path \'' + filePath + '.js\' tidak ditemukan!');
}
},
devs: true
};
async function obfus(code, level = 'low') {
return new Promise((resolve, reject) => {
let levels = ['low', 'medium', 'high'];
level = levels.includes(level) ? level : levels[0];
try {
const options = {
low: {
compact: true,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true,
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
},
medium: {
compact: true,
controlFlowFlattening: false,
deadCodeInjection: false,
debugProtection: false,
debugProtectionInterval: 0,
disableConsoleOutput: false,
identifierNamesGenerator: 'hexadecimal',
log: true,
numbersToExpressions: false,
renameGlobals: false,
selfDefending: true,
simplify: true,
splitStrings: false,
stringArray: true,
stringArrayCallsTransform: false,
stringArrayEncoding: [],
stringArrayIndexShift: true,
stringArrayRotate: true,
stringArrayShuffle: true,
stringArrayWrappersCount: 1,
stringArrayWrappersChainedCalls: true,
stringArrayWrappersParametersMaxCount: 2,
stringArrayWrappersType: 'variable',
stringArrayThreshold: 0.75,
unicodeEscapeSequence: false
},
high: {
compact: true,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 0.75,
deadCodeInjection: true,
deadCodeInjectionThreshold: 0.4,
debugProtection: false,
debugProtectionInterval: 0,
disableConsoleOutput: false,
identifierNamesGenerator: 'hexadecimal',
log: true,
numbersToExpressions: true,
renameGlobals: false,
selfDefending: true,
simplify: true,
splitStrings: true,
splitStringsChunkLength: 10,
stringArray: true,
stringArrayCallsTransform: true,
stringArrayCallsTransformThreshold: 0.75,
stringArrayEncoding: ['base64'],
stringArrayIndexShift: true,
stringArrayRotate: true,
stringArrayShuffle: true,
stringArrayWrappersCount: 2,
stringArrayWrappersChainedCalls: true,
stringArrayWrappersParametersMaxCount: 4,
stringArrayWrappersType: 'function',
stringArrayThreshold: 0.75,
transformObjectKeys: true,
unicodeEscapeSequence: false
}
};
const obfuscationResult = jsobfus.obfuscate(code, options[level]);
const result = {
status: 200,
creator: 'ZidanDev.',
result: obfuscationResult.getObfuscatedCode()
};
resolve(result);
} catch (error) {
const errorResult = {
status: 400,
creator: 'ZidanDev.',
message: String(error)
};
resolve(errorResult);
}
});
}