exports.run = {
usage: ['colong'],
hidden: ['simpan'],
use: 'reply sw',
category: 'owner',
async: async (m, { func, anya }) => {
if (m.quoted?.chat !== 'status@broadcast') return m.reply('Reply story wa yang ingin dicolong!')
if (m.quoted.isMedia) {
let media = await m.quoted.download();
let caption = m.quoted.text ? m.quoted.text : '';
await anya.sendMedia(m.chat, media, m, {caption: caption, expiration: m.expiration})
.then((res) => anya.sendReact(m.chat, '✅', m.key))
.catch((e) => anya.sendReact(m.chat, '❌', m.key))
} else {
await anya.sendMessage(m.chat, {text: m.quoted.text}, {quoted: m, ephemeralExpiration: m.expiration})
.then((res) => anya.sendReact(m.chat, '✅', m.key))
.catch((e) => anya.sendReact(m.chat, '❌', m.key))
}
},
owner: true
}