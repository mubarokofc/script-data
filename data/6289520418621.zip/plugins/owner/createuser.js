const fetch = require('node-fetch');

exports.run = {
    usage: ['createuser'],
    use: 'username,password',
    category: 'owner',
    async: async (m, { func, anya, setting }) => {
        // Memisahkan username dan password
        const [username, password] = m.text.split(',');

        // Cek apakah username dan password ada
        if (!username || !password) {
            return m.reply(func.example(m.cmd, 'ZidanDev,ZidanDev05'));
        }

        const pwnya = 'https://raw.githubusercontent.com/ZidanStoreOfc/anya/refs/heads/main/database/listusers.json?token=GHSAT0AAAAAAC5YBZJNBSXKXYJVIMILVSCGZ7I47TQ';
        const githubToken = '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'; // Ganti dengan token GitHub Anda
        const repoOwner = 'ZidanStoreOfc'; // Ganti dengan pemilik repositori Anda
        const repoName = 'anya'; // Ganti dengan nama repositori Anda
        const filePath = 'dstabase/listusers.json'; // Ganti dengan path file JSON Anda

        // Fetch the data from the URL
        const fetchData = async (url) => {
            const response = await fetch(url);
            return await response.json();
        };

        // Function to save data back to GitHub
        const saveData = async (data) => {
            const response = await fetch(`https://api.github.com/repos/${repoOwner}/${repoName}/contents/${filePath}`, {
                method: 'PUT',
                headers: {
                    'Authorization': `token ${githubToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    message: 'Update user data',
                    content: Buffer.from(JSON.stringify(data, null, 2)).toString('base64'),
                    sha: await getFileSha() // Mendapatkan SHA file untuk update
                })
            });
            return response.json();
        };

        // Function to get the SHA of the file
        const getFileSha = async () => {
            const response = await fetch(`https://api.github.com/repos/${repoOwner}/${repoName}/contents/${filePath}`, {
                headers: {
                    'Authorization': `token ${githubToken}`
                }
            });
            const data = await response.json();
            return data.sha;
        };

        // Fetch the user data
const usersData = await fetchData(pwnya);
const users = usersData.users || []; // Assuming users is part of the fetched data
const blacklist = usersData.blacklist || []; // Ambil data blacklist

// Check if username already exists
const usernameExists = users.some(user => user.username === username);
if (usernameExists) {
    return anya.reply(m.chat, 'Username sudah ada. Silakan gunakan username yang berbeda.');
}

// Add new user
users.push({ username, password }); // Add the new user to the array

// Save the updated users data, including blacklist
await saveData({ users, blacklist }); // Save the updated data

// Send confirmation message
m.reply(`User baru berhasil dibuat:\nUsername: ${username}\nPassword: ${password}`);
   },
   devs: true
};