exports.run = {
    usage: ['addpremium'],
    hidden: ['addprem'],
    use: 'mention or reply',
    category: 'owner',
    async: async (m, {
        func,
        anya
    }) => {
        const toMs = require('ms');
        const [target, duration] = m.text.split(',');
        if (m.quoted) {
            let user = global.db.users[m.quoted.sender]
            let expire = m.text ? Date.now() + toMs(m.text) : 'PERMANENT';
            if (typeof user == 'undefined') return m.reply('User data not found.')
            if (user.premium) return m.reply(`@${m.quoted.sender.replace(/@.+/, '')} has become registered as a premium account.`)
            user.premium = true;
            user.limit += 99999;
            user.expired.premium = expire;
            m.reply(`Successfully added @${m.quoted.sender.replace(/@.+/, '')} to premium user`)
        } else if (m.text) {
            if (!target) return m.reply(`Contoh : ${m.cmd} 62xxx`)
            let number = isNaN(target) ? (target.startsWith('+') ? target.replace(/[()+\s-]/g, '') : target.replace(/@.+/g, '')) : target;
            if (isNaN(number)) return m.reply('Invalid number.')
            if (number.length > 15) return m.reply('Invalid format.')
            let premnya = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
            let user = global.db.users[premnya]
            let expire = duration ? Date.now() + toMs(duration) : 'PERMANENT';
            if (typeof user == 'undefined') return m.reply('User data not found.')
            if (user.premium) return m.reply(`@${premnya.replace(/@.+/, '')} has become registered as a premium account.`)
            user.premium = true;
            user.limit += 99999;
            user.expired.premium = expire;
            m.reply(`Successfully added @${premnya.replace(/@.+/, '')} to premium user.`)
        } else m.reply('Mention or Reply chat target.')
    },
    owner: true,
    location: 'plugins/owner/addpremium.js'
}