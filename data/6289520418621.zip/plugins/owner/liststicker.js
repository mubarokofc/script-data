exports.run = {
usage: ['liststicker'],
hidden: ['liststiker', 'liststik'],
category: 'owner',
async: async (m, { func, anya }) => {
const data = Object.keys(global.db.sticker)
if (data.length == 0) return m.reply('Empty data.')
let rows = [];
for (let [index, name] of data.entries()) {
rows.push({
header: `sticker number ${index + 1}`,
title: `${func.ucword(name)}`,
id: name
})
}
let sections = [{
title: `Database Sticker ( ${data.length} Sticker )`, 
highlight_label: 'Populer Sticker',
rows: rows
}]
let buttons = [
['list', 'Click Here ⎙', sections]
]
await anya.sendButton(m.chat, 'LIST DATABASE STICKER', 'select the list button below.', global.footer, buttons, m, {
expiration: m.expiration
})
},
premium: true
}