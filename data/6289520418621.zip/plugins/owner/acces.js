const axios = require('axios');

exports.run = {
    usage: ['acces'],
    use: 'UserID,Nama,Expired,Role',
    category: 'owner',
    async: async (m, { func, anya, setting }) => {
        if (!m.isDevs) return m.reply('Fitur ini hanya bisa digunakan oleh Developer.');
        if (!m.args[0]) return m.reply(func.example(m.cmd, 'UserID,Nama,21-11-2025,ADMIN'));

        const [filename, name, expiryDate, role] = m.args[0].split(',');

        // Format data untuk file JSON
        const data = {
            name: name.trim(),
            expiry_date: expiryDate.trim(),
            role: role.trim()
        };

        // Konversi data ke JSON string
        const jsonData = JSON.stringify(data, null, 2);

        // URL untuk API GitHub
        const url = `https://api.github.com/repos/ZidanStoreOfc/ZIDANSTORE/contents/license/${filename}.json`;

        // Konfigurasi untuk request
        const config = {
            headers: {
                'Authorization': `token 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`,
                'Accept': 'application/vnd.github.v3+json'
            }
        };

        // Data untuk request
        const body = {
            message: `Create ${filename}.json`,
            content: Buffer.from(jsonData).toString('base64')
        };

        try {
            // Mengirim request untuk membuat file
            const response = await axios.put(url, body, config);
            // Pesan konfirmasi dengan detail akun
            const confirmationMessage = `Acces Telah Diberikan\nDetail Akun:\n- UserID: ${filename}\n- Nama: ${name.trim()}\n- Expired: ${expiryDate.trim()}\n- Role: ${role.trim()}`;
            anya.reply(m.chat, confirmationMessage, m, {
                    expiration: m.expiration
                });
        } catch (error) {
            console.error(error);
            m.reply('Terjadi kesalahan saat membuat file. Pastikan folder license sudah ada.');
        }
    }
};