const fs = require('fs');

exports.run = {
usage: ['listsw'],
hidden: ['botsw'],
use: 'number',
category: 'owner',
async: async (m, { func, anya }) => {
let datastory = JSON.parse(fs.readFileSync('./database/story.json'));
let database = [];
if (!m.text) {
if (datastory.length == 0) return m.reply(`Tidak ada cerita yang tersedia saat ini. silakan tambahkan cerita dengan mengirim gambar, video, atau pesan suara.`)
for (let result of datastory) {
if (database.find(x => x.number == result.sender)) continue;
database.push({
number: result.sender,
name: result.pushname,
total: datastory.filter(v => v.sender == result.sender).length
})
}
let rows = [];
for (let [index, data] of database.entries()) {
rows.push({
//header: `${data.total} Story WhatsApp`,
title: `${index + 1}. ${data.name}`,
description: `Viewing Story from ${data.name?.replaceAll(/\n/g, '')} (${data.total} Story)`, 
id: `${m.prefix}listsw ${data.number}`
})
}
let sections = [{
title: 'S T O R Y - W H A T S A P P',
rows: rows
}]
let buttons = [
['list', 'Click Here ⎙', sections],
]
anya.sendButton(m.chat, `LIST STORY WHATSAPP`, `Total : *${datastory.length}* story`, 'select the list button below.', buttons, m, {
expiration: m.expiration
})
} else {
const data = datastory.filter(x => x.sender === m.text);
if (!data) return m.reply('Empty data.');
await anya.sendReact(m.chat, '🕒', m.key)
let success = 0;
let failed = 0;
for (let story of data) {
await new Promise(resolve => setTimeout(resolve, 1500));
try {
const msg = story.msg.message[story.mtype];
if (story.mtype === 'imageMessage') {
let buffer = await anya.downloadM(msg, story.mtype.replace(/Message/i, ''));
await anya.sendMessage(m.chat, {image: buffer, caption: story.caption, mentions: [story.sender]}, {quoted: story.msg, ephemeralExpiration: m.expiration});
success++;
} else if (story.mtype === 'videoMessage') {
let buffer = await anya.downloadM(msg, story.mtype.replace(/Message/i, ''));
await anya.sendMessage(m.chat, {video: buffer, caption: story.caption, mentions: [story.sender]}, {quoted: story.msg, ephemeralExpiration: m.expiration});
success++;
} else if (story.mtype === 'audioMessage') {
let buffer = await anya.downloadM(msg, story.mtype.replace(/Message/i, ''));
await anya.sendMessage(m.chat, {audio: buffer, mimetype: 'audio/mpeg', ptt: true}, {quoted: story.msg, ephemeralExpiration: m.expiration});
success++;
} else if (story.mtype === 'extendedTextMessage') {
await anya.sendMessage(m.chat, {text: story.caption, mentions: [story.sender]}, {quoted: story.msg, ephemeralExpiration: m.expiration});
success++;
}
} catch (e) {
failed++;
datastory.splice(datastory.indexOf(story), 1);
fs.writeFileSync('./database/story.json', JSON.stringify(datastory, null, 2))
}
}
await m.reply(`Successfully get story data ${data[0]?.pushname}\nSuccess: ${success}\nFailed: ${failed}`)
}
},
vvip: true
}