const Jimp = require('jimp');
const QrCode = require('qrcode-reader');
const fs = require('fs').promises;

exports.run = {
   usage: ['setqris'],
   use: 'reply qr',
   category: 'owner',
   async: async (m, { func, anya }) => {
      try {
         let q = m.quoted ? m.quoted : m;
         let mime = (q.msg || q).mimetype || '';

         if (!/image/.test(mime)) return anya.reply(m.chat, func.texted('bold', '🚩 Image not found.'), m);

         anya.sendReact(m.chat, '🕒', m.key);
         let imgBuffer = await q.download();

         // Use Jimp to handle the image
         let image = await Jimp.read(imgBuffer);

         // Use QrCode reader
         const qr = new QrCode();
         qr.callback = async (err, value) => {
            if (err) {
               return anya.reply(m.chat, '❌ Failed to read QR code. Please make sure the image contains a valid QR code.', m);
            }

            // Send the QR code value as a reply
            setting.qris = value.result
            anya.reply(m.chat, '✅ QRIS Successfully Set', m)
         };

         // Decode the QR code from the image
         qr.decode(image.bitmap);

      } catch (e) {
         return anya.reply(m.chat, func.jsonFormat(e), m);
      }
   },
   owner: true
};
