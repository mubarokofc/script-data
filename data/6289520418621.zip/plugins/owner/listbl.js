const fs = require('fs'); // Untuk membaca file JSON
const blacklistFile = './database/blacklist.json'; // Lokasi file blacklist

exports.run = {
  usage: ['listbl'], // Perintah untuk menampilkan blacklist
  category: 'owner', // Kategori untuk owner
  async: async (m) => {
    try {
      // Periksa apakah file blacklist ada
      if (!fs.existsSync(blacklistFile)) {
        m.reply("Database blacklist tidak ditemukan.");
        return;
      }

      // Membaca file blacklist
      const blacklistData = JSON.parse(fs.readFileSync(blacklistFile, 'utf8'));

      // Pastikan array `blacklistedUsers` ada
      if (!blacklistData.blacklistedUsers || blacklistData.blacklistedUsers.length === 0) {
        m.reply("Blacklist kosong. Tidak ada pengguna yang diblokir.");
        return;
      }

      // Membuat daftar blacklist
      const blacklistList = blacklistData.blacklistedUsers
        .map((userId, index) => `${index + 1}. @${userId.split('@')[0]}`)
        .join('\n');

      // Kirim daftar blacklist dengan format yang diminta
      const message = `乂  *L I S T  B L A C K L I S T*\n\n${blacklistList}`;
      m.reply(message, { mentions: blacklistData.blacklistedUsers });
    } catch (err) {
      console.error("Terjadi kesalahan:", err);
      m.reply("Terjadi kesalahan saat memproses permintaan. Silakan coba lagi nanti.");
    }
  },
  group: true, // Perintah ini hanya bisa digunakan di grup
  botAdmin: true, // Bot harus menjadi admin
};