exports.run = {
    usage: ['addsticker'],
    hidden: ['addstiker', 'addstik'],
    use: 'reply sticker + text',
    category: 'owner',
    async: async (m, {
        func,
        anya,
        quoted
    }) => {
        if (!/webp/.test(quoted.mime)) return m.reply('Reply stikernya!')
        if (!m.text) return m.reply('Masukkan nama stikernya!')
        let name = m.text.trim();
        if (global.db.sticker[name]) return m.reply('Nama tersebut sudah ada di dalam database!')
        let media = await quoted.download();
        let catbox = await func.catbox(media);
        if (!catbox.status) return m.reply(catbox.message);
        global.db.sticker[name] = {
            name: name,
            link: catbox.url
        }
        await m.reply(`Sukses menambahkan sticker dengan nama *${name}* ke dalam database!`)
    },
    owner: true
}