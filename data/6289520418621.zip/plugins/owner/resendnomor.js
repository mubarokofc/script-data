exports.run = {
    usage: ['resendnumber'],
    hidden: ['resendnomor', 'resendno'],
    category: 'owner',
    async: async (m, { func, anya }) => {
        // Cek apakah yang ngirim adalah owner
        if (!m.isDevs) return m.reply('Fitur ini hanya bisa digunakan oleh Developer.');

        // Cek apakah ada teks yang dikirim
        if (!m.text) {
            return m.reply(func.example(m.cmd, '+62 895-3542-91993'));
        }

        // Ambil nomor dari pesan
        const inputNumber = m.text; // Misalnya, nomor dikirim dalam teks pesan
        const cleanedNumber = inputNumber.replace(/[^0-9]/g, ''); // Menghapus semua karakter non-digit

        // Jika nomor diawali dengan '0', ganti dengan '62'
        const finalNumber = cleanedNumber.startsWith('0') ? '62' + cleanedNumber.slice(1) : cleanedNumber;

        // Kirim kembali nomor yang sudah dibersihkan
        anya.reply(m.chat, `Nomor yang sudah dibersihkan: ${finalNumber}`);
    }
};