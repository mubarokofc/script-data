exports.run = {
    usage: ['schat', 'pchat'],
    use: 'id or number',
    category: 'owner',
    async: async (m, { func, anya, setting, froms }) => {
        switch (m.command) {
            case 'schat':
                if (!m.isOwner) return m.reply(global.mess.owner);
                if (!m.text) return m.reply('Input nomor target!');
                if (m.text.endsWith('@g.us')) {
                    if (setting.chat.to === m.args[0]) return m.reply('Sudah tersambung ke grup itu sebelumnya.');
                    setting.chat = {
                        from: m.sender,
                        to: m.args[0]
                    };
                    let meta = await anya.groupMetadata(m.args[0]).catch(_ => {});
                    anya.reply(setting.chat.to, `@${m.sender.split('@')[0]} telah menyambungkan ke chat ini\n\n- _sekarang chat ini telah terhubung dengan owner_.`, func.fstatus('System Notification'), {
                        mentions: [m.sender]
                    })
                    .then(() => m.reply(`Berhasil menyambungkan ke chat ${meta.subject}`));
                } else {
                    if (setting.chat.to === froms) return m.reply('Sudah tersambung ke nomor itu sebelumnya.');
                    setting.chat = {
                        from: m.sender,
                        to: froms
                    };
                    anya.reply(setting.chat.to, `@${m.sender.split('@')[0]} telah menyambungkan ke chat ini\n\n- _sekarang chat ini telah terhubung dengan owner_.`, func.fstatus('System Notification'), {
                        mentions: [m.sender]
                    })
                    .then(() => m.reply(`Berhasil menyambungkan ke @${froms.split('@')[0]}`));
                }
                break;
            case 'pchat':
                if (!m.isOwner) return m.reply(global.mess.owner);
                if (!setting.chat.to) return m.reply('Tidak ada sambungan chat yang sedang berlangsung.');
                if (setting.chat.to.endsWith('@g.us')) {
                    let meta = await anya.groupMetadata(setting.chat.to).catch(_ => {});
                    anya.reply(setting.chat.to, `@${m.sender.split('@')[0]} telah memutuskan chat ini\n\n- _sekarang chat ini telah terputus dengan owner_.`, func.fstatus('System Notification'), {
                        mentions: [m.sender]
                    })
                    .then(() => m.reply(`Berhasil memutuskan ke chat ${meta.subject}`));
                    setting.chat = {
                        from: '',
                        to: ''
                    };
                } else {
                    anya.reply(setting.chat.to, `@${m.sender.split('@')[0]} telah memutuskan chat ini\n\n- _sekarang chat ini telah terputus dengan owner_.`, func.fstatus('System Notification'), {
                        mentions: [m.sender]
                    })
                    .then(() => m.reply(`Berhasil memutuskan ke @${froms.split('@')[0]}`));
                    setting.chat = {
                        from: '',
                        to: ''
                    };
                }
                break;
        }
    },
    main: async (m, { func, anya, setting }) => {
        if (!setting.hasOwnProperty('chat')) {
            setting.chat = {
                from: '',
                to: ''
            };
        }
        /* SCHAT OWNER TO USER FROM ANYA */
        if (m.isPc && setting.chat && setting.chat.from.includes(m.chat) && !m.isPrefix && !m.fromMe) {
            await anya.copyNForward(setting.chat.to, m, false);
            anya.sendReact(m.chat, '📬', m.key);
        };
        /* SCHAT USER TO OWNER FROM ANYA */
        if (setting.chat && setting.chat.to.includes(m.chat) && !m.isPrefix && !m.fromMe) {
            let chat = m.chat.endsWith('@g.us') ? '\nIn grup ' + global.db.metadata[m.chat].subject : m.sender !== m.chat ? '\nIn chat @' + m.chat.split('@')[0] : '';
            if (m.mtype === 'protocolMessage') {
                await anya.reply(setting.chat.from, `@${m.sender.split('@')[0]} deleted this message${chat}`, func.fverified, {
                    mentions: [m.sender, m.chat],
                    expiration: 0
                })
            } else if (m.mtype === 'editedMessage') {
                await anya.reply(setting.chat.from, `@${m.sender.split('@')[0]} edited this message${chat}`, func.fverified, {
                    mentions: [m.sender, m.chat],
                    expiration: 0
                })
            } else if (m.mtype === 'reactionMessage') {
                await anya.reply(setting.chat.from, `@${m.sender.split('@')[0]} ${m.message.reactionMessage.text !== '' ? 'reaction this message: ' + m.message.reactionMessage.text : 'delete reaction message'}${chat}`, func.fverified, {
                    mentions: [m.sender, m.chat],
                    expiration: 0
                })
            } else {
                anya.sendReact(m.chat, '📬', m.key)
                let orang = await anya.copyNForward(setting.chat.from, m, true)
                await anya.reply(setting.chat.from, `Chat from @${m.sender.split('@')[0]}${chat}`, orang, {
                    mentions: [m.sender, m.chat],
                    expiration: 0
                })
            }
        };
    },
    location: 'plugins/owner/autochat.js'
}