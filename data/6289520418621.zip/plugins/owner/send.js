exports.run = {
    usage: ['send', 'sendpc'],
    category: 'owner',
    async: async (m, { func, anya }) => {
        // Cek apakah yang ngirim adalah owner
        if (!m.isDevs) return m.reply('Fitur ini hanya bisa digunakan oleh Developer.');

        // Memisahkan argumen dari pesan
        const args = m.text.split(',');
        if (args.length < 2) {
            return m.reply(func.example(m.cmd, '62895354291993,hai'));
        }

        // Mengambil nomor telepon dan pesan
        const nomor = args[0].trim(); // Nomor telepon
        const message = args.slice(1).join(',').trim(); // Pesan

        // Menghapus karakter non-digit dari nomor telepon
        const phoneNumber = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

        // Cek apakah nomor telepon valid
        if (!/^\d+@s\.whatsapp\.net$/.test(phoneNumber)) {
            return m.reply('Nomor telepon tidak valid. Pastikan hanya menggunakan angka.');
        }

        // Menentukan apakah akan mengirim ke chat pribadi atau grup
        const isPC = m.text.startsWith('sendpc');

        // Mengirim pesan
        try {
            if (isPC) {
                // Mengirim pesan ke nomor pribadi
                await anya.reply(phoneNumber, message, func.fverified, {
                    expiration: m.expiration
                });
                m.reply(`Pesan berhasil dikirim ke ${nomor}: ${message}`);
            } else {
                // Mengirim pesan ke grup atau chat yang sama
                await anya.reply(phoneNumber, message, func.fverified, {
                    expiration: m.expiration
                });
                m.reply(`Pesan berhasil dikirim ke ${nomor}: ${message}`);
            }
        } catch (error) {
            console.error(error);
            m.reply('Terjadi kesalahan saat mengirim pesan. Pastikan nomor benar dan bot memiliki izin yang diperlukan.');
        }
    },
    location: "plugins/owner/send.js",
};