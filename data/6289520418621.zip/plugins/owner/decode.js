const crypto = require('crypto');
const axios = require('axios');
exports.run = {
usage: ['decode'],
use: 'reply text or url',
category: 'owner',
async: async (m, { anya, quoted }) => {
let textToDecode = quoted && quoted.text ? quoted.text : m.text;
if (!textToDecode) return anya.reply(m.chat, 'Masukkan teks atau URL yang ingin didekode.', m);
await anya.sendReact(m.chat, '🕒', m.key);
try {
if (textToDecode.startsWith('http://') || textToDecode.startsWith('https://')) {
const response = await axios.get(textToDecode);
textToDecode = response.data;
}
const decryptAES = (encryptedText, secretKey) => {
const decipher = crypto.createDecipher('aes-256-cbc', secretKey);
let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
decrypted += decipher.final('utf8');
return decrypted;
};
const hexDecode = (str) => {
return str.match(/.{1,2}/g).map(byte => {
return String.fromCharCode(parseInt(byte, 16));
}).join('');
};
const base64Decode = (str) => {
return Buffer.from(str, 'base64').toString('utf-8');
};
const reverseString = (str) => {
return str.split('').reverse().join('');
};
const binaryDecode = (binary) => {
return binary.split(' ').map(bin => {
return String.fromCharCode(parseInt(bin, 2));
}).join('');
};
const secretKey = 'HCZpGQadP53RB4bxVXKuo2kwWjrvNnYSthLiUgfM7JEcm68sqeDz9AyTFn34TRUQuv5drbRxXgRvDRmL7hwLJvtpaoSZJfgaFuCNUprVDDD5prvbct6MG9fmohdSAN62yWCwZDAFh6ZVfrZHYaL2cxoJEKqryGWGNG2h4vkWB5huJMihhouTMfm7NhaZBxRPCLeuDRd9DJnfngSQN3wao3Rw64hQvL39wP66xRVAPZNBc8pmiajBvdox75qq7sq3UiKJvq4bp7nxAftYqWM6hcDp55WzQbuNksEFrjRsfAaJ7cfhQ4wWBh4ggFuoSY7fbagmvtRTsnb7b9VGTLRCaYQWKsWmjBkkmjR3WayeMkc4bxz3gsxrYeoSVhsxDXUBpJJsV653PshnazGZ4rW7taib54VrMJFRWbn2ZWYLHH4j6JmCf6pMwx7k7PioHK3AmP5EJeYU29dMCNxo9tcZx7rS5qei5E5jT7rzQE9QrccdAmhfG87fWdvWJDgJSieCsQmKj36kiF5MHBWHzVsb5T3LzaJ34jYUVGzuYBGrZstT4mBuCXqfVcjxmCCGBLRfHTfTSBdS3TAi6X7FYEA5H97DhCvSukvRvj3DwciG3DSDZNnXsZXZLxdX5LzfT4sdATRutAjZFYyYxg5xj4xLV5UrP5mM4CDAaGC2bwBHgmpBbHFeFynM9HqSUZHqjqrSSpBog3YucAmAycXcazUHZSnkkXZhBvMCYDPyFD7xwoXeF8YcvmZPvDWt5HSBWB3ukntqeen8cgK8yPtacPYh5wCcPCcnrVwrJfj7y2UdRocRanCCdPoZ39zYYSG8Bim4AstzqFGqsavYYW2Xzu8oYTQdJYBBuHsYaNopAGAwG4aj6EWDykwQ5Rm4uXZeM4gxci49nsSqHGbySiYU2PD2MJwpjufVtVd6zb3hBuCT84Z9N2wtH7qb74SVpWU46ARmRjWZZCzZzYzx5zNRdfXpvcq4k2wPm2vDQJ9m2hd';
const decrypted = decryptAES(textToDecode, secretKey);
const decodedHex = hexDecode(decrypted);
const decodedBase64 = base64Decode(decodedHex);
const reversedBinary = reverseString(decodedBase64);
const text = binaryDecode(reversedBinary);
if (!text) return anya.reply(m.chat, 'Gagal mendekode teks.', m);
await anya.reply(m.chat, text, m);
await anya.sendReact(m.chat, '✅', m.key);
} catch (error) {
console.error(error);
await anya.sendReact(m.chat, '❌', m.key);
anya.reply(m.chat, 'Terjadi kesalahan saat mendekode.', m);
}
},
devs: true
};