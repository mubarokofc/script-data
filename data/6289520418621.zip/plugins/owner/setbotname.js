exports.run = {
usage: ['setbotname'],
use: 'text',
category: 'owner',
async: async (m, { func, anya }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'anya 1'))
await anya.updateProfileName(m.text)
m.reply(`Bot name successfully changed to : ${m.text}`)
},
owner: true
}