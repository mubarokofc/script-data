exports.run = {
  usage: ['delsesiquiz'],
  category: 'owner',
  async: async (m, { func, anya }) => {
    // Cek apakah user adalah owner
    if (!m.isOwner) return m.reply('Fitur ini hanya bisa digunakan oleh Owner.');

    // Ambil data quiz di database
    if (!global.db || !global.db.quiz) return m.reply('Tidak ada sesi Quiz yang ditemukan di database.');

    let quizSessions = Object.keys(global.db.quiz);
    if (quizSessions.length === 0) return m.reply('Tidak ada sesi Quiz yang aktif untuk dihapus.');

    // Hapus semua sesi quiz
    quizSessions.forEach(session => {
      delete global.db.quiz[session];
    });

    // Konfirmasi ke owner
    m.reply(`Semua sesi permainan Quiz berhasil dihapus.\nJumlah sesi yang dihapus: *${quizSessions.length}*`);
  },
  owner: true
};