exports.run = {
usage: ['block'],
use: 'mention or reply',
category: 'owner',
async: async (m, { anya, froms }) => {
if (m.quoted || m.text) {
if (!froms) return m.reply('Invalid number.')
anya.updateBlockStatus(froms, 'block')
.then((res) => anya.sendReact(m.chat, '✅', m.key))
.catch((e) => anya.sendReact(m.chat, '❌', m.key))
} else m.reply(`Mention or Reply chat target.`)
},
owner: true
}