const util = require('util');

exports.run = {
    usage: ['getkbbi'],
    hidden: ['gkbbi'],
    use: 'kata',
    category: 'tools',
    async: async (m, {
        func,
        anya
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'ng'))
        const [kata] = m.args;
        let json = await fetch('https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/kbbi.json').then(response => response.json())
        let result = json.filter(item => item.startsWith(kata)).map(x => x);
        if (result.length < 1) return m.reply('Empty data.')
        let words = result.sort((a, b) => a.localeCompare(b)).map((item, index) => (index + 1) + '. ' + item).join('\n');
        anya.reply(m.chat, words, m, {
            expiration: m.expiration
        })
    }
}