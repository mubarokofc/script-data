let fetch = require("node-fetch");
exports.run = {
    usage: ["brat", "bratgif"],
    use: "text",
    category: "convert",
    async: async (t, {
        func: e,
        anya: a,
        packname: r,
        author: i
    }) => {
        var n = "bratgif" === t.command,
            c = n ? 250 : 150;
        let o;
        if (1 <= t.args.length) o = t.args.slice(0).join(" ");
        else {
            if (!t.quoted || !t.quoted.text) return t.reply("Input atau reply text!");
            o = t.quoted.text
        }
        if (!o) return t.reply(e.example(t.cmd, "i love you"));
        if (o.length > c) return t.reply(`Max ${c} character!`);
        if (n && o.split(" ").length < 2) return t.reply("Minimal 2 kata!");
        a.sendReact(t.chat, "🕒", t.key);
        try {
            var p = (n ? "https://apizell.web.id/tools/bratanimate?q=" : "https://brat.caliphdev.com/api/brat?text=") + encodeURIComponent(o),
                l = t.isPrem ? t.chat : "120363378890662177@newsletter";
            t.isPrem || !global.devs.includes(t.bot) ? await a.sendSticker(l, p, t, {
                packname: r,
                author: i,
                expiration: t.expiration
            }) : await a.sendSticker(l, p, null, {
                packname: r,
                author: i,
                expiration: 0
            }).then(e => a.reply(t.chat, "Done icikbos🐦 ambil disini:\nhttps://whatsapp.com/channel/0029Vb0NWHW1dAvuE5yUDZ0b", t, {
                expiration: t.expiration
            }))
        } catch (e) {
            a.reply(t.chat, `An error occurred while creating the sticker.
- ` + e.message, t, {
                expiration: t.expiration
            })
        }
    },
    limit: !0,
    restrict: !0,
    location: "plugins/convert/brat.js"
};