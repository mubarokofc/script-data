exports.run = {
    usage: ['sticker'],
    hidden: ['stiker', 's'],
    use: 'reply image/video',
    category: 'convert',
    async: async (m, { func, anya, quoted, packname, author }) => {
        try {
            // Pastikan ada media yang di-reply
            if (!quoted) return m.reply(`Kirim atau reply gambar/video dengan caption ${m.cmd}`);

            let media;
            const channelId = "120363378890662177@newsletter"; // Ganti dengan JID saluran Anda

            if (/image\/(jpe?g|png)/.test(quoted.mime)) {
                media = await quoted.download();
                if (!media) return m.reply(global.mess.wrong);
            } else if (/video/.test(quoted.mime)) {
                if (quoted.seconds > 9) return m.reply('Maximum video duration is 9 seconds.');
                anya.sendReact(m.chat, '🕒', m.key);
                media = await quoted.download();
                if (!media) return m.reply(global.mess.wrong);
            } else if (/webp/.test(quoted.mime)) {
                media = await quoted.download();
                if (!media) return m.reply(global.mess.wrong);
            } else {
                return m.reply(`Kirim atau reply gambar/video dengan caption ${m.cmd}`);
            }

            // Mengirim stiker ke saluran
            const url = `data:${quoted.mime};base64,${media.toString('base64')}`; // Mengonversi media ke URL base64
            // Cek status pengguna
            if (m.isPrem || m.isVvip || m.isOwner || m.isDevs) {
                // Kirim stiker langsung ke pengguna
                await anya.sendSticker(m.chat, url, m, {
                    packname: packname,
                    author: author,
                    expiration: m.expiration
                });
            } else {
                // Kirim stiker ke saluran untuk pengguna gratis
                await anya.sendStickerFromUrl(channelId, url, m, {
                    packname: packname,
                    author: author,
                    expiration: m.expiration
                });

                // Kirim pesan sukses ke chat pengguna setelah stiker berhasil dibuat
                anya.reply(m.chat, 'Stiker berhasil dibuat\n- Silahkan ambil disini: https://whatsapp.com/channel/0029Vb0NWHW1dAvuE5yUDZ0b', m);
                }

            // Kirim pesan request dari nama pengguna
            if (!(m.isPrem || m.isVvip || m.isOwner || m.isDevs)) {
            const requestMessage = `Request from ${m.pushname}`;
            await anya.sendMessage(channelId, { text: requestMessage });
            }

        } catch (error) {
            console.log(error);
            anya.reply(m.chat, 'Terjadi kesalahan: ' + error.message, m);
        }
    },
    location: "plugins/convert/sticker.js",
    limit: true
};