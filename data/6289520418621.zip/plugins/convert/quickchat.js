const axios = require('axios');

exports.run = {
    usage: ['quickchat', 'quickchat2', 'quickchat3', 'quickchat4'],
    hidden: ['qc', 'qc2', 'qc3', 'qc4'],
    use: 'text',
    category: 'convert',
    async: async (m, { func, anya, packname, author }) => {
    
    // Mendapatkan waktu saat ini
        const now = new Date();
        const hours = now.getUTCHours() + 7; // Mengonversi ke WIB (UTC+7)

        // Cek apakah waktu saat ini antara jam 18:00 dan 20:00 WIB
        if (hours >= 18 && hours < 21) {
            return m.reply('Fitur ini tidak dapat digunakan antara jam 18:00 - 21:00 WIB.');
        }
        
        if (!m.text) return m.reply(func.example(m.cmd, 'hello world'));
        if (m.text.length > 50) return m.reply('Max 50 character!');
        anya.sendReact(m.chat, '🕒', m.key);
        try {
            let color;
            if (/^(quickchat|qc)$/.test(m.command)) color = '#FFFFFF';
            if (/^(quickchat2|qc2)$/.test(m.command)) color = '#000000';
            if (/^(quickchat3|qc3)$/.test(m.command)) color = '#999999';
            if (/^(quickchat4|qc4)$/.test(m.command)) color = '#FF9999';
            const obj = {
                type: "quote",
                format: "png",
                backgroundColor: color,
                width: 512,
                height: 768,
                scale: 2,
                messages: [{
                    entities: [],
                    avatar: true,
                    from: {
                        id: 5,
                        name: m.quoted ? global.db.users[m.quoted.sender].name : m.pushname,
                        photo: {
                            url: await anya.profilePictureUrl(m.quoted ? m.quoted.sender : m.sender, 'image').catch(_ => 'https://telegra.ph/file/320b066dc81928b782c7b.png')
                        }
                    },
                    text: m.text,
                    replyMessage: {}
                }]
            };
            let res = await axios.post(global.quoteApi, obj, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            const channelId = "120363378890662177@newsletter";
            const buffer = Buffer.from(res.data.result.image, 'base64');
            // Cek status pengguna
            if (m.isPrem || m.isVvip || m.isOwner || m.isDevs) {
                // Kirim stiker langsung ke pengguna
                await anya.sendSticker(m.chat, buffer, m, {
                    packname: packname,
                    author: author,
                    expiration: m.expiration
                });
            } else {
                // Kirim stiker ke saluran untuk pengguna gratis
                await anya.sendSticker(channelId, buffer, m, {
                    packname: packname,
                    author: author,
                    expiration: m.expiration
                });

                // Kirim pesan sukses ke chat pengguna setelah stiker berhasil dibuat
                anya.reply(m.chat, 'Stiker qc berhasil dibuat\n- Silahkan ambil disini: https://whatsapp.com/channel/0029Vb0NWHW1dAvuE5yUDZ0b', m);
            }

            // Kirim pesan request dari nama pengguna hanya untuk pengguna gratis
            if (!(m.isPrem || m.isVvip || m.isOwner || m.isDevs)) {
                const requestMessage = `Request from ${m.pushname}`;
                await anya.sendMessage(channelId, { text: requestMessage });
            }
        } catch (error) {
            console.log(error);
            anya.reply(m.chat, error.message, m, {
                expiration: m.expiration
            });
        }
    },
    location: "plugins/convert/quickchat.js",
    restrict: true,
    limit: 3
};