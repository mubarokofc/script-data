const toMs = require('ms');

exports.run = {
    usage: ['jadibot-trial'],
    hidden: ['trialbot'],
    use: 'mention or reply',
    category: 'jadibot',
    async: async (m, {
        func,
        anya,
        users
    }) => {
        if (!users.hasOwnProperty('trialbot')) {
            users.trialbot = false;
        }
        if (users.jadibot) return m.reply('kamu telah terdaftar sebagai user jadibot.')
        if (users.trialbot) return m.reply('kamu sudah pernah mencoba trial jadibot sebelumnya.')
        anya.sendReact(m.chat, '🕒', m.key);
        let expire = Date.now() + toMs('3h');
        let jadibotData = global.db.jadibot.find(v => v.number === m.sender)
        if (!jadibotData) global.db.jadibot.push({
            number: m.sender,
            session: '',
            notify: true,
            status: true
        })
        users.jadibot = true;
        users.trialbot = true;
        users.expired.jadibot = expire;
        if (jadibotData) jadibotData.status = true;
        await require('../../system/jadibot.js').Jadibot(anya, m.sender);
    },
    limit: 5,
    location: 'plugins/jadibot/jadibot-trial.js'
}