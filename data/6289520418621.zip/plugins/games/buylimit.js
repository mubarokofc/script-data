exports.run = {
usage: ['buylimit'],
use: 'jumlah',
category: 'games',
async: async (m, { func, anya, setting, isPrem }) => {
if (!m.text) return m.reply(`Input jumlahnya!\nContoh: ${m.cmd} 1`)
let amount = (m.args[0] || '').replace(/-/g, '')
if (isNaN(amount)) return m.reply(`Jumlah harus berupa angka!\nContoh: ${m.cmd} 1`)
let harga = isPrem ? 500 : ((global.db.users[m.sender].money >= 1000000) ? 1500 : setting.limit.price)
let total = Number(parseInt(amount) * harga) 
if (global.db.users[m.sender].money < total) return m.reply(`Money kamu tidak mencukupi untuk pembelian ini!`)
global.db.users[m.sender].limit += parseInt(amount)
global.db.users[m.sender].money -= total
m.reply(`Membeli *${amount} limit* seharga *${func.rupiah(total)} money*\n> sisa money: ${func.rupiah(global.db.users[m.sender].money)}\n> sisa limit: ${global.db.users[m.sender].limit}`)
}
}