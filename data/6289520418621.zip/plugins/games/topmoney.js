const { areJidsSameUser } = require('@whiskeysockets/baileys');

exports.run = {
usage: ['topmoney'],
category: 'games',
async: async (m, { func, anya }) => {
let umoney = Object.entries(global.db.users).map(([key, value]) => {return {...value, jid: key}})
let sortedbalance = umoney.map(func.toNumber('money')).sort(func.sort('money'))
let usersmoney = sortedbalance.map(func.enumGetKey)
let txt = `Kamu Top *${usersmoney.indexOf(m.sender) + 1}* Money dari *${usersmoney.length}* Users\n`
txt += sortedbalance.slice(0, 40).map(({ jid, money }, i) => `${i + 1}. ${m.isGc && m.members.some(x => areJidsSameUser(jid, x.id)) ? (global.db.users[jid]?.name || anya.getName(jid)).replaceAll('\n', '\t') : '@' + jid.split('@')[0]} => $${func.rupiah(money)}`).join('\n')
anya.reply(m.chat, txt, m, {
expiration: m.expiration
})
}
}