let fetch = require('node-fetch'),
    similarity = require('similarity'),
    gamesUrl = 'https://raw.githubusercontent.com/ZidanStoreOfc/Database/main/games/family100.json',
    sensitive = 0.75,
    alreadyAnswered = new Set();

exports.run = {
    usage: ['family100'],
    hidden: ['f100'],
    category: 'games',
    async: async (m, {
        func,
        anya,
        setting,
        isPrem
    }) => {
        anya.family100 = anya.family100 || {};
        if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit)
        if (m.chat in anya.family100) return anya.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', anya.family100[m.chat].msg)
        let data = await fetch(gamesUrl).then(response => response.json());
        let {
            soal,
            jawaban
        } = data.result.random();
        if (!Array.isArray(jawaban)) return m.reply(`Terjadi kesalahan, silahkan kirim ulang ${m.cmd}`)
        let hadiah = func.hadiah(setting.hadiah);
        let family = [];
        for (let i of jawaban) {
            let a = i.split('/') ? i.split('/')[0] : i
            let b = a.startsWith(' ') ? a.replace(' ', '') : a
            let c = b.endsWith(' ') ? b.replace(b.slice(-1), '') : b
            family.push(c.toLowerCase())
        }
        let caption = `*FAMILY 100 GAMES*\n\n${func.texted('monospace', soal)}\n\nTotal Jawaban: ${jawaban.length}\nHadiah: $${hadiah} balance\nWaktu: ${setting.gamewaktu} detik`
        let msg = await anya.reply(m.chat, caption, m, {
            expiration: m.expiration
        });
        alreadyAnswered.clear();
        anya.family100[m.chat] = {
            soal: soal,
            jawaban: family,
            hadiah: hadiah,
            total: jawaban.length,
            players: [],
            nextQuestion: 1,
            timeout: setTimeout(function() {
                if (m.chat in anya.family100) {
                    let gameData = anya.family100[m.chat];
                    let answered = 'Waktu habis!\nJawaban yang belum terjawab :\n' + gameData.jawaban.map(key => `- ${key}`).join('\n');
                    anya.reply(m.chat, answered, gameData.msg, {
                        expiration: m.expiration
                    });
                    delete anya.family100[m.chat];
                };
            }, setting.gamewaktu * 1000),
            msg: msg ? {
                key: msg.key,
                message: msg.message
            } : null
        }
    },
    main: async (m, {
        func,
        anya,
        setting
    }) => {
        // Game Family 100 By ZidanDev
        anya.family100 = anya.family100 || {};
        if ((m.chat in anya.family100) && !m.fromMe && !m.isPrefix) {
            let gameData = anya.family100[m.chat];
            if (/nyerah/i.test(m.budy)) {
                if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit)
                if (gameData.timeout) clearTimeout(gameData.timeout);
                gameData.nextQuestion++;
                let caption = 'Jawaban yang belum terjawab :\n' + gameData.jawaban.map(key => `- ${key}`).join('\n');
                let next = await anya.sendMessage(m.chat, {
                    text: caption
                }, {
                    quoted: anya.family100[m.chat].msg,
                    ephemeralExpiration: m.expiration
                })
                setTimeout(async () => {
                    let data = await fetch(gamesUrl).then(response => response.json());
                    let result = data.result.random();
                    if (!Array.isArray(result.jawaban)) return m.reply(`Terjadi kesalahan, silahkan kirim ulang ${m.cmd}`)
                    let hadiah = func.hadiah(setting.hadiah);
                    let family = [];
                    for (let i of result.jawaban) {
                        let a = i.split('/') ? i.split('/')[0] : i
                        let b = a.startsWith(' ') ? a.replace(' ', '') : a
                        let c = b.endsWith(' ') ? b.replace(b.slice(-1), '') : b
                        family.push(c.toLowerCase())
                    }
                    let caption = `*LANJUT SOAL KE-${gameData.nextQuestion}*\n\n${func.texted('monospace', result.soal)}\n\nTotal Jawaban: ${result.jawaban.length}\nHadiah: $${hadiah} balance\nWaktu: ${setting.gamewaktu} detik`
                    let msg = await anya.sendMessage(m.chat, {
                        text: caption,
                        edit: next.key
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                    Object.assign(gameData, {
                        soal: result.soal,
                        jawaban: family,
                        hadiah: hadiah,
                        total: result.jawaban.length,
                        players: [],
                        waktu: setTimeout(function() {
                            if (m.chat in anya.family100) {
                                let answered = 'Waktu habis!\nJawaban yang belum terjawab :\n' + gameData.jawaban.map(key => `- ${key}`).join('\n');
                                anya.reply(m.chat, answered, gameData.msg, {
                                    expiration: m.expiration
                                });
                                delete anya.family100[m.chat];
                            };
                        }, parseInt(setting.gamewaktu) * 1000),
                        msg: msg ? {
                            key: msg.key,
                            message: msg.message
                        } : null
                    })
                }, 3000)
                return false;
            }
            if (m.quoted && m.quoted.fromMe && m.quoted.id == anya.family100[m.chat].msg.key.id && !answer(gameData.jawaban, m.budy.toLowerCase()) && /conversation|extendedTextMessage/.test(m.mtype) && setting.incorrect) await anya.sendMessage(m.chat, {
                react: {
                    text: '❌',
                    key: m.key
                }
            })
            for (let kata of gameData.jawaban) {
                if (answer(kata, m.budy.toLowerCase())) {
                    if (alreadyAnswered.has(kata)) return
                    alreadyAnswered.add(kata);
                    console.log(Array.from(alreadyAnswered));
                    let anu = gameData.jawaban.indexOf(kata)
                    gameData.players.push({
                        jid: m.sender,
                        jawaban: kata.toLowerCase()
                    })
                    gameData.jawaban.splice(anu, 1)
                    let txt = m.isGc ? `${gameData.soal}..\n\nTerdapat *${gameData.total}* jawaban\n${gameData.players.map((v, index) => `${index + 1}. ${v.jawaban} @${v.jid.split('@')[0]}`).join('\n')}${gameData.jawaban.length < 1 ? `\n\nSelamat semua jawaban sudah tertebak!\ningin bermain lagi? kirim ${m.prefix}family100` : `\n\n$${gameData.hadiah}balance tiap jawaban benar\nketik *nyerah* untuk menyerah`}` : `Jawaban kamu benar!\nJawaban: ${kata}\n\n${gameData.jawaban.length < 1 ? `Selamat semua jawaban sudah tertebak!\ningin bermain lagi? kirim ${m.prefix}family100` : `Jawaban yang belum tertebak: ${gameData.jawaban.length}`}`
                    anya.reply(m.chat, txt, m, {
                        expiration: m.expiration
                    })
                    global.db.users[m.sender].balance += gameData.hadiah
                    global.db.users[m.sender].game.family100 += 1
                    if (gameData.jawaban.length < 1) clearTimeout(gameData.timeout), delete anya.family100[m.chat];
                }
            }
        }
    },
    location: 'plugins/games/family100.js'
}

function answer(data, text) {
    const lowerText = text.toLowerCase();
    return Array.isArray(data) ?
        data.some(kata => similarity(kata, lowerText) >= sensitive) :
        similarity(data, lowerText) >= sensitive;
}