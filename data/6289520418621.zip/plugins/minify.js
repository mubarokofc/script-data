let fs = require("fs");
let path = require("path");
exports.run = {
  usage: ["uglify"],
  hidden: ["minify2"],
  use: "input or reply",
  category: "developer",
  async: async (e, {
    anya: t
  }) => {
    var a = require("uglify-js");
    let i;
    let n = "minify.js";
    if (e.quoted && /(application|text)\/(javascript|octet-stream)/i.test(e.quoted.mime)) {
      var r = await e.quoted.download();
      i = Buffer.from(r, "base64").toString("utf-8");
      n = e.quoted.fileName;
    } else {
      if (!e.quoted || !e.quoted.text) {
        return e.reply(`Penggunaan:

1. Reply file javascript dengan caption *${e.cmd}*
2. Reply kode javascript dengan caption *${e.cmd}*`);
      }
      i = e.quoted.text;
    }
    await t.sendReact(e.chat, "🕒", e.key);
    r = (await a.minify(i))?.code || false;
    if (!r) {
      return e.reply("Something when wrong!");
    }
    if (r?.length >= 65536) {
      a = path.join(process.cwd(), "sampah", n);
      fs.writeFileSync(a, r);
      await t.sendMessage(e.chat, {
        document: {
          url: a
        },
        mimetype: "application/javascript",
        fileName: n
      }, {
        quoted: e,
        ephemeralExpiration: e.expiration
      });
      if (fs.existsSync(a)) {
        fs.unlinkSync(a);
      }
    } else {
      t.reply(e.chat, r, e, {
        expiration: e.expiration
      });
    }
  }
};