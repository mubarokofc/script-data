exports.run = {
    usage: ['vca', 'vcv'],
    use: 'mention or reply',
    category: 'developer',
    async: async (m, {
        func,
        anya,
        froms
    }) => {
        if (m.quoted || m.text) {
            await anya.offerCall(froms, {
                isVideo: /^vcv$/.test(m.command) ? true : false,
                callOutCome: Date.now()
            });
            await anya.sendReact(m.chat, '✅', m.key);
        } else m.reply('Mention or Reply chat target.')
    },
    devs: true
}