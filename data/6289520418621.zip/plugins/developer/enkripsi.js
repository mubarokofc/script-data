const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

exports.run = {
    usage: ['enkripsi', 'denkripsi'],
    use: 'input or reply',
    category: 'developer',
    async: async (m, {
        func,
        anya
    }) => {
        const algorithm = 'aes-256-cbc';
        const key = Buffer.from('28ead2626a1a8d16a8931a33ae48066588ac9a3f33d651874d99dc2f7d431728', 'hex');
        const iv = Buffer.from('bcf9e83bb4253174c8e93c68bd434b19', 'hex');

        // Simpan key dan iv ke file
        // fs.writeFileSync('key.txt', key.toString('hex'));
        // fs.writeFileSync('iv.txt', iv.toString('hex'));

        const encrypt = (text) => {
            let cipher = crypto.createCipheriv(algorithm, key, iv);
            let encrypted = cipher.update(text);
            encrypted = Buffer.concat([encrypted, cipher.final()]);
            return encrypted.toString('hex');
        };

        const decrypt = (encryptedData) => {
            let decipher = crypto.createDecipheriv(algorithm, key, iv);
            let decrypted = decipher.update(encryptedData, 'hex', 'utf-8');
            decrypted += decipher.final('utf-8');
            return decrypted;
        };

        let inputString;
        let fileName = 'file.js.enc';
        if (m.quoted && /application\/(javascript|octet-stream)/i.test(m.quoted.mime)) {
            let buffer = await m.quoted.download();
            inputString = Buffer.from(buffer, 'base64').toString('utf-8');
            fileName = m.quoted.fileName;
        } else if (m.quoted && m.quoted.text) {
            inputString = m.quoted.text;
        } else return m.reply('Input/reply file javascript yang ingin di enkripsi.')
        await anya.sendReact(m.chat, '🕒', m.key)
        const encryptedContent = /^enkripsi$/.test(m.command) ? encrypt(inputString) : decrypt(inputString);
        if (encryptedContent.length >= 65536) {
            const filePath = path.join(process.cwd(), 'sampah', fileName);
            fs.writeFileSync(filePath, encryptedContent);
            await anya.sendMessage(m.chat, {
                document: {
                    url: filePath
                },
                mimetype: 'application/javascript',
                fileName: fileName
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            })
        } else {
            anya.reply(m.chat, encryptedContent, m, {
                expiration: m.expiration
            })
        }
        // Simpan hasil enkripsi ke file
        fs.writeFileSync('./media/' + fileName, JSON.stringify(encryptedContent));
    }
}