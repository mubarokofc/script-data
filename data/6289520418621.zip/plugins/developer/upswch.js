exports.run = {
    usage: ['upswch'],
    category: 'developer',
    async: async (m, {
        func,
        anya
    }) => {
        const {
            generateWAMessage,
            STORIES_JID,
            generateWAMessageFromContent
        } = require('@whiskeysockets/baileys');

        const sendStatusMention = async (content, groupData, statusJidList) => {
            let success = 0,
                failed = 0,
                index = 0;
            const media = await generateWAMessage(STORIES_JID, content, {
                upload: anya.waUploadToServer,
            });
            const groupStages = itemStages(groupData);
            for (const groupId of groupStages) {
                const additionalNodes = [{
                    tag: "meta",
                    attrs: {},
                    content: [{
                        tag: "mentioned_users",
                        attrs: {},
                        content: groupId.map((jid) => ({
                            tag: "to",
                            attrs: {
                                jid
                            },
                            content: undefined,
                        })),
                    }],
                }];

                await anya.relayMessage(STORIES_JID, media.message, {
                    messageId: media.key.id,
                    statusJidList: statusJidList,
                    additionalNodes,
                });
                for (const jid of groupId) {
                    try {
                        await anya.relayMessage(jid, {
                            groupStatusMentionMessage: {
                                message: {
                                    protocolMessage: {
                                        key: media.key,
                                        type: 25,
                                    },
                                },
                            },
                        }, {
                            userJid: anya.user.jid,
                            additionalNodes: [{
                                tag: "meta",
                                attrs: {
                                    is_status_mention: "true"
                                },
                                content: undefined,
                            }],
                        });
                        success++;
                    } catch (error) {
                        console.log(`Error pada: ${jid}`, error);
                        failed++;
                    }

                    index++;
                    const delay = (index % 10 === 0) ? 30000 : 3000;
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
                await new Promise(resolve => setTimeout(resolve, 5000));
            }
            return {
                success,
                failed
            };
        };

        let groups = Object.values(await anya.groupFetchAllParticipating()).filter(v => v.participants.find(p => p.id == anya.user.jid) && !v.announce);
        let groupData = groups.map(x => x.id);
        let statusJidList = groups.flatMap(group => group.participants.map(v => v.id));
        let content = {
            "image": {
                "url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQN-KVjcdJs8l5b6J_IrV8kaFh_rELFOnhYQ0JI5P-7LmBEuDHmb7GL8C-U8MrCVzQUNaryZ6QxKVb1VuDYU1kMMTBzcv_nA6SORx5-2ig?ccb=9-4&oh=01_Q5AaIQpuQFzplaqA-zywDhMibKr9fDTKykcjvrIyL-dWSPc3&oe=6809AEFD&_nc_sid=e6ed6c&mms3=true",
            },
            "mimetype": "image/jpeg",
            "fileSha256": "/D9weHx5+T9MhDUyndpT0jnqY1kfvPe2ozJeKwAY7bI=",
            "fileLength": "28476",
            "height": 1280,
            "width": 720,
            "mediaKey": "bpi3NO46lEjL+7RKVGW/q1NIYdRtNzTXq1SCsa53gks=",
            "fileEncSha256": "79sPRNip4/j51hmEPgi2dOQVaAHVWMyhERRQJX9bN3E=",
            "directPath": "/o1/v/t62.7118-24/f2/m231/AQN-KVjcdJs8l5b6J_IrV8kaFh_rELFOnhYQ0JI5P-7LmBEuDHmb7GL8C-U8MrCVzQUNaryZ6QxKVb1VuDYU1kMMTBzcv_nA6SORx5-2ig?ccb=9-4&oh=01_Q5AaIQpuQFzplaqA-zywDhMibKr9fDTKykcjvrIyL-dWSPc3&oe=6809AEFD&_nc_sid=e6ed6c",
            "mediaKeyTimestamp": "1740280112",
            "contextInfo": {
                "forwardingScore": 1,
                "isForwarded": true
            },
            "scansSidecar": "hg4yqOmbuCIFJPz1krGja2F24Y3kpl0B3XIzaQclcXpg3m4yXIBhGA==",
            "scanLengths": [
                4208,
                14252,
                4422,
                5594
            ],
            "midQualityFileSha256": "UY+rJ0B+1SOtm6aNwXJB+3Sg5OJG+pC4uUmyohXyLiY=",
            "annotations": [{
                    "polygonVertices": [{
                            "x": 0.13333334028720856,
                            "y": 0.675000011920929
                        },
                        {
                            "x": 0.8666666746139526,
                            "y": 0.675000011920929
                        },
                        {
                            "x": 0.8666666746139526,
                            "y": 0.737500011920929
                        },
                        {
                            "x": 0.13333334028720856,
                            "y": 0.737500011920929
                        }
                    ],
                    "newsletter": {
                        "newsletterJid": "120363375037255604@newsletter",
                        "newsletterName": "𝗈𝖿𝖿𝗂𝖼𝗂𝖺𝗅 𝖺𝗇𝗒𝖺 𝖻𝗈𝗍",
                        "contentType": "LINK_CARD",
                        "accessibilityText": "𝗈𝖿𝖿𝗂𝖼𝗂𝖺𝗅 𝖺𝗇𝗒𝖺 𝖻𝗈𝗍"
                    },
                    "shouldSkipConfirmation": true
                },
                {
                    "polygonVertices": [{
                            "x": 0.06666667014360428,
                            "y": 0.22447916865348816
                        },
                        {
                            "x": 0.9333333373069763,
                            "y": 0.22447916865348816
                        },
                        {
                            "x": 0.9333333373069763,
                            "y": 0.7749999761581421
                        },
                        {
                            "x": 0.06666667014360428,
                            "y": 0.7749999761581421
                        }
                    ],
                    "newsletter": {
                        "newsletterJid": "120363375037255604@newsletter",
                        "newsletterName": "𝗈𝖿𝖿𝗂𝖼𝗂𝖺𝗅 𝖺𝗇𝗒𝖺 𝖻𝗈𝗍",
                        "contentType": "LINK_CARD",
                        "accessibilityText": "𝗈𝖿𝖿𝗂𝖼𝗂𝖺𝗅 𝖺𝗇𝗒𝖺 𝖻𝗈𝗍"
                    }
                }
            ]
        }
        anya.sendReact(m.chat, '🕒', m.key);
        await sendStatusMention(content, groupData, statusJidList);
        anya.sendReact(m.chat, '✅', m.key)
    },
    devs: true,
    location: 'plugins/developer/upswch.js'
}

function itemStages(itemArray) {
    const hasil = [];

    for (let index = 0; index < itemArray.length; index += 5) {
        const stage = itemArray.slice(index, index + 5);
        hasil.push(stage);
    }

    return hasil;
}