const fs = require('fs');

exports.run = {
usage: ['updb'],
category: 'owner',
async: async (m, { func, anya, errorMessage }) => {
anya.sendReact(m.chat, '🕒', m.key)
try {
const content = JSON.parse(fs.readFileSync('./database/database.json'));
global.db = content;
await global.database.save(global.db);
if (JSON.stringify(global.db) === JSON.stringify(content)) await anya.sendReact(m.chat, '✅', m.key)
} catch (e) {
return errorMessage(e);
}
},
devs: true
}