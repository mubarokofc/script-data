const fs = require('fs');
const path = require('path');

exports.run = {
    usage: ['enchard'],
    hidden: ['encjs'],
    use: 'reply file javascript',
    category: 'developer',
    async: async (m, {
        func,
        anya
    }) => {
        const JsConfuser = require('js-confuser');
        try {
            const JsConfuser = require('js-confuser');
            let originalCode;
            let fileName = 'enchard.js';
            if (m.quoted && /application\/(javascript|octet-stream)/i.test(m.quoted.mime)) {
                let buffer = await m.quoted.download();
                originalCode = Buffer.from(buffer, 'base64').toString('utf-8');
                fileName = m.quoted.fileName;
            } else if (m.quoted && m.args.length == 1 && /\.js$/.test(m.args[0])) {
                originalCode = m.quoted.text;
                fileName = m.text;
            } else if (m.text) {
                let filename = m.text.trim().toLowerCase()
                let filePath = path.join(process.cwd(), filename)
                if (!fs.existsSync(filePath)) {
                    return m.reply(`File ${filename} does not exist!`)
                }
                originalCode = fs.readFileSync(filePath, 'utf-8')
                fileName = path.basename(filePath)
            } else {
                return m.reply('Reply file script yang ingin di enkrip.')
            }
            await anya.sendReact(m.chat, '🕒', m.key)
            const options = {
                target: "node",
                preset: "high",
                calculator: true,
                compact: true,
                hexadecimalNumbers: true,
                controlFlowFlattening: 0.75,
                deadCode: 0.2,
                dispatcher: true,
                duplicateLiteralsRemoval: 0.75,
                flatten: true,
                globalConcealing: true,
                identifierGenerator: "randomized",
                minify: true,
                movedDeclarations: true,
                objectExtraction: true,
                opaquePredicates: 0.75,
                renameVariables: true,
                renameGlobals: true,
                shuffle: {
                    hash: 0.5,
                    true: 0.5
                },
                stack: true,
                stringConcealing: true,
                stringCompression: true,
                stringEncoding: true,
                stringSplitting: 0.75,
                rgf: false,
            };

            const obfuscatedCode = await JsConfuser.obfuscate(originalCode, options);
            let obfuscatedPath = `./sampah/${fileName}.js`;
            await fs.writeFileSync(obfuscatedPath, obfuscatedCode)
            await anya.sendMessage(m.chat, {
                    document: fs.readFileSync(obfuscatedPath),
                    mimetype: 'application/javascript',
                    fileName: fileName,
                    caption: 'Successfully hard encrypted this file.'
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                })
                .then(_ => fs.unlinkSync(obfuscatedPath))
        } catch (e) {
            m.reply("Terjadi kesalahan: " + e.message);
        }
    },
    devs: true,
    location: 'plugins/developer/enchigh.js'
}