const axios = require('axios');

exports.run = {
    usage: ['sendgclirik'],
    hidden: ['sendgrouplirik'],
    category: 'developer',
    async: async (m, { func, anya }) => {
        // Check if the sender is the owner
        if (!m.isDevs) return m.reply('Fitur ini hanya bisa digunakan oleh Developer.');

        // Extract the song title from the command
        const songTitle = m.text.split(' ').slice(0).join(' '); // Get the song title after the command

        // Check if a song title was provided
        if (!songTitle) return m.reply('Silakan masukkan judul lagu yang ingin dikirim.');

        const lyricUrl = `https://api.ryzendesu.vip/api/search/lyrics?query=${encodeURIComponent(songTitle)}`;

        // Specify the group ID where you want to send the lyrics
        const groupId = '120363347494579697@g.us'; // Replace with your actual group ID

        try {
            // Fetch the lyrics from the API
            const response = await axios.get(lyricUrl);
            const lyricsData = response.data;

            // Check if we received any lyrics
            if (!lyricsData || lyricsData.length === 0) {
                return m.reply('Lirik tidak ditemukan untuk lagu tersebut.');
            }

            // Extract the plain lyrics from the first result
            const lyrics = lyricsData[0].plainLyrics.split('\n'); // Split lyrics into lines

            // Send each line of the lyrics every second
            for (let i = 0; i < lyrics.length; i++) {
                setTimeout(async () => {
                    await anya.reply(groupId, lyrics[i], func.fverified);
                }, i * 1000); // Send each line every second
            }

            m.reply('Lirik sedang dikirim ke grup.');
        } catch (error) {
            console.error('Error fetching lyrics:', error);
            m.reply('Terjadi kesalahan saat mengambil lirik.');
        }
    }
};