const axios = require('axios');

exports.run = {
usage: ['addbuyer', 'delbuyer', 'listbuyer'],
use: 'parameter',
category: 'developer',
async: async (m, { func, anya }) => {
const username = 'ZidanStoreOfc';
const token = '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';
const repo = 'Database';
const pathName = 'gamesanya/buyer.json';

async function getFileContent() {
const { data: fileData } = await axios.get(`https://api.github.com/repos/${username}/${repo}/contents/${pathName}`, {
headers: {
Authorization: `Bearer ${token}`,
},
});
const fileContent = Buffer.from(fileData.content, 'base64').toString('utf8');
return { fileData, jsonArray: JSON.parse(fileContent) };
}

async function updateFileContent(jsonArray, sha) {
const newFileContent = JSON.stringify(jsonArray, null, 2);
const base64Content = Buffer.from(newFileContent).toString('base64');
await axios.put(`https://api.github.com/repos/${username}/${repo}/contents/${pathName}`, {
message: `Update ${pathName}`,
content: base64Content,
sha: sha,
branch: branch
}, {
headers: {
Authorization: `Bearer ${token}`,
},
});
}

switch (m.command) {
case 'addbuyer':{
if (!m.text) return m.reply(func.example(m.cmd, 'Sultan ➠ 100k *(free update)*'))
const { fileData, jsonArray } = await getFileContent();
let updateData = jsonArray;
if (updateData && Array.isArray(updateData.result)) {
if (updateData.result.includes(m.text)) return m.reply('This buyer is already in database.')
updateData.result.push(m.text)
await updateFileContent(updateData, fileData.sha);
let caption = `successfully add buyer to database.`;
anya.reply(m.chat, caption, m, {
expiration: m.expiration
})
} else m.reply('buyer data is not an array.')
}
break;
case 'delbuyer':{
if (!m.text) return m.reply(func.example(m.cmd, 'Sultan ➠ 100k *(free update)*'))
const { fileData, jsonArray } = await getFileContent();
let updateData = jsonArray;
if (updateData && Array.isArray(updateData.result)) {
if (!updateData.result.includes(m.text)) return m.reply('This buyer not in database.')
const indexToRemove = updateData.result.indexOf(user);
if (indexToRemove !== -1) {
updateData.result.splice(indexToRemove, 1);
await updateFileContent(updateData, fileData.sha);
let caption = `successfully delete buyer from database.`;
anya.reply(m.chat, caption, m, {
expiration: m.expiration
})
} else {
anya.reply(m.chat, 'buyer not in database.', m, {
expiration: m.expiration
})
}
} else m.reply('buyer data is not an array.')
}
break;
case 'listbuyer':{
const { fileData, jsonArray } = await getFileContent();
if (jsonArray.result.length === 0) {
anya.reply(m.chat, 'Data empty.', m, {
expiration: m.expiration
})
} else {
let caption = '*ANYA SCRIPT BUYER LIST*\n\n'
caption += jsonArray.result.map((buyer, index) => `${index + 1}. ${buyer}`).join('\n')
anya.reply(m.chat, caption, m, {
expiration: m.expiration
})
}
}
break
}
},
devs: true
}