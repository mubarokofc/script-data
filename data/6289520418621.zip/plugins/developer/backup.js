const fs = require('fs');
const multidb = new(require('../../system/multidb.js'))();

exports.run = {
    usage: ['backup'],
    category: 'owner',
    async: async (m, {
        func,
        anya,
        errorMessage
    }) => {
        anya.sendReact(m.chat, '🕒', m.key)
        try {
            await multidb.init.save(global.db);
            await fs.writeFileSync('./database/database.json', JSON.stringify(global.db, null, 2))
            await anya.sendMessage(m.chat, {
                document: fs.readFileSync('./database/database.json'),
                caption: `Database ${global.botName}`,
                mimetype: 'application/json',
                fileName: 'database.json'
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
        } catch (e) {
            return errorMessage(e);
        }
    },
    devs: true
}