exports.run = {
    usage: ['getusername'],
    hidden: ['getuser', 'getusr'],
    category: 'developer',
    async: async (m, { func, anya, setting }) => {
        const pwnya = 'https://anya-bot-website.vercel.app/database/listusers.json';
        
        // Fetch the data from the URL
        const fetchData = async (url) => {
            const response = await fetch(url);
            return await response.json();
        };

        // Function to check if username is blacklisted
        const isBlacklisted = (username, blacklist) => {
            return Array.isArray(blacklist) && blacklist.includes(username);
        };

        // Fetch the user data and blacklist
        const usersData = await fetchData(pwnya);
        const blacklist = usersData.blacklist || []; // Assuming blacklist is part of the fetched data
        const users = usersData.users || []; // Assuming users is part of the fetched data

        // Get the username from the command
        const usernameToFind = m.args[0]; // Assuming m.args contains the command arguments

        // Find the user by username
        const user = users.find(user => user.username === usernameToFind); // Tanpa toLowerCase()

        if (!user) {
            return anya.reply(m.chat, `User dengan username "${usernameToFind}" tidak ditemukan.`, m);
        }

        // Check access status
        const accessStatus = isBlacklisted(user.username, blacklist) ? '❌️' : '✅️';

        // Prepare the response message
        const responseMessage = `Detail Akun\nUsername: ${user.username}\nPassword: ${user.password}\nAccess: ${accessStatus}`;

        // Send the response back to the chat
        anya.reply(m.chat, responseMessage, m, {
            expiration: m.expiration
        });
    },
    location: "plugins/developer/getuser.js",
    devs: true
};