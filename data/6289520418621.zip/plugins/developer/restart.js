const multidb = new(require('../../system/multidb.js'))();

exports.run = {
    usage: ['restart'],
    category: 'owner',
    async: async (m, {
        func,
        anya
    }) => {
        await anya.sendMessage(m.chat, {
            text: func.texted('monospace', 'Restarting...')
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        }).then(async () => {
            await multidb.init.save(global.db);
            if (!process.send) return m.reply('Tidak dapat me-restart bot karena file `index.js` tidak dijalankan.')
            process.send('reset');
        })
    },
    devs: true
}