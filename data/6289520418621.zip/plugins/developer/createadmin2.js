exports.run = {
    usage: ['createadmin2', 'cadmin2'],
    use: 'user,nomor',
    category: 'cpanel',
    async: async (m, { func, anya }) => {
        if (!m.isDevs) return m.reply('Fitur ini hanya bisa digunakan oleh Developer.');

        let s = m.text.split(',');
        let username = s[0];
        let nomor = s[1];

        if (s.length < 2) {
            return m.reply(`*Format salah!*\nPenggunaan:\n${m.cmd} user,nomor`);
        }

        if (!username || !nomor) {
            return m.reply(`Ex : ${m.cmd} Username,@tag/nomor\n\nContoh :\n${m.cmd} example,@user`);
        }

        let password = username + Math.floor(Math.random() * 10000)
        let nomornya = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

        let f = await fetch(global.panelApi2.domain + "/api/application/users", {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.panelApi2.apikey
            },
            body: JSON.stringify({
                "email": username + "@zidanstore.shop",
                "username": username,
                "first_name": username,
                "last_name": "Memb",
                "language": "en",
                "root_admin": true,
                "password": password.toString()
            })
        });

        let data = await f.json();

        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        let user = data.attributes;

        let tks = `
TYPE: user

📡ID: ${user.id}
🌷UUID: ${user.uuid}
👤USERNAME: ${user.username}
📬EMAIL: ${user.email}
🦖NAME: ${user.first_name} ${user.last_name}
🔥LANGUAGE: ${user.language}
📊ADMIN: ${user.root_admin}
☢️CREATED AT: ${user.created_at}

🖥️LOGIN: ${global.panelApi2.domain}
`;

        const listMessage = {
            text: tks,
        };

        await anya.sendMessage(m.chat, listMessage);

        await anya.sendMessage(nomornya, { text: `*BERIKUT DETAIL AKUN ADMIN PANEL ANDA*\n\nUSERNAME : ${username}\nPASSWORD: ${password}\nLOGIN: ${global.panelApi2.domain}\n\n*NOTE : OWNER HANYA MENGIRIM 1X DATA AKUN ANDA MOHON DI SIMPAN BAIK BAIK KALAU DATA AKUN ANDA HILANG OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*` }, { quoted: func.fverified, ephemeralExpiration: m.expiration });
    }
}