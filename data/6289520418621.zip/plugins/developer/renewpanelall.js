const toMs = require('ms');

exports.run = {
    usage: ['renewpanelall'],
    use: '<duration>',
    category: 'developer',
    async: async (m, { func, anya }) => {
        const args = m.text.split(' ');
        const duration = args[0] || '30d'; // Jika tidak ada durasi, gunakan 30d sebagai default
        const durationMs = toMs(duration);

        if (!durationMs) return m.reply(func.example(m.cmd, '1d'));

        // Logika untuk memperbarui semua panel
        const allServers = Object.values(global.db.server);
        let successCount = 0;

        for (let server of allServers) {
            if (server.data) {
                for (let data of server.data) {
                    data.expired += durationMs; // Tambahkan durasi
                    successCount++;
                }
            }
        }

        let caption = `Successfully renew panel all for ${formatDuration(duration)}.\nTotal renewed: ${successCount}`;
        anya.reply(m.chat, caption, m, {
            expiration: m.expiration
        });
    },
    devs: true
}

function formatDuration(duration) {
    let result = '';
    if (duration) {
        if (duration.endsWith('d')) result = duration.replace(/d/gi, ' days');
        if (duration.endsWith('h')) result = duration.replace(/h/gi, ' hours');
        if (duration.endsWith('m')) result = duration.replace(/m/gi, ' minutes');
        if (duration.endsWith('s')) result = duration.replace(/s/gi, ' seconds');
    } else {
        result = '30 days';
    }
    return result;
}