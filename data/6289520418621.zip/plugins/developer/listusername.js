exports.run = {
    usage: ['listusername'],
    category: 'developer',
    async: async (m, { func, anya, setting }) => {
        const pwnya = 'https://anya-bot-website.vercel.app/database/listusers.json';
        
        // Fetch the data from the URL
        const fetchData = async (url) => {
            const response = await fetch(url);
            return await response.json();
        };

        // Function to check if username is blacklisted
        const isBlacklisted = (username, blacklist) => {
            return Array.isArray(blacklist) && blacklist.includes(username);
        };

        // Fetch the user data and blacklist
        const usersData = await fetchData(pwnya);
        const blacklist = usersData.blacklist || []; // Assuming blacklist is part of the fetched data
        const users = usersData.users || []; // Assuming users is part of the fetched data

        // Prepare the list of usernames with their access status
        let responseMessage = 'L I S T - U S E R N A M E\n\n';
        users.forEach((user, index) => {
            const accessStatus = isBlacklisted(user.username, blacklist) ? '❌️' : '✅️';
            const passwordMasked = '*'.repeat(user.password.length); // Masking the password
            responseMessage += `${index + 1}. ${user.username}\n- Password:  ${passwordMasked}\n- Access:  ${accessStatus}\n\n`;
        });

        // Remove the last newline character to avoid extra space at the end
        responseMessage = responseMessage.trim();

        // Send the response back to the chat
        anya.reply(m.chat, responseMessage, m, {
                    expiration: m.expiration
                });
    },
    location: "plugins/developer/listusername.js",
    devs: true
};