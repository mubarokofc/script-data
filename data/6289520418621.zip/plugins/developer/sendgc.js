exports.run = {
    usage: ['sendgc'],
    hidden: ['sendgcnotag'],
    category: 'developer',
    async: async (m, { func, anya }) => {
        // Check if the sender is the owner
        if (!m.isDevs) return m.reply('Fitur ini hanya bisa digunakan oleh Developer.');

        // Extract the group ID and message from the command
        const groupId = '120363347494579697@g.us'; // Replace with your group ID
        const message = m.text.split(' ').slice(0).join(' '); // Get the message after the command

        // Check if a message was provided
        if (!message) return m.reply('Silakan masukkan pesan yang ingin dikirim.');

        try {
            // Send the message to the group
            await anya.reply(groupId, message, func.fverified, {
                    expiration: m.expiration
                });
            m.reply('Pesan berhasil dikirim ke grup.');
        } catch (error) {
            console.error(error);
            m.reply('Terjadi kesalahan saat mengirim pesan.');
        }
    }
};