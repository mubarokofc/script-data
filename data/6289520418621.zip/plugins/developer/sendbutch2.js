exports.run = {
    usage: ['sendbutch2'],
    use: 'text',
    category: 'developer',
    async: async (m, {
        func,
        anya,
        setting
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'halo'))
        const buttons = [{
                index: 1,
                urlButton: {
                    displayText: "Get Buy",
                    url: 'https://wa.me/62895354291993?text=Bang+saya+mau+beli+produk+abang'
                }
            },
            {
                index: 1,
                urlButton: {
                    displayText: "Group Marketplace",
                    url: 'https://chat.whatsapp.com/IJ6RwwsCCrAGTbkUcu8MXE'
                }
            },
            {
                index: 1,
                urlButton: {
                    displayText: "My Tiktok",
                    url: 'https://tiktok.com/@zidanstoreofficial'
                }
            },
            {
               index: 1,
                urlButton: {
                    displayText: "My Instagram",
                    url: 'https://instagram.com/zidanstoreofficial'
               }
           }
        ];
        const buttonsMessage = {
            text: m.text.trim(),
            title: '',
            footer: global.footer2,
            viewOnce: true,
            templateButtons: buttons,
            headerType: 2
        }
        await anya.sendMessage(global.newsletter3, buttonsMessage).then(() => anya.sendReact(m.chat, '✅', m.key))
            .catch(() => anya.sendReact(m.chat, '❌', m.key))
    },
    devs: true,
    location: 'plugins/developer/sendbutch2.js'
}