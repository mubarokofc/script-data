const toMs = require('ms');

exports.run = {
    usage: ['addpanel'],
    use: 'mention or reply',
    category: 'developer',
    async: async (m, {
        func,
        anya
    }) => {
        const timenow = func.timezone();
        if (m.quoted && m.text) {
            const [username, id, ram, duration] = m.text.split(',');
            if (!(username && id && ram)) return m.reply(func.example(m.cmd, 'ZidanStore,1,unli'))
            let jid = m.quoted.sender;
            let server = global.db.server[jid];
            let expire = duration ? Date.now() + toMs(duration) : Date.now() + toMs('30d')
            if (!server) {
                global.db.server[jid] = {
                    jid: jid,
                    data: [{
                        id: id,
                        ram: ram,
                        username: username,
                        expired: expire,
                        date: timenow.date
                    }]
                }
            } else {
                if (server.data.find(item => item.username === username)) return m.reply(`Username tersebut sudah ada pada server @${jid.replace(/@.+/, '')}`)
                if (server.data.find(item => item.id === id)) return m.reply(`ID tersebut sudah ada pada server @${jid.replace(/@.+/, '')}`)
                server.data.push({
                    id: id,
                    ram: ram,
                    username: username,
                    expired: expire,
                    date: timenow.date
                })
            }
            m.reply(`Successfully added @${jid.replace(/@.+/, '')} to panel list`)
        } else if (m.text) {
            const [target, username, id, ram, duration] = m.text.split(',');
            if (!(target && username && id && ram)) return m.reply(func.example(m.cmd, '62895354291993,Zidan,1,unli'))
            let number = isNaN(target) ? (target.startsWith('+') ? target.replace(/[()+\s-]/g, '') : (target).split('@')[1]) : target;
            if (isNaN(number)) return m.reply('Invalid number.')
            if (number.length > 15) return m.reply('Invalid format.')
            let jid = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
            let server = global.db.server[jid];
            let expire = duration ? Date.now() + toMs(duration) : Date.now() + toMs('30d')
            if (!server) {
                global.db.server[jid] = {
                    jid: jid,
                    data: [{
                        id: id,
                        ram: ram,
                        username: username,
                        expired: expire,
                        date: timenow.date
                    }]
                }
            } else {
                if (server.data.find(item => item.username === username)) return m.reply(`Username tersebut sudah ada pada server @${jid.replace(/@.+/, '')}`)
                if (server.data.find(item => item.id === id)) return m.reply(`ID tersebut sudah ada pada server @${jid.replace(/@.+/, '')}`)
                server.data.push({
                    id: id,
                    ram: ram,
                    username: username,
                    expired: expire,
                    date: timenow.date
                })
            }
            m.reply(`Successfully added @${jid.replace(/@.+/, '')} to panel list`)
        } else m.reply('Mention or Reply chat target.')
    },
    devs: true
}