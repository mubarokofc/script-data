exports.run = {
    usage: ['subdo', 'listsubdo'],
    use: '',
    category: 'cpanel',
    async: async (m, { func, anya }) => {
        const obj = Object.keys(global.subdomain);
        let count = 0;
        let teks = `*#- List all domain server*\n`;

        for (let i of obj) {
            count++;
            teks += `\n* ${count}. ${i}\n`;
        }

        teks += `\nContoh : *.domain 2 host|ipvps*\n`;
        m.reply(teks);
    },
    devs: true
};