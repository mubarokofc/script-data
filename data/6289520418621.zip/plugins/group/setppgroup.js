exports.run = {
    usage: ['setppgroup'],
    hidden: ['setppgrup', 'setppgc'],
    use: 'reply photo / full',
    category: 'admin tools',
    async: async (m, { func, anya, quoted }) => {
        if (/image\/(jpe?g|png)/.test(quoted.mime)) {
            if (m.args[0] === 'full') {
                let media = await quoted.download()
                await anya.updateProfilePicture(m.chat, media, { width: 800, height: 400 }) // Atur ukuran di sini
                m.reply(global.mess.ok)
            } else {
                let media = await quoted.download()
                await anya.updateProfilePicture(m.chat, media, { width: 800, height: 400 }) // Atur ukuran di sini
                .then((res) => anya.sendReact(m.chat, '✅', m.key))
                .catch((e) => anya.sendReact(m.chat, '❌', m.key))
            }
        } else m.reply(`Kirim/reply gambar dengan caption ${m.cmd}`)
    },
    group: true,
    admin: true,
    boAdmin: true
}