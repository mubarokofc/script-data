exports.run = {
usage: ['getname', 'getpp', 'getbio'],
use: 'mention or reply',
category: 'group',
async: async (m, { anya, froms }) => {
switch (m.command) {
case 'getname':
if (m.quoted || m.text) {
let name;
if (froms in global.db.users) {
name = global.db.users[froms]?.name;
} else {
name = await anya.getName(froms);
}
anya.reply(m.chat, name, m, {
expiration: m.expiration
})
} else m.reply('Mention or Reply chat target.')
break
case 'getpp':
if (m.quoted || m.text) {
if ([global.owner, ...global.devs].includes(froms) && !m.isOwner) return m.reply('Tidak bisa getpp creator saya!')
anya.sendReact(m.chat, '🕒', m.key)
let pporang = await anya.profilePictureUrl(froms, 'image').catch(_ => '')
if (pporang) {
anya.sendMessage(m.chat, {image: {url: pporang}, caption: global.mess.ok}, {quoted: m, ephemeralExpiration: m.expiration})
} else m.reply('Gagal profile di private.')
} else m.reply('Mention or Reply chat target.')
break
case 'getbio':
if (m.quoted || m.text) {
let bionya = (await anya.fetchStatus(froms).catch(console.log('[ ERROR BIO ]')) || {}).status || 'Bio di private!'
anya.reply(m.chat, bionya, m, {
expiration: m.expiration
})
} else m.reply('Mention or Reply chat target.')
break
}
}
}