exports.run = {
    usage: ['antispam2'],
    use: 'on / off',
    category: 'admin tools',
    async: async (m, {
        func,
        anya
    }) => {
        let groupData = global.db.groups[m.chat];
        if (!m.args || !m.args[0]) return m.reply(`*Current status* : ${groupData.antispam ? 'active' : 'non-active'}\n\n${func.example(m.cmd, 'on / off')}`)
        let option = m.args[0].toLowerCase()
        let optionList = ['on', 'off'];
        if (!optionList.includes(option)) return m.reply(`${func.example(m.cmd, 'on / off')}`)
        let status = option === 'on' ? true : false;
        if (groupData.antispam == status) return m.reply(`AntispamV2 has been ${option == 'on' ? 'activated' : 'inactivated'} previously.`)
        groupData.antispam = status;
        anya.reply(m.chat, `AntispamV2 has been ${option == 'on' ? 'activated' : 'inactivated'} successfully.`, m, {
            expiration: m.expiration
        })
    },
    group: true,
    admin: true,
    botAdmin: true
}