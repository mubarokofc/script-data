exports.run = {
    usage: ['kickme'],
    hidden: ['tendangdiri'],
    category: 'group',
    async: async (m, { func, anya }) => {
        
        let target = m.sender; // Ini untuk ngekick diri sendiri

        await anya.groupParticipantsUpdate(m.chat, [target], 'remove').then(data => {
            for (let i of data) {
                if (i.status == 406) {
                    m.reply(`Gagal mengeluarkan @${target.split('@')[0]} dengan alasan: kamu yang membuat grup ini!`);
                } else {
                    m.reply(`Berhasil mengeluarkan @${target.split('@')[0]} dari grup ini! Bye-bye! 👋`);
                }
            }
        }).catch((err) => m.reply(func.jsonFormat(err)));
    },
    group: true,
    botAdmin: true
}