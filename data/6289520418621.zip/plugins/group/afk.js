exports.run = {
usage: ['afk', 'setafk', 'setalasan', 'listafk'],
category: 'group',
async: async (m, { func, anya, update, users, froms, setting }) => {
switch (m.command) {
case 'afk':
//if (!setting.owner.includes(m.sender)) return m.reply('Fiturnya dihapus sama owner awoawok')
if (m.text && m.text.length > 1000) return m.reply('Max 1000 character.')
users.afk = + new Date
users.alasan = m.text ? m.text : '';
users.afkObj = {
key: m.key,
message: m.message
}
return m.reply(`${m.pushname} sedang AFK${m.text ? '\nAlasan: ' + m.text : ''}`)
break
case 'setafk':
if (!m.isOwner) return m.reply(global.mess.owner)
if (m.text && isNaN(m.text)) return m.reply('Waktu harus berupa angka (ms)')
//if (!m.text) return m.reply('Masukkan waktunya!')
if (!m.quoted) return m.reply('Reply pesan target!')
let now = + new Date;
global.db.users[m.quoted.sender].afk = m.text ? m.text : now;
anya.sendReact(m.chat, '✅', m.key)
break
case 'setalasan':
if (!m.isOwner) return m.reply(global.mess.owner)
if (!m.text) return m.reply('Masukkan alasannya!')
if (!m.quoted) return m.reply('Reply pesan target!')
global.db.users[m.quoted.sender].alasan = m.text
anya.sendMessage(m.chat, {delete: {remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.sender}})
break
case 'listafk':
let afkdata = Object.values(global.db.users).filter(v => v.afk > 0)
if (afkdata.length == 0) return m.reply('Empty data.')
let txt = `乂  *LIST USER AFK*\nTotal : *${afkdata.length}*\n`
txt += afkdata.map((v, i) => `\n${i + 1}. @${v.jid.split('@')[0]}\n◦  Reason: ${v.alasan ?? 'tanpa alasan'}\n◦  Selama: ${func.clockString(Date.now() - v.afk)}`).join('\n')
anya.sendMessageModify(m.chat, txt, m, {
thumbUrl: setting.cover,
largeThumb: true,
expiration: m.expiration
})
break
}
},
restrict: true,
group: true
}