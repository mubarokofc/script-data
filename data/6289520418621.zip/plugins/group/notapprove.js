let moment = require("moment-timezone");

exports.run = {
    usage: ["notapprove"],
    hidden: ["notaccept", "noacc"],
    category: "group",
    async: async (e, { func: t, anya: a }) => {
        let [i] = e.args, r = [], p = `乂  *LIST REQUEST JOIN*
        `;
        p += `
*${e.prefix}acc 1* untuk approve peserta 1
*${e.prefix}acc all* untuk approve semua peserta
*${e.prefix}noacc 1* untuk menolak peserta 1
*${e.prefix}noacc all* untuk menolak semua peserta
`;

        var s = await a.groupRequestParticipantsList(e.chat);
        if (s.length === 0) return e.reply("Tidak ada pending request.");

        s.forEach((e, t) => {
            r.push({
                index: t + 1,
                jid: e.jid,
                request_method: e.request_method,
                request_time: e.request_time
            });
            p += `
${t + 1}. @` + e.jid.split("@")[0] + `
◦  *Request method:* ` + e.request_method + `
◦  *Time:* ` + moment(1e3 * e.request_time).tz("Asia/Jakarta").format("DD/MM/YY HH:mm:ss");
        });

        if (i && /^(all|semua)$/i.test(i)) {
            for (var o of s) {
                await a.groupRequestParticipantsUpdate(e.chat, [o.jid], "reject");
                await t.delay(1e3);
            }
            a.reply(e.chat, `Successfully rejected ${s.length} participants.`, e, {
                expiration: e.expiration
            });
        } else if (i && r.some(e => e.index == i)) {
            s = r[i - 1].jid;
            await a.groupRequestParticipantsUpdate(e.chat, [s], "reject");
            a.sendReact(e.chat, "❌", e.key);
        } else {
            await a.reply(e.chat, p, e, {
                expiration: e.expiration
            });
        }
    },
    group: true,
    admin: true,
    botAdmin: true
};