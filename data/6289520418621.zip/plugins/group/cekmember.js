exports.run = {
    usage: ['cekmember', 'cekasalmember'],
    category: 'group',
    async: async (m, { func, anya, users }) => {
        // Ambil metadata grup
        if (!m.isGc) return m.reply(global.mess.group)
        const groupMetadata = await anya.groupMetadata(m.chat);
        const members = groupMetadata.participants;

        // Daftar negara, kode telepon, dan bendera
        const countryInfo = {
            '🇮🇩 Indonesia': '+62',
            '🇷🇺 Rusia/Kazakhstan': '+7',
            '🇲🇾 Malaysia': '+60',
            '🇺🇸 Amerika Serikat': '+1',
            '🇬🇧 Inggris': '+44',
            '🇩🇪 Jerman': '+49',
            '🇫🇷 Prancis': '+33',
            '🇯🇵 Jepang': '+81',
            '🇮🇳 India': '+91',
            '🇦🇷 Argentina': '+54',
            '🇹🇷 Turkey': '+90',
            '🇲🇽 Meksiko': '+52',
            '🇧🇷 Brazil': '+55',
            // Tambahkan negara lain sesuai kebutuhan
        };

        // Buat objek untuk menyimpan jumlah anggota berdasarkan negara
        const countryCount = {};
        for (const country in countryInfo) {
            countryCount[country] = 0;
        }

        // Hitung anggota berdasarkan negara
        members.forEach(member => {
            const phoneNumber = member.id.split('@')[0]; // Ambil nomor telepon dari ID

            for (const [country, code] of Object.entries(countryInfo)) {
                if (phoneNumber.startsWith(code.replace('+', ''))) { // Cek dengan menghapus tanda +
                    countryCount[country]++;
                    break;
                }
            }
        });

        // Hitung total anggota
        const totalMembers = members.length;

        // Buat pesan untuk dikirim
        let message = '乂  *A S A L - N E G A R A*\n\nJumlah Anggota Grup Berdasarkan Negara:\n';
        for (const country in countryCount) {
            message += `${country} (${countryInfo[country]}) : ${countryCount[country]}\n`; // Tampilkan bendera, kode negara, dan jumlah
        }
        message += `\n📋 Total Anggota: ${totalMembers}`;

        // Kirim pesan
        await m.reply(message);
    }
};