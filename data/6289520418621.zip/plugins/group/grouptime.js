exports.run = {
    usage: ['opentime', 'closetime'],
    use: '<angka> <waktu>',
    category: 'group',
    async: async (m, { args, anya }) => {
        const timeValue = parseInt(m.args[0]); // Ambil angka dari argumen pertama
        const timeUnit = m.args[1]; // Ambil unit waktu dari argumen kedua
        let timer;

        if (isNaN(timeValue)) {
            return m.reply('Masukkan angka yang valid untuk waktu!');
        }

        if (timeUnit === "detik") {
            timer = timeValue * 1000;
        } else if (timeUnit === "menit") {
            timer = timeValue * 60000;
        } else if (timeUnit === "jam") {
            timer = timeValue * 3600000;
        } else if (timeUnit === "hari") {
            timer = timeValue * 86400000;
        } else {
            return m.reply("*pilih:*\ndetik\nmenit\njam\nhari\n\n*contoh*\n10 detik");
        }

        if (m.command === "closetime") {
            m.reply(`Menutup group ini *${timeValue} ${timeUnit}* dimulai dari sekarang`); // Tambahin timeValue
            setTimeout(() => {
                const close = `*Tepat waktu* grup ditutup oleh admin\nsekarang hanya admin yang dapat mengirim pesan`;
                anya.groupSettingUpdate(m.chat, 'announcement');
                m.reply(close);
            }, timer);
        } else if (m.command === "opentime") {
            m.reply(`Membuka Group Ini *${timeValue} ${timeUnit}* Dimulai Dari Sekarang`); // Tambahin timeValue
            setTimeout(() => {
                const open = `*Tepat Waktu* Grup Dibuka Oleh Admin\nSekarang Member Dapat Mengirim Pesan`;
                anya.groupSettingUpdate(m.chat, 'not_announcement');
                m.reply(open);
            }, timer);
        }
    },
    group: true,
    admin: true,
    botAdmin: true
};