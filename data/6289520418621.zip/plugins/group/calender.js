const {
    createCanvas
} = require('canvas');
const moment = require('moment-timezone');

exports.run = {
    usage: ['kalender', 'calendar', 'tanggal', 'date'],
    category: 'group',
    async: async (m, {
        text,
        anya
    }) => {
        const timezone = 'Asia/Jakarta';
        const currentDate = moment.tz(timezone);
        const currentMonth = currentDate.month();
        const currentYear = currentDate.year();
        const today = currentDate.date();
        const isDaytime = currentDate.hour() >= 6 && currentDate.hour() < 18;

        const canvasWidth = 1600;
        const canvasHeight = 1400;

        const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
        let queryMonth = months.findIndex(month => text && month.toLowerCase() === text.toLowerCase());
        if (queryMonth === -1) queryMonth = currentMonth;

        const displayDate = moment.tz(timezone).month(queryMonth).startOf('month');
        const monthName = months[queryMonth];
        const year = currentYear;

        const canvas = createCanvas(canvasWidth, canvasHeight);
        const ctx = canvas.getContext('2d');

        const theme = isDaytime ?
            {
                bg: '#ffffff',
                text: '#000000',
                grid: '#cccccc',
                accent: '#007bff',
                todayBg: '#cce5ff',
                todayBorder: '#007bff',
            } :
            {
                bg: '#1e1e1e',
                text: '#ffffff',
                grid: '#444444',
                accent: '#00aaff',
                todayBg: '#004466',
                todayBorder: '#00aaff',
            };

        ctx.fillStyle = theme.bg;
        ctx.fillRect(0, 0, canvasWidth, canvasHeight);

        ctx.fillStyle = theme.text;
        ctx.font = 'bold 80px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(`${monthName} ${year}`, canvasWidth / 2, 100);

        ctx.strokeStyle = theme.grid;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(100, 120);
        ctx.lineTo(canvasWidth - 100, 120);
        ctx.stroke();

        const dayNames = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
        const cellWidth = canvasWidth / 7;
        const cellHeight = (canvasHeight - 200) / 8;
        ctx.font = 'bold 50px Arial';
        dayNames.forEach((day, i) => {
            if (i === 0) {
                ctx.fillStyle = 'red';
            } else {
                ctx.fillStyle = theme.text;
            }
            ctx.fillText(day, cellWidth * i + cellWidth / 2, 180);
        });

        const pasaran = ['Legi', 'Pahing', 'Pon', 'Wage', 'Kliwon'];
        const startDay = displayDate.day();
        const totalDays = displayDate.daysInMonth();
        const pasaranOffset = moment('1900-01-01').diff(displayDate, 'days') % 5;

        let x = startDay;
        let y = 1;

        for (let day = 1; day <= totalDays; day++) {
            const posX = cellWidth * x + cellWidth / 2;
            const posY = 200 + cellHeight * y + 60;

            if (day === today && queryMonth === currentMonth && year === currentYear) {
                ctx.fillStyle = theme.accent;
            } else {
                ctx.fillStyle = 'black';
            }
            ctx.font = 'bold 45px Arial';
            ctx.fillText(day, posX, posY - 10);

            const pasaranName = pasaran[(day + pasaranOffset) % 5];
            ctx.fillStyle = 'black';
            ctx.font = 'italic 30px Arial';
            ctx.fillText(pasaranName, posX, posY + 35);

            x++;
            if (x > 6) {
                x = 0;
                y++;
            }
        }

        const buffer = canvas.toBuffer();
        await anya.sendMessage(m.chat, {
            image: buffer,
            caption: `*• Kalender :* ${monthName} ${year}`,
        }, {
            quoted: m
        });
    },
};