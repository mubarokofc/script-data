exports.run = {
    usage: ['taggc'],
    hidden: ['taggrup'],
    use: 'example',
    category: 'group',
    async: async (m, {
        func,
        anya
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'Zidan'));
        await anya.sendMessage(m.chat, {
            text: `@${m.chat}`,
            contextInfo: {
                mentionedJid: [m.sender],
                groupMentions: [{
                    groupSubject: m.text.trim(),
                    groupJid: m.chat,
                }]
            }
        }, {
            quoted: null,
            ephemeralExpiration: m.expiration
        });
    },
    admin: true,
    location: 'plugins/group/taggc.js'
}