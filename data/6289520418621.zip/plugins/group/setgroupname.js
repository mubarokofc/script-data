exports.run = {
usage: ['setgroupname'],
hidden: ['setgrupname', 'setgcname'],
use: 'text',
category: 'group',
async: async (m, { func, anya }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'Test'))
await anya.groupUpdateSubject(m.chat, m.text)
.then((res) => anya.sendReact(m.chat, '✅', m.key))
.catch((e) => anya.sendReact(m.chat, '❌', m.key))
},
group: true,
admin: true,
botAdmin: true
}