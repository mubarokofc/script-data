exports.run = {
    usage: ['delschedule'],
    use: 'parameter',
    category: 'admin tools',
    async: async (m, { func, anya }) => {
        let time = m.text;
        
        if (!m.text) return m.reply("Contoh: \n- .delschedule all\n- .delschedule 12:00:00");
        
        if (!global.schedules) global.schedules = {};
        
        if (!global.schedules[m.chat]) {
            return m.reply(`Tak ada schedule yang aktif di grup ini!`);
        }

        if (time === "all") {
            delete global.schedules[m.chat];
            return m.reply(`Berhasil! Semua schedule aktif di grup ini telah dihapus!`);
        } else {
            const newTimes = global.schedules[m.chat].times.filter(entry => entry.time !== time);
            if (newTimes.length === global.schedules[m.chat].times.length) {
                return m.reply(`Tak ada schedule untuk waktu ${time} di grup ini.`);
            } else {
                global.schedules[m.chat].times = newTimes;
                if (global.schedules[m.chat].times.length === 0) {
                    delete global.schedules[m.chat];
                    return m.reply(`Semua schedule untuk waktu ${time} di grup ini telah dihapus! Tidak ada lagi schedule yang tersisa.`);
                } else {
                    return m.reply(`Schedule untuk waktu ${time} di grup ini sudah dihapus!`);
                }
            }
        }
    },
    group: true,
    admin: true,
    botAdmin: true
};