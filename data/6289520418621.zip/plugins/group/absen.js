exports.run = {
    usage: ['mulaiabsen', 'absen', 'cekabsen', 'hapusabsen'],
    use: 'alasan',
    category: 'group',
    async: async (m, {
        anya,
        calender,
        groups
    }) => {
        let caption;
        let absenData = groups.absen;
        switch (m.command) {
            case 'mulaiabsen':
                if (!m.isAdmin && !m.isOwner) return m.reply(global.mess.admin)
                if (absenData.status) return m.reply(`Masih ada absen di grup ini, kirim *${m.prefix}hapusabsen* untuk menghapus absen.`)
                groups.absen = {
                    status: true,
                    alasan: m.text ? m.text : '-',
                    date: calender,
                    peserta: []
                };
                caption = `乂  *ABSEN DI MULAI*

- *Tanggal*: ${groups.absen.date}
- *Alasan*: ${groups.absen.alasan}

kirim *${m.prefix}absen* untuk absen`
                m.reply(caption.trim());
                break
            case 'absen':
                if (!absenData.status) return m.reply(`Tidak ada absen di grup ini!`)
                let isAbsen = absenData.peserta.some(x => x.jid === m.sender);
                if (isAbsen) return m.reply('Kamu sudah Absen!')
                groups.absen.peserta.push({
                    jid: m.sender,
                    text: m.text || ''
                })
                caption = `乂  *A B S E N*

- *Tanggal*: ${absenData.date}
- *Alasan*: ${absenData.alasan}
- *Total*: ${absenData.peserta.length}
- *Daftar Absen*: ${absenData.peserta.length < 1 ? '-' : formatAbsen(absenData.peserta)}

kirim *${m.prefix}absen* untuk absen`
                m.reply(caption.trim());
                break
            case 'cekabsen':
                if (!absenData.status) return m.reply('Tidak ada absen yang berlangsung!')
                caption = `乂  ${m.groupName}

- *Tanggal*: ${absenData.date}
- *Alasan*: ${absenData.alasan}
- *Total*: ${absenData.peserta.length}
- *Daftar Absen*: ${absenData.peserta.length < 1 ? '-' : formatAbsen(absenData.peserta)}

kirim *${m.prefix}absen* untuk absen`
                m.reply(caption.trim());
                break
            case 'hapusabsen':
                if (!m.isAdmin && !m.isOwner) return m.reply(global.mess.admin)
                if (!absenData.status) return m.reply('Tidak ada absen yang berlangsung!')
                absenData.status = false;
                absenData.peserta = [];
                m.reply('Absen berhasil dihapus')
                break
        }
    },
    group: true,
    location: 'plugins/group/absen.js'
}

function formatAbsen(peserta) {
    if (!Array.isArray(peserta)) return '-';
    return '\n' + peserta.map((item, index) => `${index + 1}. @${item.jid.split('@')[0]} ${item.text || ''}`).join('\n')
}