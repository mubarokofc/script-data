const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
const obj = {
nsfwImageDB: [],
sfwImageDB: [],
nsfwStickerDB: [],
sfwStickerDB: [],
}

exports.run = {
main: async (m, { func, anya, groups }) => {
if (!groups.hasOwnProperty('antiporn')) {
groups.antiporn = false;
}

/* create antiporn database file if doesn't exist */
if (!fs.existsSync('./database/antiporn.json')) fs.writeFileSync('./database/antiporn.json', JSON.stringify(obj, null, 2))

if (groups.antiporn) {
if (m.fromMe) return
// if (/image\/(png|jpe?g|gif)|video\/mp4|webp/.test(m.mime)) {
if (/image\/(png|jpe?g|gif)|webp/.test(m.mime)) {
let json = JSON.parse(fs.readFileSync('./database/antiporn.json'))
if (m.mtype === 'stickerMessage') {
const fileSha256 = m.message.stickerMessage.fileSha256.toString('base64');
if (json.sfwStickerDB.includes(fileSha256)) return
if (json.nsfwStickerDB.includes(fileSha256)) {
await m.reply('Porno Terdeteksi!') 
await anya.sendMessage(m.chat, { delete: m.key }) 
return
}
} else if (m.mtype === 'imageMessage') {
const fileSha256 = (m.message?.imageMessage?.fileSha256 ?? m.message?.viewOnceMessageV2?.message?.imageMessage?.fileSha256).toString('base64');
if (json.sfwImageDB.includes(fileSha256)) return
if (json.nsfwImageDB.includes(fileSha256)) {
await m.reply('Porno Terdeteksi!') 
await anya.sendMessage(m.chat, { delete: m.key }) 
return
}
}
if (m.mtype === 'stickerMessage' && m.message.stickerMessage.isAnimated) {
return
}
await anya.sendReact(m.chat, '🕒', m.key)
let media = await m.download();
if (!media) return
let url = await tmpfiles(media)
if (url) {
let image = await func.fetchJson(`https://api.betabotz.eu.org/api/tools/nsfw-detect?url=${url}&apikey=0TIrhCdZ7U2s1fX6Jzs0K0k056kyG7YQ0`)
if (!image.status) return anya.sendReact(m.chat, '❌', m.key)
const labelName = image?.result?.labelName || 'Not Porn';
let isNsfw = labelName.match(/(Porn)/gi) && labelName != 'Not Porn' ? true : false;
if (isNsfw) {
if (m.mtype === 'stickerMessage') {
const fileSha256 = m.message.stickerMessage.fileSha256.toString('base64');
if (!json.nsfwStickerDB.includes(fileSha256)) {
json.nsfwStickerDB.push(fileSha256)
fs.writeFileSync('./database/antiporn.json', JSON.stringify(json, null, 2))
}
} else if (m.mtype === 'imageMessage') {
const fileSha256 = (m.message?.imageMessage?.fileSha256 ?? m.message?.viewOnceMessageV2?.message?.imageMessage?.fileSha256).toString('base64');
if (!json.nsfwImageDB.includes(fileSha256)) {
json.nsfwImageDB.push(fileSha256)
fs.writeFileSync('./database/antiporn.json', JSON.stringify(json, null, 2))
}
}
await m.reply('Porno Terdeteksi!') 
await anya.sendMessage(m.chat, { delete: m.key }) 
} else {
await anya.sendReact(m.chat, '🎉', m.key)
if (m.mtype === 'stickerMessage') {
const fileSha256 = m.message.stickerMessage.fileSha256.toString('base64');
if (!json.sfwStickerDB.includes(fileSha256)) {
json.sfwStickerDB.push(fileSha256)
fs.writeFileSync('./database/antiporn.json', JSON.stringify(json, null, 2))
}
} else if (m.mtype === 'imageMessage') {
const fileSha256 = (m.message?.imageMessage?.fileSha256 ?? m.message?.viewOnceMessageV2?.message?.imageMessage?.fileSha256).toString('base64');
if (!json.sfwImageDB.includes(fileSha256)) {
json.sfwImageDB.push(fileSha256)
fs.writeFileSync('./database/antiporn.json', JSON.stringify(json, null, 2))
}
}
}
}
await func.delay(1000)
}
}
},
group: true,
botAdmin: true
}

async function tmpfiles (buffer) {
const { ext, mime } = (await fromBuffer(buffer)) || {};
const form = new FormData();
form.append("file", buffer, {
filename: `tmp.${ext}`,
contentType: mime
});
try {
const { data } = await axios.post("https://tmpfiles.org/api/v1/upload", form, {
headers: form.getHeaders()
});
const match = /https?:\/\/tmpfiles.org\/(.*)/.exec(data.data.url);
return `https://tmpfiles.org/dl/${match[1]}`;
} catch (error) {
return false;
}
}