exports.run = {
    main: async (m, {
        func,
        anya,
        commands
    }) => {
        if (!m.fromMe & m.isPc && !(m.command && commands.includes(m.command)) && !m.isPrefix && !/protocolMessage/.test(m.mtype)) {
            let user = global.db.users[m.sender];
            if (!('private' in user)) user.private = 0;
            const cooldown = 86400000;
            if (new Date() - user.private < cooldown) return;

            let caption = `Halo @${m.sender.split('@')[0]} 👋🏻, ada yang bisa saya bantu? Ketik .sewabot jika ingin menyewa bot ini.`.trim();

            await anya.replyAI(m.chat, caption, null, {
                forwardingScore: 10,
                isForwarded: true,
                mentionedJid: [m.sender],
                businessMessageForwardInfo: {
                    businessOwnerJid: '62895354291993@s.whatsapp.net'
                },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363375037255604@newsletter',
                    serverMessageId: null,
                    newsletterName: '𝗈𝖿𝖿𝗂𝖼𝗂𝖺𝗅 𝖺𝗇𝗒𝖺 𝖻𝗈𝗍'
                }
            });

            user.private = new Date() * 1;
        }
    },
    private: true,
    location: 'plugins/event/_private.js'
}