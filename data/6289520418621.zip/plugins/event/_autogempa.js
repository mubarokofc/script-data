const fetch = require('node-fetch');
const link = 'https://data.bmkg.go.id/DataMKG/TEWS/';
const groupChatId = '120363347494579697@g.us';
const groupData = global.db.groups[groupChatId];

async function fetchAndSendGempa(anya) {
    try {
        let res = await fetch(link + 'autogempa.json');
        if (!res.ok) throw new Error('Failed to fetch data from BMKG');

        let result = await res.json();
        result = result.Infogempa.gempa;

        // Format pesan
        let txt = `乂 A U T O - G E M P A\n`
        txt += `Tanggal : ${result.Tanggal}\n`;
        txt += `Waktu : ${result.Jam}\n`;
        txt += `Potensi : *${result.Potensi}*\n`;
        txt += `Magnitude : ${result.Magnitude}\n`;
        txt += `Kedalaman : ${result.Kedalaman}\n`;
        txt += `Wilayah : ${result.Wilayah}\n`;
        txt += `Lintang : ${result.Lintang} & Bujur: ${result.Bujur}\n`;
        txt += `Koordinat : ${result.Coordinates}\n`;
        txt += result.Dirasakan ? `Dirasakan : ${result.Dirasakan}` : '';

        let imgBuffer = await (await fetch(link + result.Shakemap)).buffer();

        await anya.sendMedia(groupChatId, imgBuffer, null, {
            caption: txt
        });
    } catch (e) {
        console.log(e);
        await anya.sendMessage(groupChatId, `Error: ${e.message}`);
    }
}

exports.run = {
    main: async (m, {
        func,
        anya,
        setting
    }) => {
        if (!groupData.hasOwnProperty('autogempa')) {
            groupData.autogempa = true;

            setInterval(() => {
                fetchAndSendGempa(anya);
            }, 3600000); // 3600000 ms = 1 jam
        }
    }
};