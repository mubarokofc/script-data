exports.run = {
    main: async (m, {
        func,
        anya,
        groups,
        errorMessage
    }) => {
const promoKeywords = [
    'minat pm',
    'promo',
    'ready panel',
    'ready vps',
    'ready nokos',
    'open reseller',
    'open jasa',
    'jangan lupa follow',
    '100% aman',
    'open topup',
    'topup bussid',
    'suntik sosmed',
    'topup truckid',
    'topup trucks indonesia'
];

    if (m.budy && groups.antipromosi && !m.isAdmin && !m.isOwner) {
        if (promoKeywords.some(keyword => m.budy.toLowerCase().includes(keyword))) {
        
            await anya.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.sender
                }
            });

            await anya.sendMessage(m.chat, {
                text: `Detected @${m.sender.split('@')[0]} has sent a promotional message. Sorry, your message will be deleted by the bot.`,
                mentions: [m.sender]
            }, {
                quoted: func.fstatus('Anti Promosi'),
                ephemeralExpiration: m.expiration
            });
        }
        await anya.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
    }
    
    if (m.budy && groups.antipromosinokick && !m.isAdmin && !m.isOwner) {
        if (promoKeywords.some(keyword => m.budy.toLowerCase().includes(keyword))) {
        
            await anya.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.sender
                }
            });

            await anya.sendMessage(m.chat, {
                text: `Detected @${m.sender.split('@')[0]} has sent a promotional message. Sorry, your message will be deleted by the bot.`,
                mentions: [m.sender]
            }, {
                quoted: func.fstatus('Anti Promosi No Kick'),
                ephemeralExpiration: m.expiration
            });
        }
    }
},
group: true,
botAdmin: true,
location: 'plugins/event/_antipromosi.js'
}