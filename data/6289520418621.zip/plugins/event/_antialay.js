exports.run = {
    main: async (m, {
        func,
        anya,
        groups
    }) => {
        if (!m.fromMe && m.budy.match(/(😍|🥰|😘|😊|🤭|🤗)/gi) && ['120363264558127828@g.us'].includes(m.chat) && !m.isPrem && !m.isVvip) {
            await anya.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.sender
                }
            })
            await func.delay(1000)
        }
    },
    group: true,
    botAdmin: true,
    location: 'plugins/event/_antialay.js'
}