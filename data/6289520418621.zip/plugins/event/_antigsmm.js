exports.run = {
    main: async (m, {
        func,
        anya,
        groups,
        errorMessage
    }) => {
        if (groups.antigsmm && /groupStatusMentionMessage/.test(m.mtype) && !m.isAdmin && !m.isOwner) {
            return await anya.sendMessage(m.chat, {
                    delete: {
                        remoteJid: m.chat,
                        fromMe: false,
                        id: m.key.id,
                        participant: m.sender
                    }
                })
                .then(() => anya.sendMessage(m.chat, {
                    text: `Sorry @${m.sender.split('@')[0]} your message will be deleted by the bot.`,
                    mentions: [m.sender]
                }, {
                    quoted: func.fstatus('Anti Group Status Mention Message'),
                    ephemeralExpiration: m.expiration
                }))
            // .then(() => anya.groupParticipantsUpdate(m.chat, [m.sender], 'remove'))
        }
    },
    group: true,
    botAdmin: true,
    location: 'plugins/event/_antigsmm.js'
}