exports.run = {
main: async (m, { func, anya, packname, author, isPrem }) => {
if (m.budy && global.db.sticker[m.budy] && isPrem) {
anya.sendStickerFromUrl(m.chat, global.db.sticker[m.budy].link, m, {
packname: packname, 
author: author, 
expiration: m.expiration
})
}
},
limit: true
}