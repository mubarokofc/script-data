const axios = require('axios');
const cheerio = require('cheerio');
const crypto = require('crypto');
const FormData = require('form-data');
let processedLink = new Set();

async function facebook(link) {
    return new Promise((resolve, reject) => {
        let config = {
            'url': link
        }
        axios('https://www.getfvid.com/downloader', {
                method: 'POST',
                data: new URLSearchParams(Object.entries(config)),
                headers: {
                    "content-type": "application/x-www-form-urlencoded",
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                    "cookie": "_ga=; _pbjs_userid_consent_data=; cto_bidid=; _gid=; __gads=ID=; cookieconsent_status=dismiss"
                }
            })
            .then(async ({
                data
            }) => {
                const $ = cheerio.load(data)
                resolve({
                    video: $('body > div.page-content > div > div > div.col-lg-10.col-md-10.col-centered > div > div:nth-child(3) > div > div.col-md-4.btns-download > p:nth-child(1) > a').attr('href'),
                    audio: $('body > div.page-content > div > div > div.col-lg-10.col-md-10.col-centered > div > div:nth-child(3) > div > div.col-md-4.btns-download > p:nth-child(2) > a').attr('href')
                })
            })
            .catch(reject)
    })
}

async function ttSlide(url) {
    try {
        const response = await axios.post('https://ttsave.app/download', {
            query: url,
            language_id: '2'
        }, {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            }
        })

        const html = response.data
        const $ = cheerio.load(html)

        const uniqueId = $('#unique-id').val()
        const username = $('h2.font-extrabold.text-xl.text-center').text()
        const thumbnail = $('a[target="_blank"]').attr('href')
        const profile = $('img.h-24.w-34.rounded-full').attr('src')
        const description = $('p.text-gray-600.px-2.text-center.break-all.w-3/4.oneliner').text()

        const stats = {
            views: $('svg.h-5.w-5.text-gray-500 + span').text(),
            likes: $('svg.h-5.w-5.text-red-500 + span').text(),
            comments: $('svg.h-5.w-5.text-green-500 + span').text(),
            shares: $('svg.h-5.w-5.text-yellow-500 + span').text(),
            downloads: $('svg.h-5.w-5.text-blue-500 + span').text()
        }

        const download = []
        $('a[onclick="bdl(this, event)"]').each((i, elem) => {
            const link = $(elem).attr('href')
            const type = $(elem).attr('type')
            const title = $(elem).text().trim()
            download.push({
                link,
                type,
                title
            })
        })

        return {
            uniqueId,
            username,
            thumbnail,
            profile,
            description,
            stats,
            download,
        }
    } catch (error) {
        console.error(error)
        throw error
    }
}

async function SSVID(link) {
    try {
        const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:watch\?v=|embed\/|v\/)|youtu\.be\/)([\w-]{11})/;
        const match = link.match(regex);
        if (!match) {
            return {
                status: false,
                message: 'Link video tidak valid'
            }
        }
        const id = match[1];

        const headers = {
            accept: "*/*",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            "sec-ch-ua": '"Not-A.Brand";v="99", "Chromium";v="124"',
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": '"Android"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "x-requested-with": "XMLHttpRequest",
            Referer: "https://ssvid.net/",
            Origin: "https://ssvid.net",
            Cookie: "_ga=GA1.1.123456789.1234567890; _gid=GA1.1.987654321.0987654"
        };

        const searchResponse = await axios.post("https://ssvid.net/api/ajax/search", `query=${encodeURIComponent(link)}&vt=home`, {
            headers: headers
        });

        if (!searchResponse.data || !searchResponse.data.vid) {
            throw new Error("Tidak dapat menemukan informasi video");
        }

        const videoData = searchResponse.data;

        const mp4ConvertKey = videoData.links.mp4.auto.k || videoData.links.mp4["18"].k;
        const mp4ConvertPayload = `vid=${id}&k=${encodeURIComponent(mp4ConvertKey)}`;
        const mp4ConvertResponse = await axios.post("https://ssvid.net/api/ajax/convert", mp4ConvertPayload, {
            headers: headers
        });

        const mp3ConvertKey = videoData.links.mp3.mp3128.k;
        const mp3ConvertPayload = `vid=${id}&k=${encodeURIComponent(mp3ConvertKey)}`;
        const mp3ConvertResponse = await axios.post("https://ssvid.net/api/ajax/convert", mp3ConvertPayload, {
            headers: headers
        });

        if (!mp4ConvertResponse.data || mp4ConvertResponse.data.c_status !== "CONVERTED" || !mp3ConvertResponse.data || mp3ConvertResponse.data.c_status !== "CONVERTED") {
            throw new Error("Konversi video gagal");
        }

        return {
            status: true,
            title: videoData?.title || '-',
            mp4: {
                quality: videoData?.links?.mp4?.auto?.q_text || videoData?.links?.mp4["18"]?.q_text || '-',
                size: videoData?.links?.mp4?.auto?.size || videoData?.links?.mp4["18"]?.size || '-',
                downloadLink: mp4ConvertResponse?.data?.dlink
            },
            mp3: {
                quality: videoData?.links?.mp3?.mp3128?.q_text || '-',
                size: videoData?.links?.mp3?.mp3128?.size || '-',
                downloadLink: mp3ConvertResponse?.data?.dlink
            }
        };
    } catch (error) {
        console.log(error);
        return {
            status: false,
            message: error.message
        };
    }
}

async function msec() {
    try {
        const {
            data
        } = await axios.get('https://sssinstagram.com/msec')
        return Math.floor(data.msec * 1000)
    } catch (error) {
        console.error('Error fetching time:', error)
        return Date.now()
    }
}

async function generateSignature(url, secretKey) {
    const time = await msec()
    const ab = Date.now() - (time ? Date.now() - time : 0)
    const hashString = `${url}${ab}${secretKey}`
    const signature = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(hashString))
        .then(buffer => Array.from(new Uint8Array(buffer)).map(b => b.toString(16).padStart(2, '0')).join(''))

    return {
        signature,
        ab,
        time
    }
}

async function SSSIG(url) {
    const secretKey = '19e08ff42f18559b51825685d917c5c9e9d89f8a5c1ab147f820f46e94c3df26'
    const {
        signature,
        ab,
        time
    } = await generateSignature(url, secretKey)

    const requestData = {
        url: url,
        ts: ab,
        _ts: 1739186038417,
        _tsc: time ? Date.now() - time : 0,
        _s: signature
    }

    const headers = {
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': 'https://sssinstagram.com/',
        'authority': 'sssinstagram.com/',
        'Origin': 'https://sssinstagram.com/'
    }

    try {
        const response = await axios.post('https://sssinstagram.com/api/convert', requestData, {
            headers
        })
        return response.data
    } catch (error) {
        return {
            error: 'Error scraping data',
            details: error.response ? error.response.data : error.message
        }
    }
}

async function savetik(url) {
    const bodyForm = new FormData();
    bodyForm.append("q", url);
    bodyForm.append("lang", "id");
    try {
        const {
            data
        } = await axios(`https://savetik.co/api/ajaxSearch`, {
            method: "post",
            data: bodyForm,
            headers: {
                "content-type": "application/x-www-form-urlencoded",
                "User-Agent": "PostmanRuntime/7.32.2",
            },
        });
        const $ = cheerio.load(data.data);
        const result = {
            status: true,
            title: $("div.video-data > div > .tik-left > div > .content > div > h3").text(),
            video: $("div.video-data > div > .tik-right > div > p:nth-child(1) > a").attr("href"),
            audio: $("div.video-data > div > .tik-right > div > p:nth-child(3) > a").attr("href"),
        };
        return result;
    } catch (error) {
        console.log(error);
        return {
            status: false,
            message: error.message
        }
    }
}

exports.run = {
    main: async (m, {
        func,
        anya,
        setting,
        groups,
        commands
    }) => {
        if (m.budy && setting.autodownload && !(m.command && commands.includes(m.command)) && (m.isPrem || m.isVvip || m.isVIP) && !m.isPrefix && !/(exports\.run|async|await|function|const|var|let)/.test(m.budy)) {
            const extractLink = generateLink(m.budy);

            /* Function Auto Download Youtube By ZidanDev */
            if (extractLink) {
                const links = filterDuplicates(extractLink.filter(v => v.match(/^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/)));
                try {
                    if (links.length > 0) {
                        if (processedLink.has(links[0])) return;
                        processedLink.add(links[0]);
                        anya.sendReact(m.chat, '🕒', m.key);
                        /*let wait = await anya.sendMessage(m.chat, {
                            text: 'Url youtube terdeteksi\nWait sedang mengecek data url...'
                        }, {
                            quoted: m,
                            ephemeralExpiration: m.expiration
                        })
                        if (users.limit > 0) {
                        let limit = 3
                        if (users.limit >= limit) {
                        users.limit -= limit
                        } else return m.reply('Limit Anda tidak cukup untuk menggunakan fitur ini.')
                        }*/
                        links.map(async link => {
                            const result = await SSVID(link);
                            if (!result.status) return m.reply(result.message)
                            let capt = `*YOUTUBE AUTO DOWNLOADER*\n`
                            capt += `\n◦ Title : ${result.title}`
                            capt += '\n\n*MP4*:'
                            capt += `\n◦ Quality : ${result.mp4.quality}`
                            capt += `\n◦ Size : ${result.mp4.size}`
                            capt += '\n\n*MP3*:'
                            capt += `\n◦ Quality : ${result.mp3.quality}`
                            capt += `\n◦ Size : ${result.mp3.size}`
                            capt += `\n\nPlease wait, the audio & video file is being sent...`
                            await anya.sendMessage(m.chat, {
                                text: capt,
                                // edit: wait.key
                            }, {
                                quoted: m,
                                ephemeralExpiration: m.expiration
                            }).then(async (message) => {
                                await anya.sendMessage(m.chat, {
                                    audio: {
                                        url: result.mp3.downloadLink
                                    },
                                    fileName: result.title + '.mp3',
                                    mimetype: 'audio/mpeg',
                                }, {
                                    quoted: message,
                                    ephemeralExpiration: m.expiration
                                })
                            })

                            anya.sendMessage(m.chat, {
                                video: {
                                    url: result.mp4.downloadLink
                                },
                                caption: result.title,
                                mimetype: 'video/mp4',
                            }, {
                                quoted: m,
                                ephemeralExpiration: m.expiration
                            })
                            processedLink.delete(link)
                        })
                    }
                } catch (error) {
                    console.log(error)
                    processedLink.clear();
                    return anya.reply(m.chat, error.message, m, {
                        expiration: m.expiration
                    })
                }
            }

            /* Function Auto Download Tiktok By ZidanDev */
            if (extractLink) {
                const links = filterDuplicates(extractLink.filter(v => ttFixed(v).match(/^(?:https?:\/\/)?(?:www\.|vt\.|vm\.|t\.)?(?:tiktok\.com\/)(?:\S+)?$/)));
                try {
                    if (links.length > 0) {
                        if (processedLink.has(links[0])) return;
                        processedLink.add(links[0]);
                        anya.sendReact(m.chat, '🕒', m.key);
                        links.map(async link => {
                            const result = await savetik(ttFixed(link));
                            if (!result.status) return m.reply(result.message)
                            if (result.audio == undefined) {
                                let data = await ttSlide(ttFixed(link));
                                if (data.download.length == 0) return processedLink.delete(link);
                                let slide = data.download.filter(v => v.type == 'slide')
                                let stats = data.stats;
                                let capt = `*TIKTOK SLIDE AUTO DOWNLOADER*\n`
                                capt += `\n- Username : ${data.username}`
                                capt += `\n- UniqueId : ${data.uniqueId}`
                                capt += `\n- Views : ${stats.views ?? '-'}`
                                capt += `\n- Likes : ${stats.likes ?? '-'}`
                                capt += `\n- Comments : ${stats.comments ?? '-'}`
                                capt += `\n- Shares : ${stats.shares ?? '-'}`
                                capt += `\n- Downloads : ${stats.downloads ?? '-'}`
                                capt += `\n- Total Images : ${slide.length}`
                                capt += `\n\n_Please wait image is being sent..._`
                                await anya.sendMessage(m.chat, {
                                    text: capt,
                                    // edit: wait.key
                                }, {
                                    quoted: m,
                                    ephemeralExpiration: m.expiration
                                }).then(async () => {
                                    if (slide.length == 0) return processedLink.delete(link);
                                    for (let item of slide) {
                                        anya.sendMessage(m.chat, {
                                            image: {
                                                url: item.link
                                            }
                                        }, {
                                            ephemeralExpiration: m.expiration
                                        })
                                        await func.delay(1000)
                                    }
                                    return processedLink.delete(link);
                                })
                            } else {
                                anya.sendMessage(m.chat, {
                                        video: {
                                            url: result.video
                                        },
                                        caption: result?.title || ''
                                    }, {
                                        quoted: m,
                                        ephemeralExpiration: m.expiration
                                    })
                                    .then((q) => anya.sendMessage(m.chat, {
                                        audio: {
                                            url: result.audio
                                        },
                                        mimetype: 'audio/mpeg',
                                        ptt: false
                                    }, {
                                        quoted: q,
                                        ephemeralExpiration: m.expiration
                                    }))
                                return processedLink.delete(link);
                            }
                        })
                    }
                } catch (error) {
                    console.log(error)
                    processedLink.clear();
                    return anya.reply(m.chat, error.message, m, {
                        expiration: m.expiration
                    })
                }
            }

            /* Function Auto Download Facebook By ZidanDev */
            if (extractLink) {
                const links = filterDuplicates(extractLink.filter(v => v.match(/^(?:https?:\/\/(web\.|www\.|m\.)?(facebook|fb)\.(com|watch)\S+)?$/)));
                try {
                    if (links.length > 0) {
                        if (processedLink.has(links[0])) return;
                        processedLink.add(links[0]);
                        anya.sendReact(m.chat, '🕒', m.key);
                        let old = new Date()
                        links.map(async link => {
                            const res = await facebook(link)
                            await anya.sendMedia(m.chat, res.video, m, {
                                caption: `Speed : ${((new Date - old) * 1)} ms`,
                                expiration: m.expiration
                            });
                            processedLink.delete(link);
                        })
                    }
                } catch (error) {
                    console.log(error)
                    processedLink.clear();
                    return anya.reply(m.chat, error.message, m, {
                        expiration: m.expiration
                    })
                }
            }

            /* Function Auto Download Instagram By ZidanDev */
            if (extractLink) {
                const links = filterDuplicates(extractLink.filter(v => igFixed(v).match(/^(?:https?:\/\/)?(?:www\.)?(?:instagram\.com\/)(?:tv\/|p\/|reel\/)(?:\S+)?$/)));
                try {
                    if (links.length > 0) {
                        if (processedLink.has(links[0])) return;
                        processedLink.add(links[0]);
                        anya.sendReact(m.chat, '🕒', m.key);
                        links.map(async link => {
                            /*const result = await func.fetchJson('https://api.siputzx.my.id/api/d/igdl?url=' + igFixed(link))
                            if (!result.status) return m.reply('Something went wrong!')
                            if (result.data.length < 1) return m.reply('Data empty.');
                            const images = filterDuplicates(result.data.map(x => x.url));
                            for (let [index, url] of images.entries()) {
                                let message = index == 0 ? m : null;
                                await anya.sendMedia(m.chat, url, m, {
                                    caption: images.length == 1 ? global.mess.ok : '',
                                    expiration: m.expiration
                                })
                                await func.delay(500)
                            }*/
                            const result = await SSSIG(igFixed(link));
                            if (result.error) return m.reply(`${func.jsonFormat(result.details)}`);
                            const mediaArray = Array.isArray(result) ? result : [result];
                            let captionSent = false;

                            for (const item of mediaArray) {
                                const meta = item.meta || {}
                                let caption = `*INSTAGRAM AUTO DOWNLOADER*

- Username : ${meta.username || '-'}
- Likes : ${meta.like_count || 0}
- Comments : ${meta.comment_count || 0}
- Caption : ${(meta.title || '-').slice(0, 1000)}`.trim()
                                if (item.url?.[0]?.ext === 'mp4') {
                                    await anya.sendMessage(m.chat, {
                                        video: {
                                            url: item.url[0].url
                                        },
                                        caption: caption
                                    }, {
                                        quoted: m,
                                        ephemeralExpiration: m.expiration
                                    })
                                    return
                                }
                            }

                            for (const item of mediaArray) {
                                const meta = item.meta || {}
                                let caption = `*INSTAGRAM AUTO DOWNLOADER*

- Username : ${meta.username || '-'}
- Likes : ${meta.like_count || 0}
- Comments : ${meta.comment_count || 0}
- Caption : ${(meta.title || '-').slice(0, 1000)}`.trim()
                                if (item.url?.[0]?.url) {
                                    await anya.sendMessage(m.chat, {
                                        image: {
                                            url: item.url[0].url
                                        },
                                        caption: captionSent ? '' : caption
                                    }, {
                                        quoted: m,
                                        ephemeralExpiration: m.expiration
                                    })
                                    captionSent = true
                                } else if (item.thumb) {
                                    await anya.sendMessage(m.chat, {
                                        image: {
                                            url: item.thumb
                                        },
                                        caption: captionSent ? '' : caption
                                    }, {
                                        quoted: m,
                                        ephemeralExpiration: m.expiration
                                    })
                                    captionSent = true
                                }
                            }
                            return processedLink.delete(link);
                        })
                    }
                } catch (error) {
                    console.log(error)
                    processedLink.clear();
                    return anya.reply(m.chat, error.message, m, {
                        expiration: m.expiration
                    })
                }
            }

            /* Function Auto Download Mediafire By ZidanDev */
            if (extractLink) {
                const links = filterDuplicates(extractLink.filter(v => v.match(/^(?:https?:\/\/)?(?:www\.)?(?:mediafire\.com\/)(?:\S+)?$/)));
                try {
                    if (links.length > 0) {
                        if (processedLink.has(links[0])) return;
                        processedLink.add(links[0]);
                        anya.sendReact(m.chat, '🕒', m.key);
                        links.map(async link => {
                            const result = await func.fetchJson(`https://api.siputzx.my.id/api/d/mediafire?url=${link}`);
                            if (!result.status) return m.reply('Something went wrong!')
                            let data = result?.data;
                            if (!data?.fileName) return m.reply('Invalid link!')
                            let caption = `乂  *MEDIAFIRE AUTO DOWNLOADER*\n`
                            caption += `\n◦ File Name: ${data.fileName}`
                            caption += `\n◦ File Size: ${data.fileSize}`
                            await anya.sendMedia(m.chat, data.downloadLink, m, {
                                caption: caption,
                                fileName: data.fileName,
                                expiration: m.expiration
                            })
                            processedLink.delete(link)
                        })
                    }
                } catch (error) {
                    console.log(error)
                    processedLink.clear();
                    return anya.reply(m.chat, error.message, m, {
                        expiration: m.expiration
                    })
                }
            }
        }
    },
    location: 'plugins/event/_autodownload.js'
}

function generateLink(text) {
    let regex = /(https?:\/\/(?:www\.|(?!www))[^\s\.]+\.[^\s]{2,}|www\.[^\s]+\.[^\s]{2,})/gi;
    return text.match(regex)
}

function removeItem(arr, value) {
    let index = arr.indexOf(value)
    if (index > -1) arr.splice(index, 1)
    return arr
}

function igFixed(url) {
    let count = url.split('/')
    if (count.length == 7) {
        let username = count[3]
        let destruct = removeItem(count, username)
        return destruct.map(v => v).join('/')
    } else return url
}

function ttFixed(url) {
    if (!url.match(/(tiktok.com\/t\/)/g)) return url
    let id = url.split('/t/')[1]
    return 'https://vm.tiktok.com/' + id
}

function filterDuplicates(array) {
    return [...new Set(array)];
}

function formatter(integer) {
    let numb = parseInt(integer)
    return Number(numb).toLocaleString().replace(/,/g, '.')
}