exports.run = {
main: async (m, { func, anya, errorMessage }) => {
try {
if (!m.isOwner && !m.isAdmin && m.mentionedJid?.length >= m.members?.length) {
await anya.sendMessage(m.chat, {text: `Sorry @${m.sender.split('@')[0]} you will be removed from this group.`, mentions: [m.sender]}, {quoted: func.fstatus('Hidetag Message Detected'), ephemeralExpiration: m.expiration})
.then(() => anya.groupParticipantsUpdate(m.chat, [m.sender], 'remove'))
}
} catch (e) {
return errorMessage(e)
}
},
group: true,
botAdmin: true
}